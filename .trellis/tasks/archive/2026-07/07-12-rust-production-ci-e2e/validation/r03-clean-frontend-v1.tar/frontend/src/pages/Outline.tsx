import { Suspense, lazy, useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useShallow } from 'zustand/react/shallow';


import { Button, List, Modal, Form, Input, message, Empty, Space, Popconfirm, Card, Select, Radio, Tag, InputNumber, Typography, Row, Col, Divider, theme } from 'antd';


import { EditOutlined, DeleteOutlined, ThunderboltOutlined, BranchesOutlined, AppstoreAddOutlined, CheckCircleOutlined, ExclamationCircleOutlined, PlusOutlined } from '@ant-design/icons';


import { useStore } from '../store';
import { isActiveBackgroundTask, useBackgroundTaskStore } from '../store/backgroundTasks';


import { useCharacterSync, useOutlineSync } from '../store/hooks';


import { outlineApi, chapterApi } from '../services/modularApi';
import { backgroundTaskApi, projectApi, settingsApi } from '../services/modularApi';
import { formatBackgroundTaskError } from '../utils/taskPolling';
import InlineDeferredPanel from '../components/InlineDeferredPanel';
import { useRestorableBackgroundTaskPolling } from '../hooks/useRestorableBackgroundTaskPolling';
import { isRequestCancelledError } from '../services/core/httpClient';
import { hasUsableApiCredentials } from '../utils/apiKey';
import InlineErrorBoundary from '../components/InlineErrorBoundary';
import WorkflowEntryFallback from '../components/WorkflowEntryFallback';
import { designDisplayFont } from '../theme/themeConfig';


import type { OutlineExpansionResponse, BatchOutlineExpansionResponse, ChapterPlanItem, ApiError, Character, CreativeMode, PlotStage, QualityPreset, StoryFocus } from '../types';

const { Title, Paragraph, Text } = Typography;

const OUTLINE_TASK_REPLAY_KEY_PREFIX = 'background-task-replay:outline:';
const OUTLINE_GENERATE_REFRESH_KEY_PREFIX = 'background-task-refresh:outline-generate:';
const OUTLINE_TASK_OPEN_REQUEST_KEY_PREFIX = 'background-task-open:outline:';
const OUTLINE_GENERATE_REFRESH_RETRY_DELAY_MS = 2000;

const hasOutlineTaskReplayBeenHandled = (taskId: string): boolean => {
  try {
    return sessionStorage.getItem(`${OUTLINE_TASK_REPLAY_KEY_PREFIX}${taskId}`) === '1';
  } catch {
    return false;
  }
};

const markOutlineTaskReplayHandled = (taskId: string) => {
  try {
    sessionStorage.setItem(`${OUTLINE_TASK_REPLAY_KEY_PREFIX}${taskId}`, '1');
  } catch {
    // ignore sessionStorage failures
  }
};

const hasOutlineGenerateRefreshBeenHandled = (taskId: string): boolean => {
  try {
    return sessionStorage.getItem(`${OUTLINE_GENERATE_REFRESH_KEY_PREFIX}${taskId}`) === '1';
  } catch {
    return false;
  }
};

const markOutlineGenerateRefreshHandled = (taskId: string) => {
  try {
    sessionStorage.setItem(`${OUTLINE_GENERATE_REFRESH_KEY_PREFIX}${taskId}`, '1');
  } catch {
    // ignore sessionStorage failures
  }
};

const createOutlineRefreshTaskLock = () => {
  const inFlightTaskIds = new Set<string>();

  return {
    acquire(taskId: string) {
      if (!taskId || inFlightTaskIds.has(taskId)) {
        return false;
      }
      inFlightTaskIds.add(taskId);
      return true;
    },
    release(taskId: string) {
      if (!taskId) {
        return;
      }
      inFlightTaskIds.delete(taskId);
    },
  };
};

const getRequestedOutlineTaskId = (projectId: string): string | null => {
  try {
    return sessionStorage.getItem(`${OUTLINE_TASK_OPEN_REQUEST_KEY_PREFIX}${projectId}`);
  } catch {
    return null;
  }
};

const clearRequestedOutlineTaskId = (projectId: string) => {
  try {
    sessionStorage.removeItem(`${OUTLINE_TASK_OPEN_REQUEST_KEY_PREFIX}${projectId}`);
  } catch {
    // ignore sessionStorage failures
  }
};

const selectActiveOutlineGenerateTask = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
) => {
  if (!projectId) {
    return null;
  }

  return Object.values(tasks)
    .filter(
      (task) => task.projectId === projectId
        && task.taskType === 'outline_generate'
        && isActiveBackgroundTask(task)
    )
    .sort((left, right) => right.updatedAt - left.updatedAt)[0] ?? null;
};

const selectActiveOutlineExpandTask = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
) => {
  if (!projectId) {
    return null;
  }

  return Object.values(tasks)
    .filter(
      (task) => task.projectId === projectId
        && (task.taskType === 'outline_expand' || task.taskType === 'outline_batch_expand')
        && isActiveBackgroundTask(task)
    )
    .sort((left, right) => right.updatedAt - left.updatedAt)[0] ?? null;
};

const selectHasActiveOutlineGenerateTask = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
): boolean => Boolean(selectActiveOutlineGenerateTask(tasks, projectId));

const selectHasActiveOutlineExpandTask = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
): boolean => Boolean(selectActiveOutlineExpandTask(tasks, projectId));

const selectOutlineReplayTaskSignature = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
): string => {
  if (!projectId) {
    return '';
  }

  const requestedTaskId = getRequestedOutlineTaskId(projectId);
  const completedTasks = Object.values(tasks).filter(
    (task) => task.projectId === projectId
      && (task.taskType === 'outline_expand' || task.taskType === 'outline_batch_expand')
      && task.status === 'completed'
      && task.result
  );
  const completedTask = requestedTaskId
    ? completedTasks.find((task) => task.taskId === requestedTaskId)
    : completedTasks
      .filter((task) => !hasOutlineTaskReplayBeenHandled(task.taskId))
      .sort((left, right) => (right.completedAt ?? right.updatedAt) - (left.completedAt ?? left.updatedAt))[0];

  if (!completedTask) {
    return '';
  }

  return `${completedTask.taskId}:${requestedTaskId ? 'requested' : 'latest'}:${completedTask.taskType}:${completedTask.completedAt ?? completedTask.updatedAt}`;
};

const selectOutlineGenerateRefreshTaskSignature = (
  tasks: Record<string, import('../store/backgroundTasks').TrackedBackgroundTask>,
  projectId?: string | null,
): string => {
  if (!projectId) {
    return '';
  }

  const completedTask = Object.values(tasks)
    .filter(
      (task) => task.projectId === projectId
        && task.taskType === 'outline_generate'
        && task.status === 'completed'
        && !hasOutlineGenerateRefreshBeenHandled(task.taskId)
    )
    .sort((left, right) => (right.completedAt ?? right.updatedAt) - (left.completedAt ?? left.updatedAt))[0];

  if (!completedTask) {
    return '';
  }

  return `${completedTask.taskId}:${completedTask.completedAt ?? completedTask.updatedAt}`;
};


// 大纲生成请求数据类型


interface OutlineGenerateRequestData {


  project_id: string;


  genre: string;


  theme: string;


  chapter_count: number;


  narrative_perspective: string;


  target_words: number;


  requirements?: string;


  mode: 'auto' | 'new' | 'continue';
  enable_web_research?: boolean;
  web_research_query?: string;


  story_direction?: string;


  plot_stage: PlotStage;


  model?: string;


  provider?: string;


  creative_mode?: CreativeMode;


  story_focus?: StoryFocus;


  story_creation_brief?: string;


  quality_preset?: QualityPreset;


  quality_notes?: string;


}




// 跳过的大纲信息类型


// 场景类型


interface SceneInfo {


  location: string;


  characters: string[];


  purpose: string;


}


// 角色/组织条目类型（新格式）


interface CharacterEntry {


  name: string;


  type: 'character' | 'organization';


}


/**


 * 解析 characters 字段，兼容新旧格式


 * 旧格式: string[] -> 全部当作 character


 * 新格式: {name: string, type: "character"|"organization"}[]


 */


function parseCharacterEntries(characters: unknown): CharacterEntry[] {


  if (!Array.isArray(characters) || characters.length === 0) return [];


  


  return characters.map((entry) => {


    if (typeof entry === 'string') {


      // 旧格式：纯字符串，默认为 character


      return { name: entry, type: 'character' as const };


    }


    if (typeof entry === 'object' && entry !== null && 'name' in entry) {


      // 新格式：带类型标识的对象


      return {


        name: (entry as { name: string }).name,


        type: ((entry as { type?: string }).type === 'organization' ? 'organization' : 'character') as 'character' | 'organization'


      };


    }


    return null;


  }).filter((e): e is CharacterEntry => e !== null);


}


/** 从 entries 中提取角色名称列表 */


function getCharacterNames(entries: CharacterEntry[]): string[] {


  return entries.filter(e => e.type === 'character').map(e => e.name);


}


/** 从 entries 中提取组织名称列表 */


function getOrganizationNames(entries: CharacterEntry[]): string[] {


  return entries.filter(e => e.type === 'organization').map(e => e.name);


}


interface OutlineStructureData {


  key_events?: string[];


  key_points?: string[];


  characters_involved?: string[];


  characters?: unknown[];


  scenes?: string[] | SceneInfo[];


  emotion?: string;


  goal?: string;


}


interface ParsedOutlineViewData {


  structureData: OutlineStructureData;


  characterNames: string[];


  organizationNames: string[];


}


function parseOutlineStructure(structure?: string): OutlineStructureData {


  if (!structure) return {};


  try {


    return JSON.parse(structure) as OutlineStructureData;


  } catch (error) {


    console.error('parse outline structure failed:', error);


    return {};


  }


}


function getPreviewText(text: string | undefined, maxLength: number): string {


  if (!text) return '';


  const normalizedText = text.replace(/\s+/g, ' ').trim();


  if (normalizedText.length <= maxLength) {


    return normalizedText;


  }


  return `${normalizedText.slice(0, maxLength).trimEnd()}...`;


}


const { TextArea } = Input;


const outlineChapterStatusCache = new Map<string, boolean>();


const outlineChapterStatusPromises = new Map<string, Promise<boolean>>();


const INITIAL_OUTLINE_RENDER_COUNT = 6;


const OUTLINE_RENDER_BATCH_SIZE = 8;


const OUTLINE_RENDER_BATCH_DELAY_MS = 120;


const LazySSEProgressModal = lazy(async () => {


  const module = await import('../components/SSEProgressModal');


  return { default: module.SSEProgressModal };


});


const LazyOutlineBatchPreviewModal = lazy(() => import('../components/OutlineBatchPreviewModal'));
const LazyOutlineExpansionPreviewContent = lazy(() => import('../components/OutlineExpansionPreviewContent'));
const LazyOutlineExistingExpansionContent = lazy(() => import('../components/OutlineExistingExpansionContent'));
const LazyOutlineBatchExpandConfigForm = lazy(() => import('../components/OutlineBatchExpandConfigForm'));
const LazyOutlineGenerateModalContent = lazy(() => import('../components/OutlineGenerateModalContent'));

function OutlineDeferredFallback() {
  return (
    <InlineDeferredPanel
      eyebrow="Outline Workspace"
      title="正在接管大纲工作区面板"
      message="系统正在恢复生成、展开配置与预览内容面板，原有大纲生成、展开和预览逻辑保持不变。"
      minHeight={180}
      tags={[
        { label: '大纲面板恢复中', color: 'processing' },
        { label: '局部工作区接管', color: 'blue' },
      ]}
    />
  );
}

const outlineLazyFallback = (
  <OutlineDeferredFallback />
);

type ApiLikeError = {
  response?: {
    data?: {
      detail?: string;
    };
  };
  message?: string;
};

const getApiErrorMessage = (error: unknown, fallbackMessage: string): string => {
  const apiError = error as ApiLikeError;
  return apiError.response?.data?.detail || apiError.message || fallbackMessage;
};
export default function Outline() {


  const currentProject = useStore((state) => state.currentProject);


  const outlines = useStore(
    useShallow((state) => state.outlines.filter((outline) => outline.project_id === currentProject?.id)),
  );


  const storeCharacters = useStore(
    useShallow((state) => state.characters.filter((character) => character.project_id === currentProject?.id)),
  );


  const setCurrentProject = useStore((state) => state.setCurrentProject);


  const [isGenerating, setIsGenerating] = useState(false);


  const [editForm] = Form.useForm();


  const [generateForm] = Form.useForm();


  const [expansionForm] = Form.useForm();


  const [modalApi, contextHolder] = Modal.useModal();


  const [batchExpansionForm] = Form.useForm();


  const [manualCreateForm] = Form.useForm();
  const { token } = theme.useToken();

  const buildOutlineGenerateLogContext = (extra?: Record<string, unknown>) => ({
    projectId: currentProject?.id ?? null,
    outlineCount: outlines.length,
    isGenerating,
    isExpanding,
    hasActiveGenerateTask: hasActiveTrackedOutlineGenerateTask,
    hasActiveExpandTask: hasActiveTrackedOutlineExpandTask,
    ...extra,
  });
  const projectDefaultCreativeMode = currentProject?.default_creative_mode as CreativeMode | undefined;
  const projectDefaultStoryFocus = currentProject?.default_story_focus as StoryFocus | undefined;
  const projectDefaultPlotStage = currentProject?.default_plot_stage as PlotStage | undefined;
  const projectDefaultStoryCreationBrief = currentProject?.default_story_creation_brief || undefined;
  const projectDefaultQualityPreset = currentProject?.default_quality_preset as QualityPreset | undefined;
  const projectDefaultQualityNotes = currentProject?.default_quality_notes || undefined;



  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);


  const [isExpanding, setIsExpanding] = useState(false);


  // ✅ 新增：记录每个大纲的展开状态


  const [outlineExpandStatus, setOutlineExpandStatus] = useState<Record<string, boolean>>({});


  


  // ✅ 新增：记录场景区域的展开/折叠状态


  const [scenesExpandStatus, setScenesExpandStatus] = useState<Record<string, boolean>>({});


  // 缓存批量展开的规划数据，避免重复AI调用


  const [cachedBatchExpansionResponse, setCachedBatchExpansionResponse] = useState<BatchOutlineExpansionResponse | null>(null);


  // 批量展开预览的状态


  const [batchPreviewVisible, setBatchPreviewVisible] = useState(false);


  const [batchPreviewData, setBatchPreviewData] = useState<BatchOutlineExpansionResponse | null>(null);


  const [singlePreviewVisible, setSinglePreviewVisible] = useState(false);


  const [singlePreviewOutlineId, setSinglePreviewOutlineId] = useState<string | null>(null);


  const [singlePreviewData, setSinglePreviewData] = useState<OutlineExpansionResponse | null>(null);


  const [visibleOutlineCount, setVisibleOutlineCount] = useState(INITIAL_OUTLINE_RENDER_COUNT);


  // SSE进度状态


  const [sseProgress, setSSEProgress] = useState(0);


  const [sseMessage, setSSEMessage] = useState('');


  const [sseModalVisible, setSSEModalVisible] = useState(false);
  const hasActiveTrackedOutlineGenerateTask = useBackgroundTaskStore(
    (state) => selectHasActiveOutlineGenerateTask(state.tasks, currentProject?.id)
  );
  const hasActiveTrackedOutlineExpandTask = useBackgroundTaskStore(
    (state) => selectHasActiveOutlineExpandTask(state.tasks, currentProject?.id)
  );
  const outlineReplayTaskSignature = useBackgroundTaskStore(
    (state) => selectOutlineReplayTaskSignature(state.tasks, currentProject?.id)
  );
  const outlineGenerateRefreshTaskSignature = useBackgroundTaskStore(
    (state) => selectOutlineGenerateRefreshTaskSignature(state.tasks, currentProject?.id)
  );
  const completedOutlineRefreshLockRef = useRef(createOutlineRefreshTaskLock());
  const completedOutlineRefreshRetryTimerRef = useRef<number | null>(null);
  const [completedOutlineRefreshRetryTick, setCompletedOutlineRefreshRetryTick] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const scheduleCompletedOutlineRefreshRetry = useCallback(() => {
    if (completedOutlineRefreshRetryTimerRef.current) {
      clearTimeout(completedOutlineRefreshRetryTimerRef.current);
    }

    completedOutlineRefreshRetryTimerRef.current = window.setTimeout(() => {
      completedOutlineRefreshRetryTimerRef.current = null;
      setCompletedOutlineRefreshRetryTick((value) => value + 1);
    }, OUTLINE_GENERATE_REFRESH_RETRY_DELAY_MS);
  }, []);

  const expandTaskIdRef = useRef<string | null>(null);


  const { currentTaskIdRef: generateTaskIdRef, startTaskPolling: startGenerateTaskPolling, stopTaskPolling: stopGenerateTaskPolling } = useRestorableBackgroundTaskPolling({
    projectId: currentProject?.id,
    getActiveTrackedTask: () => selectActiveOutlineGenerateTask(
      useBackgroundTaskStore.getState().tasks,
      currentProject?.id,
    ),
    canRestore: !isExpanding && !expandTaskIdRef.current,
    isMatchingTask: (task) => task.task_type === 'outline_generate' && (task.status === 'pending' || task.status === 'running'),
    onRestoreTask: ({ progress, message: taskMessage }) => {
      setIsGenerating(true);
      setSSEProgress(progress || 0);
      setSSEMessage(taskMessage || '正在恢复大纲任务...');
      setSSEModalVisible(true);
    },
    createPollingOptions: () => ({
      pollTask: (currentPollingTaskId) => backgroundTaskApi.getTaskStatus(currentPollingTaskId),
      onTask: (task) => {
        setSSEProgress(task.progress || 0);
        setSSEMessage(task.message || '');
      },
      onCompleted: () => {
        stopGenerateTaskPolling();
        generateTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsGenerating(false);
        message.success('大纲生成成功');
      },
      onFailed: (task) => {
        stopGenerateTaskPolling();
        generateTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsGenerating(false);
        console.error('大纲生成任务失败:', {
          context: buildOutlineGenerateLogContext({
            stage: 'generate-task-failed',
            taskId: task.task_id,
            taskStatus: task.status,
            taskProgress: task.progress ?? null,
            taskMessage: task.message || null,
          }),
          taskError: task.error,
        });
        message.error(formatBackgroundTaskError(task.error, task.message, '生成失败'));
      },
      onCancelled: (task) => {
        stopGenerateTaskPolling();
        generateTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsGenerating(false);
        message.info(task.message || '任务已取消');
      },
      onPollingError: (error) => {
        if (isRequestCancelledError(error)) {
          return;
        }
        console.error('轮询大纲生成任务失败:', {
          error,
          context: buildOutlineGenerateLogContext({
            stage: 'generate-task-polling-error',
            taskId: generateTaskIdRef.current,
          }),
        });
        stopGenerateTaskPolling();
        generateTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsGenerating(false);
        void refreshOutlines();
        message.error('大纲生成状态同步失败，请刷新后重试');
      },
    }),
  });


  const openSingleExpansionPreview = useCallback((outlineId: string, response: OutlineExpansionResponse) => {
    setSinglePreviewOutlineId(outlineId);
    setSinglePreviewData(response);
    setSinglePreviewVisible(true);
  }, []);


  const handleExpandTaskResult = useCallback((
    taskType: 'outline_expand' | 'outline_batch_expand',
    result: Record<string, unknown> | null,
  ) => {
    if (!result) {
      message.error(taskType === 'outline_batch_expand' ? '批量展开大纲失败' : '展开大纲失败');
      return;
    }

    if (taskType === 'outline_batch_expand') {
      const data = result as unknown as BatchOutlineExpansionResponse;
      if (expandTaskIdRef.current) {
        markOutlineTaskReplayHandled(expandTaskIdRef.current);
      }
      setCachedBatchExpansionResponse(data);
      setBatchPreviewData(data);
      setBatchPreviewVisible(true);
      return;
    }

    const response = result as unknown as OutlineExpansionResponse;
    const outlineId = typeof response.outline_id === 'string' ? response.outline_id : '';
    if (!outlineId) {
      message.error('缺少大纲 ID');
      return;
    }

    if (expandTaskIdRef.current) {
      markOutlineTaskReplayHandled(expandTaskIdRef.current);
    }
    openSingleExpansionPreview(outlineId, response);
  }, [openSingleExpansionPreview]);


  const { currentTaskIdRef: expandPollingTaskIdRef, startTaskPolling: startExpandTaskPolling, stopTaskPolling: stopExpandTaskPolling } = useRestorableBackgroundTaskPolling({
    projectId: currentProject?.id,
    getActiveTrackedTask: () => selectActiveOutlineExpandTask(
      useBackgroundTaskStore.getState().tasks,
      currentProject?.id,
    ),
    canRestore: !isGenerating && !generateTaskIdRef.current,
    isMatchingTask: (task) => (task.task_type === 'outline_expand' || task.task_type === 'outline_batch_expand') && (task.status === 'pending' || task.status === 'running'),
    onRestoreTask: ({ progress, message: taskMessage }) => {
      setIsExpanding(true);
      setSSEProgress(progress || 0);
      setSSEMessage(taskMessage || '正在恢复大纲任务...');
      setSSEModalVisible(true);
    },
    createPollingOptions: () => ({
      pollTask: (currentPollingTaskId) => backgroundTaskApi.getTaskStatus(currentPollingTaskId),
      onTask: (task) => {
        setSSEProgress(task.progress || 0);
        setSSEMessage(task.message || '');
      },
      onCompleted: (task) => {
        stopExpandTaskPolling();
        expandPollingTaskIdRef.current = null;
        expandTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsExpanding(false);

        if (task.task_type === 'outline_expand' || task.task_type === 'outline_batch_expand') {
          handleExpandTaskResult(task.task_type, (task.result as Record<string, unknown> | null) || null);
        }
      },
      onFailed: (task) => {
        stopExpandTaskPolling();
        expandPollingTaskIdRef.current = null;
        expandTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsExpanding(false);
        message.error(formatBackgroundTaskError(task.error, task.message, '展开失败'));
      },
      onCancelled: (task) => {
        stopExpandTaskPolling();
        expandPollingTaskIdRef.current = null;
        expandTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsExpanding(false);
        message.info(task.message || '任务已取消');
      },
      onPollingError: (error) => {
        if (isRequestCancelledError(error)) {
          return;
        }
        console.error('轮询大纲展开任务失败:', error);
        stopExpandTaskPolling();
        expandPollingTaskIdRef.current = null;
        expandTaskIdRef.current = null;
        setSSEModalVisible(false);
        setIsExpanding(false);
        void refreshOutlines();
        message.error('大纲展开状态同步失败，请刷新后重试');
      },
    }),
  });

  useEffect(() => {
    return () => {
      stopExpandTaskPolling();
    };
  }, [stopExpandTaskPolling]);


  useEffect(() => {
    if (
      !currentProject?.id
      || generateTaskIdRef.current
      || expandTaskIdRef.current
      || sseModalVisible
      || batchPreviewVisible
    ) {
      return;
    }

    if (!outlineReplayTaskSignature) {
      return;
    }

    const [taskId, replayMode] = outlineReplayTaskSignature.split(':');
    if (!taskId) {
      return;
    }

    const completedTask = useBackgroundTaskStore.getState().tasks[taskId];

    if (!completedTask?.result) {
      return;
    }

    if (replayMode === 'requested') {
      clearRequestedOutlineTaskId(currentProject.id);
    }

    if (completedTask.taskType === 'outline_batch_expand') {
      const data = completedTask.result as unknown as BatchOutlineExpansionResponse;
      markOutlineTaskReplayHandled(completedTask.taskId);
      setCachedBatchExpansionResponse(data);
      setBatchPreviewData(data);
      setBatchPreviewVisible(true);
      return;
    }

    const response = completedTask.result as unknown as OutlineExpansionResponse;
    if (!response.outline_id || typeof response.outline_id !== 'string') {
      return;
    }

    markOutlineTaskReplayHandled(completedTask.taskId);
    openSingleExpansionPreview(response.outline_id, response);
  }, [batchPreviewVisible, currentProject?.id, generateTaskIdRef, openSingleExpansionPreview, outlineReplayTaskSignature, sseModalVisible]);


  const handleCancelGenerateTask = async () => {


    const taskId = generateTaskIdRef.current;


    if (!taskId) return;


    try {


      await backgroundTaskApi.cancelTask(taskId);


      stopGenerateTaskPolling();


      generateTaskIdRef.current = null;


      setSSEModalVisible(false);


      setIsGenerating(false);


      message.info('已取消大纲生成任务');


    } catch (error) {


      console.error('取消大纲生成任务失败:', error);


      message.error('取消任务失败');


    }


  };


  const handleCancelExpandTask = async () => {


    const taskId = expandTaskIdRef.current;


    if (!taskId) return;


    try {


      await backgroundTaskApi.cancelTask(taskId);


      stopExpandTaskPolling();


      expandTaskIdRef.current = null;


      setSSEModalVisible(false);


      setIsExpanding(false);


      message.info('已取消大纲展开任务');


    } catch (error) {


      console.error('取消大纲展开任务失败:', error);


      message.error('取消任务失败');


    }


  };


  // 使用同步 hooks


  const {


    refreshOutlines,


    updateOutline,


    deleteOutline


  } = useOutlineSync();


  const { refreshCharacters } = useCharacterSync();


  useEffect(() => {
    if (!currentProject?.id || generateTaskIdRef.current || isGenerating || isExpanding) {
      return;
    }

    if (!outlineGenerateRefreshTaskSignature) {
      return;
    }

    const [taskId] = outlineGenerateRefreshTaskSignature.split(':');
    if (!taskId) {
      return;
    }
    if (!completedOutlineRefreshLockRef.current.acquire(taskId)) {
      return;
    }

    void Promise.all([
      refreshOutlines(currentProject.id),
      projectApi.getProject(currentProject.id).then(setCurrentProject),
    ])
      .then(() => {
        markOutlineGenerateRefreshHandled(taskId);
      })
      .catch((error) => {
        console.error('刷新大纲数据失败:', error);
        scheduleCompletedOutlineRefreshRetry();
      })
      .finally(() => {
        completedOutlineRefreshLockRef.current.release(taskId);
      });
  }, [
    completedOutlineRefreshRetryTick,
    currentProject?.id,
    generateTaskIdRef,
    isExpanding,
    isGenerating,
    outlineGenerateRefreshTaskSignature,
    refreshOutlines,
    scheduleCompletedOutlineRefreshRetry,
    setCurrentProject,
  ]);

  useEffect(() => {
    return () => {
      if (completedOutlineRefreshRetryTimerRef.current) {
        clearTimeout(completedOutlineRefreshRetryTimerRef.current);
        completedOutlineRefreshRetryTimerRef.current = null;
      }
    };
  }, []);


  // 确保项目大纲已加载


  useEffect(() => {


    if (!currentProject?.id) return;


    const projectId = currentProject.id;


    const existingProjectOutlines = useStore.getState().outlines.filter((outline) => outline.project_id === projectId);


    if (existingProjectOutlines.length === 0) {


      void refreshOutlines(projectId);


    }


  }, [currentProject?.id, refreshOutlines]);


  const ensureProjectCharactersLoaded = useCallback((projectId = currentProject?.id) => {


    if (!projectId) {


      return;


    }


    const hasProjectCharacters = useStore.getState().characters.some((character) => character.project_id === projectId);


    if (!hasProjectCharacters) {


      void refreshCharacters(projectId);


    }


  }, [currentProject?.id, refreshCharacters]);


  const projectCharacters = useMemo(() => {


    if (!currentProject?.id) {


      return [];


    }


    return storeCharacters


      .filter((character) => character.project_id === currentProject.id)


      .map((char: Character) => ({


        label: char.name,


        value: char.name


      }));


  }, [currentProject?.id, storeCharacters]);


  const getOutlineHasChapters = async (outline: { id: string; has_chapters?: boolean }) => {


    if (typeof outline.has_chapters === 'boolean') {


      outlineChapterStatusCache.set(outline.id, outline.has_chapters);


      return outline.has_chapters;


    }


    const cachedStatus = outlineChapterStatusCache.get(outline.id);


    if (typeof cachedStatus === 'boolean') {


      return cachedStatus;


    }


    const existingRequest = outlineChapterStatusPromises.get(outline.id);


    if (existingRequest) {


      return existingRequest;


    }


    const request = (async () => {


      const chapters = await outlineApi.getOutlineChapters(outline.id);


      outlineChapterStatusCache.set(outline.id, chapters.has_chapters);


      return chapters.has_chapters;


    })();


    outlineChapterStatusPromises.set(outline.id, request);


    try {


      return await request;


    } finally {


      outlineChapterStatusPromises.delete(outline.id);


    }


  };


  // 按可见项渐进查询展开状态


  // 避免首屏对全部大纲并发查询


  // 确保大纲按 order_index 排序


  const sortedOutlines = useMemo(


    () => [...outlines].sort((a, b) => a.order_index - b.order_index),


    [outlines]


  );


  useEffect(() => {


    setVisibleOutlineCount(Math.min(sortedOutlines.length, INITIAL_OUTLINE_RENDER_COUNT));


  }, [currentProject?.id, sortedOutlines.length]);


  useEffect(() => {


    if (visibleOutlineCount >= sortedOutlines.length) {


      return;


    }


    let timerId: number | null = null;


    const windowWithIdleCallback = window as Window & typeof globalThis & {


      requestIdleCallback?: (callback: IdleRequestCallback, options?: IdleRequestOptions) => number;


      cancelIdleCallback?: (handle: number) => void;


    };


    let idleHandle: number | null = null;


    const expandVisibleOutlines = () => {


      setVisibleOutlineCount((prev) => {


        if (prev >= sortedOutlines.length) {


          return prev;


        }


        return Math.min(sortedOutlines.length, prev + OUTLINE_RENDER_BATCH_SIZE);


      });


    };


    if (typeof windowWithIdleCallback.requestIdleCallback === 'function') {


      idleHandle = windowWithIdleCallback.requestIdleCallback(() => {


        idleHandle = null;


        expandVisibleOutlines();


      }, { timeout: OUTLINE_RENDER_BATCH_DELAY_MS * 4 });


    } else {


      timerId = window.setTimeout(() => {


        timerId = null;


        expandVisibleOutlines();


      }, OUTLINE_RENDER_BATCH_DELAY_MS);


    }


    return () => {


      if (idleHandle !== null && typeof windowWithIdleCallback.cancelIdleCallback === 'function') {


        windowWithIdleCallback.cancelIdleCallback(idleHandle);


      }


      if (timerId !== null) {


        window.clearTimeout(timerId);


      }


    };


  }, [sortedOutlines.length, visibleOutlineCount]);


  const visibleOutlines = useMemo(


    () => sortedOutlines.slice(0, visibleOutlineCount),


    [sortedOutlines, visibleOutlineCount]


  );


  useEffect(() => {


    let cancelled = false;


    let timerId: number | null = null;


    const windowWithIdleCallback = window as Window & typeof globalThis & {


      requestIdleCallback?: (callback: IdleRequestCallback, options?: IdleRequestOptions) => number;


      cancelIdleCallback?: (handle: number) => void;


    };


    let idleHandle: number | null = null;


    const loadExpandStatus = async () => {


      if (visibleOutlines.length === 0) {


        setOutlineExpandStatus({});


        return;


      }


      const knownStatusEntries = visibleOutlines


        .filter((outline) => typeof outline.has_chapters === 'boolean')


        .map((outline) => [outline.id, Boolean(outline.has_chapters)] as const);


      if (knownStatusEntries.length > 0) {


        setOutlineExpandStatus((prev) => ({


          ...prev,


          ...Object.fromEntries(knownStatusEntries),


        }));


      }


      const outlinesNeedingFetch = visibleOutlines.filter((outline) => typeof outline.has_chapters !== 'boolean');


      if (outlinesNeedingFetch.length === 0) {


        return;


      }


      const statusEntries = await Promise.all(


        outlinesNeedingFetch.map(async (outline) => {


          try {


            return [outline.id, await getOutlineHasChapters(outline)] as const;


          } catch (error) {


            console.error(`获取大纲 ${outline.id} 展开状态失败:`, error);


            return [outline.id, false] as const;


          }


        })


      );


      if (!cancelled) {


        setOutlineExpandStatus((prev) => ({


          ...prev,


          ...Object.fromEntries(statusEntries),


        }));


      }


    };


    const scheduleLoadExpandStatus = () => {


      if (typeof windowWithIdleCallback.requestIdleCallback === 'function') {


        idleHandle = windowWithIdleCallback.requestIdleCallback(() => {


          idleHandle = null;


          if (!cancelled) {


            void loadExpandStatus();


          }


        }, { timeout: 500 });


        return;


      }


      timerId = window.setTimeout(() => {


        timerId = null;


        if (!cancelled) {


          void loadExpandStatus();


        }


      }, OUTLINE_RENDER_BATCH_DELAY_MS);


    };


    scheduleLoadExpandStatus();


    return () => {


      cancelled = true;


      if (idleHandle !== null && typeof windowWithIdleCallback.cancelIdleCallback === 'function') {


        windowWithIdleCallback.cancelIdleCallback(idleHandle);


      }


      if (timerId !== null) {


        window.clearTimeout(timerId);


      }


    };


  }, [visibleOutlines]);


  const outlineItemStyle = useMemo(() => ({


    marginBottom: 16,


    padding: 0,


    border: 'none',


    contentVisibility: 'auto' as const,


    containIntrinsicSize: isMobile ? '560px' : '520px',


  }), [isMobile]);


  const parsedOutlineViewDataById = useMemo(() => {


    const parsedMap = new Map<string, ParsedOutlineViewData>();


    visibleOutlines.forEach((outline) => {


      const structureData = parseOutlineStructure(outline.structure);


      const characterEntries = parseCharacterEntries(structureData.characters);


      parsedMap.set(outline.id, {


        structureData,


        characterNames: getCharacterNames(characterEntries),


        organizationNames: getOrganizationNames(characterEntries),


      });


    });


    return parsedMap;


  }, [visibleOutlines]);


  const handleOpenEditModal = (id: string) => {


    const outline = outlines.find(o => o.id === id);


    if (outline) {


      ensureProjectCharactersLoaded(outline.project_id);


      // 解析structure数据


      const structureData = parseOutlineStructure(outline.structure);


      const editEntries = parseCharacterEntries(structureData.characters);


      const editCharNames = getCharacterNames(editEntries);


      const editOrgNames = getOrganizationNames(editEntries);


      


      // 处理场景数据 - 可能是字符串数组或对象数组


      let scenesText = '';


      if (structureData.scenes) {


        if (typeof structureData.scenes[0] === 'string') {


          // 字符串数组格式


          scenesText = (structureData.scenes as string[]).join('\n');


        } else {


          // 对象数组格式


          scenesText = (structureData.scenes as Array<{location: string; characters: string[]; purpose: string}>)


            .map(s => `${s.location}|${(s.characters || []).join('、')}|${s.purpose}`)


            .join('\n');


        }


      }


      


      // 处理情节要点数据


      const keyPointsText = structureData.key_points ? structureData.key_points.join('\n') : '';


      


      // 设置表单初始值


      editForm.setFieldsValue({


        title: outline.title,


        content: outline.content,


        characters: editCharNames,


        organizations: editOrgNames,


        scenes: scenesText,


        key_points: keyPointsText,


        emotion: structureData.emotion || '',


        goal: structureData.goal || ''


      });


      


      modalApi.confirm({


        title: '编辑大纲',


        width: 800,


        centered: true,


        styles: {


          body: {


            maxHeight: 'calc(100vh - 200px)',


            overflowY: 'auto'


          }


        },


        content: (


          <Form


            form={editForm}


            layout="vertical"


            style={{ marginTop: 12 }}


          >


            <Form.Item


              label="标题"


              name="title"


              rules={[{ required: true, message: '请输入标题' }]}


              style={{ marginBottom: 12 }}


            >


              <Input placeholder="输入大纲标题" />


            </Form.Item>


            <Form.Item


              label="内容"


              name="content"


              rules={[{ required: true, message: '请输入内容' }]}


              style={{ marginBottom: 12 }}


            >


              <TextArea rows={4} placeholder="输入大纲内容..." />


            </Form.Item>


            


            <Form.Item


              label="涉及角色"


              name="characters"


              tooltip="从项目角色中选择，也可以手动输入新角色名"


              style={{ marginBottom: 12 }}


            >


              <Select


                mode="tags"


                style={{ width: '100%' }}


                placeholder="选择或输入角色名"


                options={projectCharacters}


                tokenSeparators={[',', '，']}


                maxTagCount="responsive"


              />


            </Form.Item>


            


            <Form.Item


              label="涉及组织"


              name="organizations"


              tooltip="从项目组织中选择，也可以手动输入新组织名"


              style={{ marginBottom: 12 }}


            >


              <Select


                mode="tags"


                style={{ width: '100%' }}


                placeholder="选择或输入组织/势力名"


                tokenSeparators={[',', '，']}


                maxTagCount="responsive"


              />


            </Form.Item>


            


            <Form.Item


              label="场景信息"


              name="scenes"


              tooltip="支持两种格式：简单描述（每行一个场景）或详细格式（地点|角色|目的）"


              style={{ marginBottom: 12 }}


            >


              <TextArea


                rows={3}


                placeholder="每行一个场景&#10;详细格式：地点|角色1、角色2|目的"


              />


            </Form.Item>


            


            <Form.Item


              label="情节要点"


              name="key_points"


              tooltip="每行一个情节要点"


              style={{ marginBottom: 12 }}


            >


              <TextArea


                rows={2}


                placeholder="每行一个情节要点"


              />


            </Form.Item>


            


            <Form.Item


              label="情感基调"


              name="emotion"


              tooltip="描述本章的情感氛围"


              style={{ marginBottom: 12 }}


            >


              <Input placeholder="例如：冷冽与躁动并存" />


            </Form.Item>


            


            <Form.Item


              label="叙事目标"


              name="goal"


              tooltip="本章要达成的叙事目的"


              style={{ marginBottom: 0 }}


            >


              <Input placeholder="例如：建立世界观对比并完成主角初遇" />


            </Form.Item>


          </Form>


        ),


        okText: '更新',


        cancelText: '取消',


        onOk: async () => {


          const values = await editForm.validateFields();


          try {


            // 解析并重构structure数据


            const originalStructure = outline.structure ? JSON.parse(outline.structure) : {};


            


            // 处理角色和组织数据 - 合并为带类型标识的新格式


            const charNames = Array.isArray(values.characters)


              ? values.characters.filter((c: string) => c && c.trim())


              : [];


            const orgNames = Array.isArray(values.organizations)


              ? values.organizations.filter((c: string) => c && c.trim())


              : [];


            const characters: CharacterEntry[] = [


              ...charNames.map((name: string) => ({ name: name.trim(), type: 'character' as const })),


              ...orgNames.map((name: string) => ({ name: name.trim(), type: 'organization' as const }))


            ];


            


            // 处理场景数据 - 检测原始格式


            let scenes: string[] | Array<{location: string; characters: string[]; purpose: string}> | undefined;


            if (values.scenes) {


              const lines = values.scenes.split('\n')


                .map((line: string) => line.trim())


                .filter((line: string) => line);


              


              // 检查是否包含管道符，判断格式


              const hasStructuredFormat = lines.some((line: string) => line.includes('|'));


              


              if (hasStructuredFormat) {


                // 尝试解析为对象数组格式


                scenes = lines


                  .map((line: string) => {


                    const parts = line.split('|');


                    if (parts.length >= 3) {


                      return {


                        location: parts[0].trim(),


                        characters: parts[1].split('、').map(c => c.trim()).filter(c => c),


                        purpose: parts[2].trim()


                      };


                    }


                    return null;


                  })


                  .filter((s: { location: string; characters: string[]; purpose: string } | null): s is { location: string; characters: string[]; purpose: string } => s !== null);


              } else {


                // 保持字符串数组格式


                scenes = lines;


              }


            }


            


            // 处理情节要点数据


            const keyPoints = values.key_points


              ? values.key_points.split('\n')


                  .map((line: string) => line.trim())


                  .filter((line: string) => line)


              : undefined;


            


            // 合并structure数据，只包含AI实际生成的字段


            const newStructure = {


              ...originalStructure,


              title: values.title,


              summary: values.content,


              characters: characters.length > 0 ? characters : undefined,


              scenes: scenes && scenes.length > 0 ? scenes : undefined,


              key_points: keyPoints && keyPoints.length > 0 ? keyPoints : undefined,


              emotion: values.emotion || undefined,


              goal: values.goal || undefined


            };


            


            // 更新大纲


            await updateOutline(id, {


              title: values.title,


              content: values.content,


              structure: JSON.stringify(newStructure, null, 2)


            });


            


            message.success('大纲更新成功');


          } catch (error) {


            console.error('更新失败:', error);


            message.error('更新失败');


          }


        },


      });


    }


  };


  const handleDeleteOutline = async (id: string) => {


    try {


      await deleteOutline(id);


      message.success('删除成功');


      // 删除后刷新大纲列表和项目信息，更新字数显示


      await refreshOutlines();


      if (currentProject?.id) {


        const updatedProject = await projectApi.getProject(currentProject.id);


        setCurrentProject(updatedProject);


      }


    } catch {


      message.error('删除失败');


    }


  };


  interface GenerateFormValues {


    theme?: string;


    chapter_count?: number;


    narrative_perspective?: string;


    requirements?: string;


    provider?: string;


    model?: string;


    creative_mode?: CreativeMode;


    story_focus?: StoryFocus;


    story_creation_brief?: string;


    quality_preset?: QualityPreset;


    quality_notes?: string;


    mode?: 'auto' | 'new' | 'continue';


    story_direction?: string;


    plot_stage?: 'development' | 'climax' | 'ending';


    keep_existing?: boolean;


    enable_web_research?: boolean;


    web_research_query?: string;


  }


  const handleGenerate = async (values: GenerateFormValues) => {


    try {


      const activeProject = currentProject;


      if (!activeProject) {


        message.error('当前项目不存在');


        return;


      }


      setIsGenerating(true);


      // 添加详细的调试日志


      console.log('=== 大纲生成调试信息 ===');


      console.log('1. Form values 原始数据:', values);


      console.log('2. values.model:', values.model);


      console.log('3. values.provider:', values.provider);


      // 显示进度Modal


      setSSEProgress(0);


      setSSEMessage('正在连接生成服务...');


      setSSEModalVisible(true);


      // 准备请求数据


      const requestData: OutlineGenerateRequestData = {


        project_id: activeProject.id,


        genre: activeProject.genre || '通用',


        theme: values.theme || activeProject.theme || '',


        chapter_count: values.chapter_count || 5,


        narrative_perspective: values.narrative_perspective || activeProject.narrative_perspective || '第三人称',


        target_words: activeProject.target_words || 100000,


        requirements: values.requirements,


        creative_mode: values.creative_mode ?? projectDefaultCreativeMode,


        story_focus: values.story_focus ?? projectDefaultStoryFocus,


        story_creation_brief: values.story_creation_brief ?? projectDefaultStoryCreationBrief,


        quality_preset: values.quality_preset ?? projectDefaultQualityPreset,


        quality_notes: values.quality_notes ?? projectDefaultQualityNotes,


        mode: values.mode || 'auto',


        enable_web_research: values.enable_web_research,


        web_research_query: values.web_research_query,


        story_direction: values.story_direction,


        plot_stage: values.plot_stage || projectDefaultPlotStage || 'development'


      };


      // 只有在用户选择了模型时才添加model参数


      if (values.model) {


        requestData.model = values.model;


        console.log('4. 添加model到请求:', values.model);


      } else {


        console.log('4. values.model为空，不添加到请求');


      }


      // 添加provider参数（如果有）


      if (values.provider) {


        requestData.provider = values.provider;


        console.log('5. 添加provider到请求:', values.provider);


      }


      console.log('6. 最终请求数据:', JSON.stringify(requestData, null, 2));


      console.log('=========================');


      const payload: Record<string, unknown> = { ...requestData };


      delete payload.project_id;


      const task = await backgroundTaskApi.createTask({


        task_type: 'outline_generate',


        project_id: activeProject.id,


        payload,


      });


      message.success('大纲生成任务已转为后台执行，可继续进行其他操作');


      startGenerateTaskPolling(task.task_id);


    } catch (error) {


      const generateErrorMessage = getApiErrorMessage(error, '智能生成失败');
      console.error('AI生成失败:', {
        error,
        context: buildOutlineGenerateLogContext({
          stage: 'create-generate-task',
          formMode: values.mode || 'auto',
          selectedModel: values.model || null,
          selectedProvider: values.provider || null,
          projectGenre: currentProject?.genre || null,
        }),
      });


      message.error(generateErrorMessage);


      stopGenerateTaskPolling();


      generateTaskIdRef.current = null;


      setSSEModalVisible(false);


      setIsGenerating(false);


    }


  };


  const showGenerateModal = async () => {

    if (isGenerating || hasActiveTrackedOutlineGenerateTask) {
      message.info('当前已有任务执行中，请稍候');
      return;
    }

    try {
      const hasOutlines = outlines.length > 0;

      const { settings, storedApiKey: api_key } = await settingsApi.getSettingsWithStoredApiKey();

      const { api_base_url, api_provider, provider_type } = settings;

      let loadedModels: Array<{ value: string, label: string }> = [];

      let defaultModel: string | undefined = undefined;

      if (hasUsableApiCredentials(api_key, api_base_url)) {
        try {
          const modelResponse = await settingsApi.getAvailableModels({
            api_key,
            api_base_url,
            provider: provider_type || api_provider || 'openai',
          });

          if (Array.isArray(modelResponse.models) && modelResponse.models.length > 0) {
            loadedModels = modelResponse.models;
            defaultModel = settings.llm_model;
          }
        } catch (modelError) {
          const modelErrorMessage = getApiErrorMessage(modelError, '获取模型列表失败，将使用默认模型');
          console.error('获取模型列表失败，将使用默认模型', {
            error: modelError,
            context: buildOutlineGenerateLogContext({
              stage: 'load-models',
              apiProvider: provider_type || api_provider || 'openai',
              hasApiKey: Boolean(api_key),
              hasApiBaseUrl: Boolean(api_base_url),
              defaultModel: settings.llm_model || null,
            }),
          });
          message.warning(modelErrorMessage);
        }
      }

      modalApi.confirm({
        title: hasOutlines ? (
          <Space>
            <span>智能生成/续写大纲</span>
            <Tag color="blue">当前已有 {outlines.length} 章</Tag>
          </Space>
        ) : '智能生成大纲',

        width: isMobile ? 'calc(100vw - 32px)' : 860,

        centered: true,

        content: (
          <InlineErrorBoundary
            fallback={(
              <div style={{ padding: '16px 0', textAlign: 'center' }}>
                大纲生成面板加载失败，请关闭后重试。
              </div>
            )}
          >
            <Suspense fallback={outlineLazyFallback}>
              <LazyOutlineGenerateModalContent
                generateForm={generateForm}
                currentProject={currentProject}
                outlinesCount={outlines.length}
                loadedModels={loadedModels}
                defaultModel={defaultModel}
                projectDefaultCreativeMode={projectDefaultCreativeMode}
                projectDefaultStoryFocus={projectDefaultStoryFocus}
                projectDefaultPlotStage={projectDefaultPlotStage}
                projectDefaultStoryCreationBrief={projectDefaultStoryCreationBrief}
                projectDefaultQualityPreset={projectDefaultQualityPreset}
                projectDefaultQualityNotes={projectDefaultQualityNotes}
              />
            </Suspense>
          </InlineErrorBoundary>
        ),

        okText: hasOutlines ? '开始续写' : '开始生成',

        cancelText: '取消',

        onOk: async () => {
          const values = await generateForm.validateFields();
          await handleGenerate(values);
        },
      });
    } catch (error) {
      const openModalErrorMessage = getApiErrorMessage(error, '打开大纲生成面板失败，请稍后重试');
      console.error('打开大纲生成弹窗失败', {
        error,
        context: buildOutlineGenerateLogContext({
          stage: 'open-generate-modal',
        }),
      });
      message.error(openModalErrorMessage);
    }
  };


  const showManualCreateOutlineModal = () => {


    const nextOrderIndex = outlines.length > 0


      ? Math.max(...outlines.map(o => o.order_index)) + 1


      : 1;


    modalApi.confirm({


      title: '手动创建大纲',


      width: 600,


      centered: true,


      content: (


        <Form


          form={manualCreateForm}


          layout="vertical"


          initialValues={{ order_index: nextOrderIndex }}


          style={{ marginTop: 16 }}


        >


          <Form.Item


            label="大纲序号"


            name="order_index"


            rules={[{ required: true, message: '请输入序号' }]}


            tooltip={currentProject?.outline_mode === 'one-to-one' ? '在传统模式下，序号即章节编号' : '在细化模式下，序号为卷数'}


          >


            <InputNumber min={1} style={{ width: '100%' }} placeholder="自动计算的下一个序号" />


          </Form.Item>


          <Form.Item


            label="大纲标题"


            name="title"


            rules={[{ required: true, message: '请输入标题' }]}


          >


            <Input placeholder={currentProject?.outline_mode === 'one-to-one' ? '例如：第一章 初入江湖' : '例如：第一卷 初入江湖'} />


          </Form.Item>


          <Form.Item


            label="大纲内容"


            name="content"


            rules={[{ required: true, message: '请输入内容' }]}


          >


            <TextArea


              rows={6}


              placeholder="描述本章/卷的主要情节和发展方向..."


            />


          </Form.Item>


        </Form>


      ),


      okText: '创建',


      cancelText: '取消',


      onOk: async () => {


        const values = await manualCreateForm.validateFields();


        // 校验序号是否重复


        const existingOutline = outlines.find(o => o.order_index === values.order_index);


        if (existingOutline) {


          modalApi.warning({


            title: '序号冲突',


            content: (


              <div>


                <p>序号 <strong>{values.order_index}</strong> 已被使用：</p>


                <div style={{


                  padding: 12,


                  background: 'var(--color-warning-bg)',


                  borderRadius: 4,


                  border: '1px solid var(--color-warning-border)',


                  marginTop: 8


                }}>


                  <div style={{ fontWeight: 500, color: 'var(--color-warning)' }}>


                    {currentProject?.outline_mode === 'one-to-one'


                      ? `第${existingOutline.order_index}章`


                      : `第${existingOutline.order_index}卷`


                    }：{existingOutline.title}


                  </div>


                </div>


                <p style={{ marginTop: 12, color: 'var(--color-text-secondary)' }}>


                  💡 建议使用序号 <strong>{nextOrderIndex}</strong>，或选择其他未使用的序号


                </p>


              </div>


            ),


            okText: '我知道了',


            centered: true


          });


          throw new Error('序号重复');


        }


        try {


          const activeProject = currentProject;


          if (!activeProject) {


            message.error('当前项目不存在');


            return;


          }


          await outlineApi.createOutline({


            project_id: activeProject.id,


            ...values


          });


          message.success('大纲创建成功');


          await refreshOutlines();


          manualCreateForm.resetFields();


        } catch (error: unknown) {


          const err = error as Error;


          if (err.message === '序号重复') {


            // 序号重复错误已经显示了Modal，不需要再显示message


            throw error;


          }


          message.error('创建失败：' + (err.message || '未知错误'));


          throw error;


        }


      }


    });


  };


  // 展开单个大纲为多章 - 使用SSE显示进度


  const handleExpandOutline = async (outlineId: string, outlineTitle: string) => {

    if (isExpanding || hasActiveTrackedOutlineExpandTask) {
      message.info('当前已有任务执行中，请稍候');
      return;
    }



    try {


      setIsExpanding(true);


      // ✅ 新增：检查是否需要按顺序展开


      const currentOutline = sortedOutlines.find(o => o.id === outlineId);


      if (currentOutline) {


        // 获取所有在当前大纲之前的大纲


        const previousOutlines = sortedOutlines.filter(


          o => o.order_index < currentOutline.order_index


        );


        // 检查前面的大纲是否都已展开


        for (const prevOutline of previousOutlines) {


          try {


            const prevChapters = await outlineApi.getOutlineChapters(prevOutline.id);


            if (!prevChapters.has_chapters) {


              // 如果前面有未展开的大纲，显示提示并阻止操作


              setIsExpanding(false);


              modalApi.warning({


                title: '请按顺序展开大纲',


                width: 600,


                centered: true,


                content: (


                  <div>


                    <p style={{ marginBottom: 12 }}>


                      为了保持章节编号的连续性和内容的连贯性，请先展开前面的大纲。


                    </p>


                    <div style={{


                      padding: 12,


                      background: 'var(--color-warning-bg)',


                      borderRadius: 4,


                      border: '1px solid var(--color-warning-border)'


                    }}>


                      <div style={{ fontWeight: 500, marginBottom: 8, color: 'var(--color-warning)' }}>


                        ⚠️ 需要先展开：


                      </div>


                      <div style={{ color: 'var(--color-text-secondary)' }}>


                        第{prevOutline.order_index}卷：《{prevOutline.title}》


                      </div>


                    </div>


                    <p style={{ marginTop: 12, color: 'var(--color-text-secondary)', fontSize: 13 }}>


                      💡 提示：您也可以使用「批量展开」功能，系统会自动按顺序处理所有大纲。


                    </p>


                  </div>


                ),


                okText: '我知道了'


              });


              return;


            }


          } catch (error) {


            console.error(`检查大纲 ${prevOutline.id} 失败:`, error);


            // 如果检查失败，继续处理（避免因网络问题阻塞）


          }


        }


      }


      // 第一步：检查是否已有展开的章节


      const existingChapters = await outlineApi.getOutlineChapters(outlineId);


      if (existingChapters.has_chapters && existingChapters.expansion_plans && existingChapters.expansion_plans.length > 0) {


        // 如果已有章节，显示已有的展开规划信息


        setIsExpanding(false);


        showExistingExpansionPreview(outlineTitle, existingChapters);


        return;


      }


      // 如果没有章节，显示展开表单


      setIsExpanding(false);


      modalApi.confirm({


        title: (


          <Space>


            <BranchesOutlined />


            <span>展开大纲为多章</span>


          </Space>


        ),


        width: 600,


        centered: true,


        content: (


          <div>


            <div style={{ marginBottom: 16, padding: 12, background: 'var(--color-bg-layout)', borderRadius: 4 }}>


              <div style={{ fontWeight: 500, marginBottom: 4 }}>大纲标题</div>


              <div style={{ color: 'var(--color-text-secondary)' }}>{outlineTitle}</div>


            </div>


            <Form


              form={expansionForm}


              layout="vertical"


              initialValues={{


                target_chapter_count: 3,


                expansion_strategy: 'balanced',


              }}


            >


              <Form.Item


                label="目标章节数"


                name="target_chapter_count"


                rules={[{ required: true, message: '请输入目标章节数' }]}


                tooltip="将这个大纲展开为几章内容"


              >


                <InputNumber


                  min={2}


                  max={10}


                  style={{ width: '100%' }}


                  placeholder="建议2-5章"


                />


              </Form.Item>


              <Form.Item


                label="展开策略"


                name="expansion_strategy"


                tooltip="选择如何分配内容到各章节"


              >


                <Radio.Group>


                  <Radio.Button value="balanced">均衡分配</Radio.Button>


                  <Radio.Button value="climax">高潮重点</Radio.Button>


                  <Radio.Button value="detail">细节丰富</Radio.Button>


                </Radio.Group>


              </Form.Item>


            </Form>


          </div>


        ),


        okText: '生成规划预览',


        cancelText: '取消',


        onOk: async () => {


          try {


            const values = await expansionForm.validateFields();


            // 显示SSE进度Modal


            setSSEProgress(0);


            setSSEMessage('正在准备展开大纲...');


            setSSEModalVisible(true);


            setIsExpanding(true);


            // 准备请求数据


            const requestData = {


              ...values,


              auto_create_chapters: false, // 第一步：仅生成规划


              enable_scene_analysis: values.enable_scene_analysis ?? true


            };


            const activeProject = currentProject;


            if (!activeProject) {


              message.error('当前项目不存在');


              return;


            }


            const task = await backgroundTaskApi.createTask({


              task_type: 'outline_expand',


              project_id: activeProject.id,


              payload: {


                outline_id: outlineId,


                ...requestData,


              },


            });


            message.success('大纲展开任务已转为后台执行，可继续进行其他操作');


            expandTaskIdRef.current = task.task_id;
            startExpandTaskPolling(task.task_id);


          } catch (error) {


            console.error('展开失败:', error);


            message.error('展开失败');


            stopExpandTaskPolling();


            expandTaskIdRef.current = null;


            setSSEModalVisible(false);


            setIsExpanding(false);


          }


        },


      });


    } catch (error) {


      console.error('检查章节失败:', error);


      message.error('检查章节失败');


      setIsExpanding(false);


    }


  };


  // 删除展开的章节内容（保留大纲）


  const handleDeleteExpandedChapters = async (outlineTitle: string, chapters: Array<{ id: string }>) => {


    try {


      // 使用顺序删除避免并发导致的字数计算竞态条件


      // 并发删除会导致多个请求同时读取项目字数并各自减去章节字数，造成计算错误


      for (const chapter of chapters) {


        await chapterApi.deleteChapter(chapter.id);


      }


      message.success(`已删除《${outlineTitle}》展开的所有 ${chapters.length} 个章节`);


      await refreshOutlines();


      // 刷新项目信息以更新字数显示


      if (currentProject?.id) {


        const updatedProject = await projectApi.getProject(currentProject.id);


        setCurrentProject(updatedProject);


      }


      // 更新展开状态


      setOutlineExpandStatus(prev => {


        const newStatus = { ...prev };


        // 找到被删除章节对应的大纲ID并更新其状态


        const outlineId = Object.keys(newStatus).find(id =>


          outlines.find(o => o.id === id && o.title === outlineTitle)


        );


        if (outlineId) {


          newStatus[outlineId] = false;


        }


        return newStatus;


      });


    } catch (error: unknown) {


      const apiError = error as ApiError;


      message.error(apiError.response?.data?.detail || '删除章节失败');


    }


  };


  // 显示已存在章节的展开规划


  const showExistingExpansionPreview = (


    outlineTitle: string,


    data: {


      chapter_count: number;


      chapters: Array<{ id: string; chapter_number: number; title: string }>;


      expansion_plans: Array<{


        sub_index: number;


        title: string;


        plot_summary: string;


        key_events: string[];


        character_focus: string[];


        emotional_tone: string;


        narrative_goal: string;


        conflict_type: string;


        estimated_words: number;


        scenes?: Array<{


          location: string;


          characters: string[];


          purpose: string;


        }> | null;


      }> | null;


    }


  ) => {


    modalApi.info({


      title: (


        <Space style={{ flexWrap: 'wrap' }}>


          <CheckCircleOutlined style={{ color: 'var(--color-success)' }} />


          <span>《{outlineTitle}》展开信息</span>


        </Space>


      ),


      width: isMobile ? '95%' : 900,


      centered: true,


      style: isMobile ? {


        top: 20,


        maxWidth: 'calc(100vw - 16px)',


        margin: '0 8px'


      } : undefined,


      styles: {


        body: {


          maxHeight: isMobile ? 'calc(100vh - 200px)' : 'calc(80vh - 60px)',


          overflowY: 'auto',


          overflowX: 'hidden'


        }


      },


      footer: (


        <Space wrap style={{ width: '100%', justifyContent: isMobile ? 'center' : 'flex-end' }}>


          <Button


            danger


            icon={<DeleteOutlined />}


            onClick={() => {


              Modal.destroyAll();


              modalApi.confirm({


                title: '确认删除',


                icon: <ExclamationCircleOutlined />,


                centered: true,


                content: (


                  <div>


                    <p>此操作将删除大纲《{outlineTitle}》展开的所有 <strong>{data.chapter_count}</strong> 个章节。</p>


                    <p style={{ color: 'var(--color-primary)', marginTop: 8 }}>


                      📝 注意：大纲本身会保留，您可以重新展开


                    </p>


                    <p style={{ color: '#ff4d4f', marginTop: 8 }}>


                      ⚠️ 警告：章节内容将永久删除且无法恢复！


                    </p>


                  </div>


                ),


                okText: '确认删除',


                okType: 'danger',


                cancelText: '取消',


                onOk: () => handleDeleteExpandedChapters(outlineTitle, data.chapters || []),


              });


            }}


            block={isMobile}


            size={isMobile ? 'middle' : undefined}


          >


            删除所有展开的章节 ({data.chapter_count}章)


          </Button>


          <Button onClick={() => Modal.destroyAll()}>


            关闭


          </Button>


        </Space>


      ),


      content: (
        <InlineErrorBoundary
          fallback={(
            <div style={{ padding: '16px 0', textAlign: 'center' }}>
              已有展开规划面板加载失败，请关闭后重试。
            </div>
          )}
        >
          <Suspense fallback={outlineLazyFallback}>
            <LazyOutlineExistingExpansionContent
              outlineTitle={outlineTitle}
              data={data}
              isMobile={isMobile}
            />
          </Suspense>
        </InlineErrorBoundary>
      ),


    });


  };


  // 确认创建章节 - 使用缓存的规划数据，避免重复AI调用


  const handleConfirmCreateChapters = async (


    outlineId: string,


    cachedPlans: ChapterPlanItem[]


  ) => {


    try {


      setIsExpanding(true);


      // 使用新的API端点，直接传递缓存的规划数据


      const response = await outlineApi.createChaptersFromPlans(outlineId, cachedPlans);


      message.success(


        `成功创建${response.chapters_created}个章节！`,


        3


      );


      console.log('✅ 使用缓存的规划创建章节，避免了重复的AI调用');


      // 刷新大纲和章节列表


      refreshOutlines();


    } catch (error) {


      console.error('创建章节失败:', error);


      message.error('创建章节失败');


    } finally {


      setIsExpanding(false);


    }


  };


  // 批量展开所有大纲 - 使用SSE流式显示进度


  const handleBatchExpandOutlines = () => {

    if (isExpanding || hasActiveTrackedOutlineExpandTask) {
      message.info('当前已有任务执行中，请稍候');
      return;
    }



    if (!currentProject?.id || outlines.length === 0) {


      message.warning('没有可展开的大纲');


      return;


    }


    modalApi.confirm({


      title: (


        <Space>


          <AppstoreAddOutlined />


          <span>批量展开所有大纲</span>


        </Space>


      ),


      width: 600,


      centered: true,


      content: (
        <InlineErrorBoundary
          fallback={(
            <div style={{ padding: '16px 0', textAlign: 'center' }}>
              批量展开配置面板加载失败，请关闭后重试。
            </div>
          )}
        >
          <Suspense fallback={outlineLazyFallback}>
            <LazyOutlineBatchExpandConfigForm
              form={batchExpansionForm}
              outlineCount={outlines.length}
            />
          </Suspense>
        </InlineErrorBoundary>
      ),


      okText: '开始展开',


      cancelText: '取消',


      okButtonProps: { type: 'primary' },


      onOk: async () => {


        try {


          const values = await batchExpansionForm.validateFields();


          // 显示SSE进度Modal


          setSSEProgress(0);


          setSSEMessage('正在准备批量展开...');


          setSSEModalVisible(true);


          setIsExpanding(true);


          // 准备请求数据


          const requestData = {


            project_id: currentProject.id,


            ...values,


            auto_create_chapters: false, // 第一步：仅生成规划

            enable_scene_analysis: values.enable_scene_analysis ?? true


          };


          const payload: Record<string, unknown> = { ...requestData };


          delete payload.project_id;


          const task = await backgroundTaskApi.createTask({


            task_type: 'outline_batch_expand',


            project_id: currentProject.id,


            payload,


          });


          message.success('批量展开任务已转为后台执行，可继续进行其他操作');


          expandTaskIdRef.current = task.task_id;
          startExpandTaskPolling(task.task_id);


        } catch (error) {


          console.error('批量展开失败:', error);


          message.error('批量展开失败');


          stopExpandTaskPolling();


          expandTaskIdRef.current = null;


          setSSEModalVisible(false);


          setIsExpanding(false);


        }


      },


    });


  };


  const handleSinglePreviewOk = async () => {
    if (!singlePreviewOutlineId || !singlePreviewData) {
      message.error('规划数据丢失，请重新展开');
      setSinglePreviewVisible(false);
      setSinglePreviewOutlineId(null);
      setSinglePreviewData(null);
      return;
    }

    setSinglePreviewVisible(false);
    await handleConfirmCreateChapters(singlePreviewOutlineId, singlePreviewData.chapter_plans);
    setSinglePreviewOutlineId(null);
    setSinglePreviewData(null);
  };


  const handleSinglePreviewCancel = () => {
    setSinglePreviewVisible(false);
    setSinglePreviewOutlineId(null);
    setSinglePreviewData(null);
    message.info('已取消创建章节');
  };


  // 渲染批量展开预览 Modal 内容


  const handleBatchPreviewOk = async () => {


    setBatchPreviewVisible(false);


    await handleConfirmBatchCreateChapters();


  };


  // 处理批量预览取消


  const handleBatchPreviewCancel = () => {


    setBatchPreviewVisible(false);


    message.info('已取消创建章节，规划已保存');


  };


  // 确认批量创建章节 - 使用缓存的规划数据


  const handleConfirmBatchCreateChapters = async () => {


    try {


      setIsExpanding(true);


      // 使用缓存的规划数据，避免重复调用AI


      if (!cachedBatchExpansionResponse) {


        message.error('规划数据丢失，请重新展开');


        return;


      }


      console.log('✅ 使用缓存的批量规划数据创建章节，避免重复AI调用');


      // 逐个大纲创建章节


      let totalCreated = 0;


      const errors: string[] = [];


      for (const result of cachedBatchExpansionResponse.expansion_results) {


        try {


          // 使用create-chapters-from-plans接口，直接传递缓存的规划


          const response = await outlineApi.createChaptersFromPlans(


            result.outline_id,


            result.chapter_plans


          );


          totalCreated += response.chapters_created;


        } catch (error: unknown) {


          const apiError = error as ApiError;


          const err = error as Error;


          const errorMsg = apiError.response?.data?.detail || err.message || '未知错误';


          errors.push(`${result.outline_title}: ${errorMsg}`);


          console.error(`创建大纲 ${result.outline_title} 的章节失败:`, error);


        }


      }


      // 显示结果


      if (errors.length === 0) {


        message.success(


          `批量创建完成！共创建 ${totalCreated} 个章节`,


          3


        );


      } else {


        message.warning(


          `部分完成：成功创建 ${totalCreated} 个章节，${errors.length} 个失败`,


          5


        );


        console.error('失败详情:', errors);


      }


      // 清除缓存


      setCachedBatchExpansionResponse(null);


      // 刷新列表


      refreshOutlines();


    } catch (error) {


      console.error('批量创建章节失败:', error);


      message.error('批量创建章节失败');


    } finally {


      setIsExpanding(false);


    }


  };


  const handleOpenEditModalRef = useRef(handleOpenEditModal);


  const handleDeleteOutlineRef = useRef(handleDeleteOutline);


  const handleExpandOutlineRef = useRef(handleExpandOutline);


  handleOpenEditModalRef.current = handleOpenEditModal;


  handleDeleteOutlineRef.current = handleDeleteOutline;


  handleExpandOutlineRef.current = handleExpandOutline;


  const openEditModalFromList = useCallback((id: string) => {


    handleOpenEditModalRef.current(id);


  }, []);


  const deleteOutlineFromList = useCallback((id: string) => {


    return handleDeleteOutlineRef.current(id);


  }, []);


  const expandOutlineFromList = useCallback((outlineId: string, outlineTitle: string) => {


    return handleExpandOutlineRef.current(outlineId, outlineTitle);


  }, []);


  const outlineMode = currentProject?.outline_mode;


  const outlineListItems = useMemo(() => (


    visibleOutlines.map((item) => {


      const parsedOutlineViewData = parsedOutlineViewDataById.get(item.id);


      const structureData = parsedOutlineViewData?.structureData ?? {};


      const characterNames = parsedOutlineViewData?.characterNames ?? [];


      const organizationNames = parsedOutlineViewData?.organizationNames ?? [];


      const outlineContentPreview = getPreviewText(item.content, isMobile ? 180 : 260);


      const isOutlineExpanded = outlineExpandStatus[item.id] ?? false;


      return (


        <List.Item


          key={item.id}


          style={outlineItemStyle}


        >


          <Card


            style={{


              width: '100%',


              borderRadius: isMobile ? 6 : 8,


              border: '1px solid #f0f0f0',


              boxShadow: '0 1px 2px rgba(0, 0, 0, 0.03)',


              transition: 'all 0.3s ease'


            }}


            bodyStyle={{


              padding: isMobile ? '10px 12px' : 16


            }}


            onMouseEnter={(e) => {


              if (!isMobile) {


                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';


                e.currentTarget.style.borderColor = 'var(--color-primary)';


              }


            }}


            onMouseLeave={(e) => {


              if (!isMobile) {


                e.currentTarget.style.boxShadow = '0 1px 2px rgba(0, 0, 0, 0.03)';


                e.currentTarget.style.borderColor = '#f0f0f0';


              }


            }}


          >


            <List.Item.Meta


              style={{ width: '100%' }}


              title={


                <Space size="small" style={{ fontSize: isMobile ? 13 : 16, flexWrap: 'wrap', lineHeight: isMobile ? '1.4' : '1.5' }}>


                  <span style={{ color: 'var(--color-primary)', fontWeight: 'bold', fontSize: isMobile ? 13 : 16 }}>


                    {outlineMode === 'one-to-one'


                      ? `第${item.order_index || '?'}章`


                      : `第${item.order_index || '?'}卷`


                    }


                  </span>


                  <span style={{ fontSize: isMobile ? 13 : 16 }}>{item.title}</span>


                  {/* ✅ 新增：展开状态标识 - 仅在一对多模式显示 */}


                  {outlineMode === 'one-to-many' && (


                    isOutlineExpanded ? (


                      <Tag color="success" icon={<CheckCircleOutlined />} style={{ fontSize: isMobile ? 11 : 12 }}>已展开</Tag>


                    ) : (


                      <Tag color="default" style={{ fontSize: isMobile ? 11 : 12 }}>未展开</Tag>


                    )


                  )}


                </Space>


              }


              description={


                <div style={{ fontSize: isMobile ? 12 : 14, lineHeight: isMobile ? '1.5' : '1.6' }}>


                  {/* 大纲内容 */}


                  <div style={{


                    marginBottom: isMobile ? 10 : 12,


                    padding: isMobile ? '8px 10px' : '10px 12px',


                    background: 'linear-gradient(135deg, #fafafa 0%, #f5f5f5 100%)',


                    borderLeft: '3px solid #8c8c8c',


                    borderRadius: isMobile ? 4 : 6,


                    fontSize: isMobile ? 12 : 13,


                    color: '#262626',


                    lineHeight: '1.6'


                  }}>


                    <div style={{


                      fontWeight: 600,


                      color: '#595959',


                      marginBottom: isMobile ? 4 : 6,


                      fontSize: isMobile ? 12 : 13


                    }}>


                      📝 大纲内容


                    </div>


                    <div


                      title={item.content}


                      style={{


                        padding: isMobile ? '6px 8px' : '6px 10px',


                        background: '#ffffff',


                        border: '1px solid #d9d9d9',


                        borderRadius: 4,


                        fontSize: isMobile ? 12 : 13,


                        color: '#262626',


                        lineHeight: '1.6'


                      }}


                    >


                      {outlineContentPreview}


                    </div>


                  </div>


                  {/* ✨ 涉及角色展示 - 优化版（支持角色/组织分类显示） */}


                  {characterNames.length > 0 && (


                    <div style={{


                      marginTop: isMobile ? 10 : 12,


                      padding: isMobile ? '8px 10px' : '10px 12px',


                      background: 'linear-gradient(135deg, #f5f3ff 0%, #faf5ff 100%)',


                      borderLeft: '3px solid #9333ea',


                      borderRadius: isMobile ? 4 : 6


                    }}>


                      <div style={{


                        display: 'flex',


                        alignItems: 'center',


                        gap: isMobile ? 6 : 8,


                        marginBottom: isMobile ? 6 : 8


                      }}>


                        <span style={{


                          fontSize: isMobile ? 12 : 13,


                          fontWeight: 600,


                          color: '#7c3aed',


                          display: 'flex',


                          alignItems: 'center',


                          gap: 4


                        }}>


                          👥 涉及角色


                          <Tag


                            color="purple"


                            style={{


                              margin: 0,


                              fontSize: 10,


                              borderRadius: 10,


                              padding: '0 6px'


                            }}


                          >


                            {characterNames.length}


                          </Tag>


                        </span>


                      </div>


                      <Space wrap size={[4, 4]}>


                        {characterNames.map((name, idx) => (


                          <Tag


                            key={idx}


                            color="purple"


                            style={{


                              margin: 0,


                              borderRadius: 4,


                              padding: isMobile ? '2px 8px' : '3px 10px',


                              fontSize: isMobile ? 11 : 12,


                              fontWeight: 500,


                              border: '1px solid #e9d5ff',


                              background: '#ffffff',


                              color: '#7c3aed',


                              whiteSpace: 'normal',


                              wordBreak: 'break-word',


                              height: 'auto',


                              lineHeight: '1.5'


                            }}


                          >


                            {name}


                          </Tag>


                        ))}


                      </Space>


                    </div>


                  )}


                  {/* 🏛️ 涉及组织展示 */}


                  {organizationNames.length > 0 && (


                    <div style={{


                      marginTop: isMobile ? 10 : 12,


                      padding: isMobile ? '8px 10px' : '10px 12px',


                      background: 'linear-gradient(135deg, #fff7ed 0%, #fffbeb 100%)',


                      borderLeft: '3px solid #ea580c',


                      borderRadius: isMobile ? 4 : 6


                    }}>


                      <div style={{


                        display: 'flex',


                        alignItems: 'center',


                        gap: isMobile ? 6 : 8,


                        marginBottom: isMobile ? 6 : 8


                      }}>


                        <span style={{


                          fontSize: isMobile ? 12 : 13,


                          fontWeight: 600,


                          color: '#ea580c',


                          display: 'flex',


                          alignItems: 'center',


                          gap: 4


                        }}>


                          🏛️ 涉及组织


                          <Tag


                            color="orange"


                            style={{


                              margin: 0,


                              fontSize: 10,


                              borderRadius: 10,


                              padding: '0 6px'


                            }}


                          >


                            {organizationNames.length}


                          </Tag>


                        </span>


                      </div>


                      <Space wrap size={[4, 4]}>


                        {organizationNames.map((name, idx) => (


                          <Tag


                            key={idx}


                            color="orange"


                            style={{


                              margin: 0,


                              borderRadius: 4,


                              padding: isMobile ? '2px 8px' : '3px 10px',


                              fontSize: isMobile ? 11 : 12,


                              fontWeight: 500,


                              border: '1px solid #fed7aa',


                              background: '#ffffff',


                              color: '#ea580c',


                              whiteSpace: 'normal',


                              wordBreak: 'break-word',


                              height: 'auto',


                              lineHeight: '1.5'


                            }}


                          >


                            {name}


                          </Tag>


                        ))}


                      </Space>


                    </div>


                  )}


                  {/* ✨ 场景信息展示 - 优化版（支持折叠，最多显示3个） */}


                  {structureData.scenes && structureData.scenes.length > 0 ? (() => {


                    const isExpanded = scenesExpandStatus[item.id] || false;


                    const maxVisibleScenes = 4;


                    const hasMoreScenes = structureData.scenes!.length > maxVisibleScenes;


                    const visibleScenes = isExpanded ? structureData.scenes : structureData.scenes!.slice(0, maxVisibleScenes);


                    return (


                      <div style={{


                        marginTop: isMobile ? 10 : 12,


                        padding: isMobile ? '8px 10px' : '10px 12px',


                        background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',


                        borderLeft: '3px solid #0ea5e9',


                        borderRadius: isMobile ? 4 : 6


                      }}>


                        <div style={{


                          display: 'flex',


                          alignItems: 'center',


                          justifyContent: 'space-between',


                          marginBottom: isMobile ? 6 : 8,


                          flexWrap: isMobile ? 'wrap' : 'nowrap',


                          gap: isMobile ? 4 : 0


                        }}>


                          <span style={{


                            fontSize: isMobile ? 12 : 13,


                            fontWeight: 600,


                            color: '#0284c7',


                            display: 'flex',


                            alignItems: 'center',


                            gap: 4


                          }}>


                            🎬 场景设定


                            <Tag


                              color="cyan"


                              style={{


                                margin: 0,


                                fontSize: 10,


                                borderRadius: 10,


                                padding: '0 6px'


                              }}


                            >


                              {structureData.scenes!.length}


                            </Tag>


                          </span>


                          {hasMoreScenes && (


                            <Button


                              type="text"


                              size="small"


                              onClick={() => setScenesExpandStatus(prev => ({


                                ...prev,


                                [item.id]: !isExpanded


                              }))}


                              style={{


                                fontSize: isMobile ? 10 : 11,


                                height: isMobile ? 20 : 22,


                                padding: isMobile ? '0 6px' : '0 8px',


                                color: '#0284c7'


                              }}


                            >


                              {isExpanded ? '收起 ▲' : `展开 (${structureData.scenes!.length - maxVisibleScenes}+) ▼`}


                            </Button>


                          )}


                        </div>


                        {/* 使用grid布局，移动端一列，桌面端两列 */}


                        <div style={{


                          display: 'grid',


                          gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fill, minmax(280px, 1fr))',


                          gap: isMobile ? 6 : 8,


                          width: '100%',


                          minWidth: 0  // 防止grid子元素溢出


                        }}>


                          {visibleScenes!.map((scene, idx) => {


                          // 判断是字符串还是对象


                          if (typeof scene === 'string') {


                            // 字符串格式：简洁卡片


                            return (


                              <div


                                key={idx}


                                style={{


                                  padding: isMobile ? '6px 8px' : '8px 10px',


                                  background: '#ffffff',


                                  border: '1px solid #bae6fd',


                                  borderRadius: isMobile ? 4 : 6,


                                  fontSize: isMobile ? 11 : 12,


                                  color: '#0c4a6e',


                                  display: 'flex',


                                  alignItems: 'flex-start',


                                  gap: isMobile ? 6 : 8,


                                  transition: 'all 0.2s ease',


                                  cursor: 'default',


                                  width: '100%',


                                  minWidth: 0,


                                  boxSizing: 'border-box'


                                }}


                                onMouseEnter={(e) => {


                                  if (!isMobile) {


                                    e.currentTarget.style.borderColor = '#0ea5e9';


                                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(14, 165, 233, 0.15)';


                                  }


                                }}


                                onMouseLeave={(e) => {


                                  if (!isMobile) {


                                    e.currentTarget.style.borderColor = '#bae6fd';


                                    e.currentTarget.style.boxShadow = 'none';


                                  }


                                }}


                              >


                                <Tag


                                  color="cyan"


                                  style={{


                                    margin: 0,


                                    fontSize: 10,


                                    borderRadius: 4,


                                    flexShrink: 0


                                  }}


                                >


                                  {idx + 1}


                                </Tag>


                                <span style={{


                                  flex: 1,


                                  lineHeight: '1.6',


                                  overflow: 'hidden',


                                  textOverflow: 'ellipsis',


                                  whiteSpace: 'nowrap'


                                }}>{scene}</span>


                              </div>


                            );


                          } else {


                            // 对象格式：详细卡片


                            return (


                              <div


                                key={idx}


                                style={{


                                  padding: isMobile ? '8px 10px' : '10px 12px',


                                  background: '#ffffff',


                                  border: '1px solid #bae6fd',


                                  borderRadius: isMobile ? 4 : 6,


                                  fontSize: isMobile ? 11 : 12,


                                  transition: 'all 0.2s ease',


                                  cursor: 'default',


                                  width: '100%',


                                  minWidth: 0,


                                  boxSizing: 'border-box'


                                }}


                                onMouseEnter={(e) => {


                                  if (!isMobile) {


                                    e.currentTarget.style.borderColor = '#0ea5e9';


                                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(14, 165, 233, 0.15)';


                                  }


                                }}


                                onMouseLeave={(e) => {


                                  if (!isMobile) {


                                    e.currentTarget.style.borderColor = '#bae6fd';


                                    e.currentTarget.style.boxShadow = 'none';


                                  }


                                }}


                              >


                                <div style={{


                                  display: 'flex',


                                  alignItems: 'center',


                                  gap: isMobile ? 6 : 8,


                                  marginBottom: isMobile ? 4 : 6,


                                  flexWrap: 'wrap'


                                }}>


                                  <Tag


                                    color="cyan"


                                    style={{


                                      margin: 0,


                                      fontSize: 10,


                                      borderRadius: 4


                                    }}


                                  >


                                    场景{idx + 1}


                                  </Tag>


                                  <span style={{


                                    fontWeight: 600,


                                    color: '#0c4a6e',


                                    fontSize: isMobile ? 12 : 13,


                                    flex: 1,


                                    overflow: 'hidden',


                                    textOverflow: 'ellipsis',


                                    whiteSpace: 'nowrap'


                                  }}>


                                    📍 {scene.location}


                                  </span>


                                </div>


                                {scene.characters && scene.characters.length > 0 && (


                                  <div style={{


                                    fontSize: isMobile ? 10 : 11,


                                    color: '#64748b',


                                    marginBottom: 4,


                                    paddingLeft: isMobile ? 2 : 4,


                                    overflow: 'hidden',


                                    textOverflow: 'ellipsis',


                                    whiteSpace: 'nowrap'


                                  }}>


                                    <span style={{ fontWeight: 500 }}>👤 角色：</span>


                                    {scene.characters.join(' · ')}


                                  </div>


                                )}


                                {scene.purpose && (


                                  <div style={{


                                    fontSize: isMobile ? 10 : 11,


                                    color: '#64748b',


                                    paddingLeft: isMobile ? 2 : 4,


                                    lineHeight: '1.5',


                                    overflow: 'hidden',


                                    textOverflow: 'ellipsis',


                                    whiteSpace: 'nowrap'


                                  }}>


                                    <span style={{ fontWeight: 500 }}>🎯 目的：</span>


                                    {scene.purpose}


                                  </div>


                                )}


                              </div>


                            );


                          }


                          })}


                        </div>


                      </div>


                    );


                  })() : null}


                {/* ✨ 关键事件展示 */}


                {structureData.key_events && structureData.key_events.length > 0 && (


                  <div style={{


                    marginTop: 12,


                    padding: '10px 12px',


                    background: 'linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%)',


                    borderLeft: '3px solid #f97316',


                    borderRadius: 6


                  }}>


                    <div style={{


                      display: 'flex',


                      alignItems: 'center',


                      gap: 8,


                      marginBottom: 8


                    }}>


                      <span style={{


                        fontSize: 13,


                        fontWeight: 600,


                        color: '#ea580c',


                        display: 'flex',


                        alignItems: 'center',


                        gap: 4


                      }}>


                        ⚡ 关键事件


                        <Tag


                          color="orange"


                          style={{


                            margin: 0,


                            fontSize: 11,


                            borderRadius: 10,


                            padding: '0 6px'


                          }}


                        >


                          {structureData.key_events.length}


                        </Tag>


                      </span>


                    </div>


                    <Space direction="vertical" size={6} style={{ width: '100%' }}>


                      {structureData.key_events.map((event, idx) => (


                        <div


                          key={idx}


                          style={{


                            padding: '6px 10px',


                            background: '#ffffff',


                            border: '1px solid #fed7aa',


                            borderRadius: 4,


                            fontSize: 12,


                            color: '#9a3412',


                            display: 'flex',


                            alignItems: 'flex-start',


                            gap: 8


                          }}


                        >


                          <Tag


                            color="orange"


                            style={{


                              margin: 0,


                              fontSize: 11,


                              borderRadius: 4,


                              flexShrink: 0


                            }}


                          >


                            {idx + 1}


                          </Tag>


                          <span style={{


                            flex: 1,


                            lineHeight: '1.6',


                            overflow: 'hidden',


                            textOverflow: 'ellipsis',


                            whiteSpace: 'nowrap'


                          }}>{event}</span>


                        </div>


                      ))}


                    </Space>


                  </div>


                )}


                {/* ✨ 情节要点展示 (key_points) */}


                {structureData.key_points && structureData.key_points.length > 0 && (


                  <div style={{


                    marginTop: 12,


                    padding: '10px 12px',


                    background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',


                    borderLeft: '3px solid #22c55e',


                    borderRadius: 6


                  }}>


                    <div style={{


                      display: 'flex',


                      alignItems: 'center',


                      gap: 8,


                      marginBottom: 8


                    }}>


                      <span style={{


                        fontSize: 13,


                        fontWeight: 600,


                        color: '#15803d',


                        display: 'flex',


                        alignItems: 'center',


                        gap: 4


                      }}>


                        💡 情节要点


                        <Tag


                          color="green"


                          style={{


                            margin: 0,


                            fontSize: 11,


                            borderRadius: 10,


                            padding: '0 6px'


                          }}


                        >


                          {structureData.key_points.length}


                        </Tag>


                      </span>


                    </div>


                    {/* 使用grid布局，移动端一列，桌面端两列 */}


                    <div style={{


                      display: 'grid',


                      gridTemplateColumns: isMobile ? '1fr' : 'repeat(auto-fill, minmax(280px, 1fr))',


                      gap: isMobile ? 6 : 8,


                      width: '100%',


                      minWidth: 0


                    }}>


                      {structureData.key_points.map((point, idx) => (


                        <div


                          key={idx}


                          style={{


                            padding: isMobile ? '6px 8px' : '8px 10px',


                            background: '#ffffff',


                            border: '1px solid #bbf7d0',


                            borderRadius: isMobile ? 4 : 6,


                            fontSize: isMobile ? 11 : 12,


                            color: '#166534',


                            display: 'flex',


                            alignItems: 'flex-start',


                            gap: isMobile ? 6 : 8,


                            transition: 'all 0.2s ease',


                            cursor: 'default',


                            width: '100%',


                            minWidth: 0,


                            boxSizing: 'border-box'


                          }}


                          onMouseEnter={(e) => {


                            if (!isMobile) {


                              e.currentTarget.style.borderColor = '#22c55e';


                              e.currentTarget.style.boxShadow = '0 2px 8px rgba(34, 197, 94, 0.15)';


                            }


                          }}


                          onMouseLeave={(e) => {


                            if (!isMobile) {


                              e.currentTarget.style.borderColor = '#bbf7d0';


                              e.currentTarget.style.boxShadow = 'none';


                            }


                          }}


                        >


                          <Tag


                            color="green"


                            style={{


                              margin: 0,


                              fontSize: 10,


                              borderRadius: 4,


                              flexShrink: 0


                            }}


                          >


                            {idx + 1}


                          </Tag>


                          <span style={{


                            flex: 1,


                            lineHeight: '1.6',


                            overflow: 'hidden',


                            textOverflow: 'ellipsis',


                            whiteSpace: 'nowrap'


                          }}>{point}</span>


                        </div>


                      ))}


                    </div>


                  </div>


                )}


                {/* ✨ 情感基调展示 (emotion) */}


                {structureData.emotion && (


                  <div style={{


                    marginTop: 12,


                    padding: '10px 12px',


                    background: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',


                    borderLeft: '3px solid #f59e0b',


                    borderRadius: 6,


                    display: 'flex',


                    alignItems: 'center',


                    gap: 8


                  }}>


                    <span style={{


                      fontSize: 13,


                      fontWeight: 600,


                      color: '#b45309'


                    }}>


                      💫 情感基调：


                    </span>


                    <Tag


                      color="gold"


                      style={{


                        margin: 0,


                        fontSize: 12,


                        padding: '2px 12px',


                        borderRadius: 12,


                        background: '#ffffff',


                        border: '1px solid #fbbf24',


                        color: '#b45309'


                      }}


                    >


                      {structureData.emotion}


                    </Tag>


                  </div>


                )}


                {/* ✨ 叙事目标展示 (goal) */}


                {structureData.goal && (


                  <div style={{


                    marginTop: 12,


                    padding: '10px 12px',


                    background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',


                    borderLeft: '3px solid #3b82f6',


                    borderRadius: 6


                  }}>


                    <div style={{


                      fontSize: 13,


                      fontWeight: 600,


                      color: '#1e40af',


                      marginBottom: 6


                    }}>


                      🎯 叙事目标


                    </div>


                    <div style={{


                      fontSize: 12,


                      color: '#1e3a8a',


                      lineHeight: '1.6',


                      padding: '6px 10px',


                      background: '#ffffff',


                      border: '1px solid #93c5fd',


                      borderRadius: 4,


                      overflow: 'hidden',


                      textOverflow: 'ellipsis',


                      whiteSpace: 'nowrap'


                    }}>


                      {structureData.goal}


                    </div>


                  </div>


                )}


              </div>


            }


          />


            {/* 操作按钮区域 - 在卡片内部 */}


            <div style={{


              marginTop: 16,


              paddingTop: 12,


              borderTop: '1px solid #f0f0f0',


              display: 'flex',


              justifyContent: 'flex-end',


              gap: 8


            }}>


              {outlineMode === 'one-to-many' && (


                <Button


                  icon={<BranchesOutlined />}


                  onClick={() => expandOutlineFromList(item.id, item.title)}


                  loading={Boolean(isExpanding || hasActiveTrackedOutlineExpandTask)}


                  size={isMobile ? 'middle' : 'small'}


                >


                  展开


                </Button>


              )}


              <Button


                icon={<EditOutlined />}


                onClick={() => openEditModalFromList(item.id)}


                size={isMobile ? 'middle' : 'small'}


              >


                编辑


              </Button>


              <Popconfirm


                title="确定删除这条大纲吗？"


                onConfirm={() => deleteOutlineFromList(item.id)}


                okText="确定"


                cancelText="取消"


              >


                <Button


                  danger


                  icon={<DeleteOutlined />}


                  size={isMobile ? 'middle' : 'small'}


                >


                  删除


                </Button>


              </Popconfirm>


            </div>


          </Card>


        </List.Item>


      );


    })


  ), [


    visibleOutlines,


    parsedOutlineViewDataById,


    outlineItemStyle,


    isMobile,


    outlineMode,


    outlineExpandStatus,


    scenesExpandStatus,


    isExpanding,


    hasActiveTrackedOutlineExpandTask,


    openEditModalFromList,


    deleteOutlineFromList,


    expandOutlineFromList,


  ]);


  if (!currentProject) return null;

  const heroBackground = `linear-gradient(135deg,
    color-mix(in srgb, ${token.colorPrimary} 76%, #69453c 24%) 0%,
    color-mix(in srgb, ${token.colorInfo} 26%, #172229 74%) 100%)`;
  const editorialInk = '#fff9f0';
  const actionButtonStyle = {
    borderRadius: 999,
    height: 42,
    paddingInline: 16,
    borderColor: 'rgba(255,255,255,0.18)',
    background: 'rgba(255,255,255,0.08)',
    color: editorialInk,
    boxShadow: 'none',
  } as const;
  const panelBackground = `linear-gradient(180deg,
    color-mix(in srgb, ${token.colorBgContainer} 94%, white 6%) 0%,
    color-mix(in srgb, ${token.colorFillAlter} 46%, ${token.colorBgContainer} 54%) 100%)`;
  const panelBorder = `1px solid color-mix(in srgb, ${token.colorBorderSecondary} 88%, white 12%)`;
  const outlineModeLabel = currentProject.outline_mode === 'one-to-one' ? '传统模式 (1→1)' : '细化模式 (1→N)';
  const activeOutlineCount = Object.values(outlineExpandStatus).filter(Boolean).length;
  const summaryItems: Array<{ label: string; value: number | string; accent: string; compact?: boolean }> = [
    { label: '大纲总数', value: sortedOutlines.length, accent: editorialInk },
    { label: '已展开', value: activeOutlineCount, accent: token.colorSuccess },
    { label: '角色素材', value: storeCharacters.length, accent: token.colorInfo },
    { label: '当前模式', value: outlineModeLabel, accent: editorialInk, compact: true },
  ];
  const outlineGuideSteps = [
    '先看模式、统计卡和任务状态，确认当前是在搭主线、续写已有结构，还是把大纲展开成章节。',
    '再进入大纲列表逐条检查标题、结构和展开状态，把修订动作放在同一轮里连续完成。',
    '最后再决定智能生成、手动创建或批量展开，避免在结构还没理顺前直接推进后续章节生产。',
  ];
  const outlineFocus = (isGenerating || hasActiveTrackedOutlineGenerateTask)
    ? {
        title: '等待大纲生成或续写回流',
        note: '当前有一条大纲生成任务正在执行，适合先观察结果回流，再统一整理列表结构和顺序。',
      }
    : (isExpanding || hasActiveTrackedOutlineExpandTask)
      ? {
          title: '关注展开成章进度',
          note: '当前有展开任务在进行，优先确认哪些大纲已经转成章节，再决定是否继续批量扩展。',
        }
      : sortedOutlines.length === 0
        ? {
            title: '先建立第一条故事主线',
            note: '当前还没有任何大纲，适合先写出一条骨架，再决定交给 AI 续写还是自己继续细化。',
          }
        : currentProject.outline_mode === 'one-to-many' && activeOutlineCount === 0
          ? {
              title: '检查哪些大纲适合先展开',
              note: '当前处于细化模式但还没有已展开的大纲，适合先确认哪些卷已经稳定，可以进入成章阶段。',
            }
          : {
              title: '整理大纲台账并校正节奏',
              note: `当前已加载 ${visibleOutlineCount}/${sortedOutlines.length} 条大纲，更适合先统一检查顺序、结构密度和展开节奏，再决定下一步生成动作。`,
            };


  return (


    <>


      {singlePreviewVisible && singlePreviewData ? (
        <Modal
          title={(
            <Space>
              <CheckCircleOutlined style={{ color: 'var(--color-success)' }} />
              <span>展开规划预览</span>
            </Space>
          )}
          open={singlePreviewVisible}
          onOk={() => void handleSinglePreviewOk()}
          onCancel={handleSinglePreviewCancel}
          width={900}
          centered
          okText="确认并创建章节"
          cancelText="暂不创建"
          confirmLoading={isExpanding}
          destroyOnHidden
        >
          <InlineErrorBoundary
            fallback={(
              <div style={{ padding: '16px 0', textAlign: 'center' }}>
                展开预览面板加载失败，请关闭后重试。
              </div>
            )}
          >
            <Suspense fallback={outlineLazyFallback}>
              <LazyOutlineExpansionPreviewContent
                response={singlePreviewData}
                isMobile={isMobile}
              />
            </Suspense>
          </InlineErrorBoundary>
        </Modal>
      ) : null}


      {/* 批量展开预览 Modal */}


      {batchPreviewVisible ? (
        <InlineErrorBoundary
          fallback={(
            <div style={{ padding: '16px 0', textAlign: 'center' }}>
              批量展开预览面板加载失败，请关闭后重试。
            </div>
          )}
        >
          <Suspense
            fallback={(
              <WorkflowEntryFallback
                eyebrow="Outline Preview"
                title="正在展开批量预览工作区"
                message="系统正在恢复批量展开预览、确认入口与关闭操作，原有预览数据和提交流程保持不变。"
                tags={[
                  { label: '批量展开预览', color: 'purple' },
                  { label: '预览工作区恢复中', color: 'processing' },
                  { label: '提交流程保持原样', color: 'green' },
                ]}
              />
            )}
          >
            <LazyOutlineBatchPreviewModal
              visible={batchPreviewVisible}
              data={batchPreviewData}
              onOk={handleBatchPreviewOk}
              onCancel={handleBatchPreviewCancel}
            />
          </Suspense>
        </InlineErrorBoundary>
      ) : null}

      {contextHolder}


      {/* SSE进度Modal - 使用统一组件 */}


      {sseModalVisible ? (
        <InlineErrorBoundary
          fallback={(
            <div style={{ padding: '16px 0', textAlign: 'center' }}>
              任务进度面板加载失败，请刷新页面后重试。
            </div>
          )}
        >
          <Suspense
            fallback={(
              <WorkflowEntryFallback
                eyebrow="Outline Generation"
                title="正在接入当前生成进度面板"
                message="系统正在恢复这次大纲生成进度、取消入口与任务提示，原有后台任务轮询、恢复与取消逻辑保持不变。"
                tags={[
                  { label: '大纲生成进度', color: 'gold' },
                  { label: '后台任务监视中', color: 'cyan' },
                  { label: '轮询逻辑保持原样', color: 'green' },
                ]}
              />
            )}
          >
            <LazySSEProgressModal
              visible={sseModalVisible}
              progress={sseProgress}
              message={sseMessage}
              title="正在生成中..."
              blocking={false}
              onCancel={() => {
                if (isGenerating) {
                  void handleCancelGenerateTask();
                  return;
                }

                if (isExpanding) {
                  void handleCancelExpandTask();
                }
              }}
              cancelButtonText="取消任务"
            />
          </Suspense>
        </InlineErrorBoundary>
      ) : null}


      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: 16, overflow: 'hidden', paddingBottom: 24 }}>
        <Card
          variant="borderless"
          style={{
            background: heroBackground,
            borderRadius: 28,
            border: `1px solid color-mix(in srgb, ${token.colorBgContainer} 12%, transparent)`,
            boxShadow: `0 26px 52px color-mix(in srgb, ${token.colorText} 20%, transparent)`,
            overflow: 'hidden',
            position: 'relative',
          }}
          styles={{ body: { padding: isMobile ? 20 : 24 } }}
        >
          <div style={{ position: 'absolute', top: -56, right: -28, width: 176, height: 176, borderRadius: '50%', background: 'rgba(255,255,255,0.08)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', bottom: -32, left: isMobile ? '56%' : '27%', width: 124, height: 124, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', pointerEvents: 'none' }} />
          <Row gutter={[24, 18]} align="middle" style={{ position: 'relative', zIndex: 1 }}>
            <Col xs={24} lg={14}>
              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                <Text style={{ color: 'rgba(255,255,255,0.72)', fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
                  Outline Workshop
                </Text>
                <Title level={2} style={{ margin: 0, color: editorialInk, fontFamily: designDisplayFont, letterSpacing: '-0.03em' }}>
                  故事大纲
                </Title>
                <Paragraph style={{ margin: 0, color: 'rgba(255,255,255,0.82)', fontSize: 15, lineHeight: 1.8 }}>
                  把故事结构、卷章节奏和后续展开入口收在同一块编辑台里。这里应该既能承接智能生成，也要方便你像编辑一样逐条修订、扩写和检查推进状态。
                </Paragraph>
                <Space wrap size={[10, 10]}>
                  <Tag style={{ borderRadius: 999, paddingInline: 12, border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.08)', color: editorialInk }}>
                    {outlineModeLabel}
                  </Tag>
                  <Tag style={{ borderRadius: 999, paddingInline: 12, border: '1px solid rgba(255,255,255,0.12)', background: 'rgba(255,255,255,0.08)', color: editorialInk }}>
                    已加载 {visibleOutlineCount}/{sortedOutlines.length}
                  </Tag>
                  {(isGenerating || hasActiveTrackedOutlineGenerateTask) && (
                    <Tag color="processing" style={{ borderRadius: 999, paddingInline: 12 }}>
                      大纲任务进行中
                    </Tag>
                  )}
                  {(isExpanding || hasActiveTrackedOutlineExpandTask) && (
                    <Tag color="success" style={{ borderRadius: 999, paddingInline: 12 }}>
                      展开任务进行中
                    </Tag>
                  )}
                </Space>
              </Space>
            </Col>
            <Col xs={24} lg={10}>
              <Row gutter={[12, 12]}>
                {summaryItems.map((item) => (
                  <Col xs={12} key={item.label}>
                    <div
                      style={{
                        minHeight: 92,
                        borderRadius: 18,
                        padding: '12px 14px',
                        background: 'rgba(255,255,255,0.08)',
                        border: '1px solid rgba(255,255,255,0.1)',
                        backdropFilter: 'blur(10px)',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                      }}
                    >
                      <Text style={{ color: 'rgba(255,255,255,0.72)', fontSize: 12, display: 'block' }}>{item.label}</Text>
                      <Text
                        style={{
                          color: item.accent,
                          fontWeight: 700,
                          fontSize: item.compact ? 15 : 24,
                          lineHeight: 1.2,
                          wordBreak: 'break-word',
                        }}
                      >
                        {item.value}
                      </Text>
                    </div>
                  </Col>
                ))}
              </Row>
            </Col>
          </Row>
          <Space wrap size={[10, 10]} style={{ marginTop: 20, position: 'relative', zIndex: 1 }}>
            <Button
              icon={<PlusOutlined />}
              onClick={showManualCreateOutlineModal}
              style={actionButtonStyle}
            >
              手动创建
            </Button>
            <Button
              type="primary"
              icon={<ThunderboltOutlined />}
              onClick={showGenerateModal}
              loading={Boolean(isGenerating || hasActiveTrackedOutlineGenerateTask)}
              style={{ borderRadius: 999, paddingInline: 16 }}
            >
              {isMobile ? '智能生成/续写' : '智能生成/续写大纲'}
            </Button>
            {outlines.length > 0 && currentProject.outline_mode === 'one-to-many' && (
              <Button
                icon={<AppstoreAddOutlined />}
                onClick={handleBatchExpandOutlines}
                loading={Boolean(isExpanding || hasActiveTrackedOutlineExpandTask)}
                title="将所有大纲展开为多章，实现从大纲到章节的一对多关系"
                style={actionButtonStyle}
              >
                {isMobile ? '批量展开' : '批量展开为多章'}
              </Button>
            )}
          </Space>
        </Card>

        <Card
          variant="borderless"
          style={{
            borderRadius: 22,
            background: `linear-gradient(135deg, color-mix(in srgb, ${token.colorPrimary} 10%, white 90%) 0%, color-mix(in srgb, ${token.colorInfo} 10%, white 90%) 100%)`,
            border: `1px solid color-mix(in srgb, ${token.colorPrimary} 16%, white 84%)`,
            boxShadow: `0 18px 36px color-mix(in srgb, ${token.colorText} 8%, transparent)`,
          }}
          styles={{ body: { padding: isMobile ? 16 : 18 } }}
        >
          <Row gutter={[16, 16]}>
            <Col xs={24} lg={15}>
              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                <Text style={{ color: token.colorTextTertiary, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                  Outline Guide
                </Text>
                <Paragraph style={{ margin: 0, color: token.colorText, lineHeight: 1.75 }}>
                  这个页面更像故事骨架工作台与后续展开入口。原有生成、续写、编辑、删除和成章展开逻辑都保持不变，这里只把阅读顺序和当前该关注的层级提炼出来。
                </Paragraph>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {outlineGuideSteps.map((item, index) => (
                    <span
                      key={item}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 8,
                        padding: '6px 12px',
                        borderRadius: 999,
                        background: token.colorBgContainer,
                        border: `1px solid ${token.colorBorderSecondary}`,
                        color: token.colorTextBase,
                        fontSize: 12,
                      }}
                    >
                      <span style={{ color: token.colorPrimary, fontWeight: 700 }}>{index + 1}</span>
                      {item}
                    </span>
                  ))}
                </div>
              </Space>
            </Col>
            <Col xs={24} lg={9}>
              <div
                style={{
                  height: '100%',
                  borderRadius: 18,
                  padding: isMobile ? '14px 14px 12px' : '16px 18px 14px',
                  background: `linear-gradient(180deg, ${token.colorBgContainer} 0%, ${token.colorFillAlter} 100%)`,
                  border: `1px solid ${token.colorBorderSecondary}`,
                }}
              >
                <Text style={{ display: 'block', color: token.colorTextTertiary, fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                  当前工作焦点
                </Text>
                <Title level={5} style={{ margin: '8px 0 6px', color: token.colorTextBase, fontFamily: designDisplayFont }}>
                  {outlineFocus.title}
                </Title>
                <Paragraph style={{ margin: 0, color: token.colorTextSecondary, lineHeight: 1.75 }}>
                  {outlineFocus.note}
                </Paragraph>
              </div>
            </Col>
          </Row>
        </Card>

        <Card
          variant="borderless"
          style={{
            flex: 1,
            overflow: 'hidden',
            background: panelBackground,
            borderRadius: 24,
            border: panelBorder,
            boxShadow: `0 18px 36px color-mix(in srgb, ${token.colorText} 8%, transparent)`,
          }}
          styles={{ body: { height: '100%', padding: isMobile ? 16 : 20 } }}
        >
          <Space direction="vertical" size={16} style={{ width: '100%', height: '100%' }}>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: isMobile ? 'flex-start' : 'center',
                gap: 12,
                flexDirection: isMobile ? 'column' : 'row',
              }}
            >
              <Space direction="vertical" size={4}>
                <Text style={{ fontSize: 12, letterSpacing: '0.12em', textTransform: 'uppercase', color: token.colorTextTertiary }}>
                  Outline Ledger
                </Text>
                <Title level={4} style={{ margin: 0, fontFamily: designDisplayFont, color: token.colorTextBase }}>
                  大纲列表工作区
                </Title>
                <Paragraph style={{ margin: 0, color: token.colorTextSecondary }}>
                  这里继续保留你现有的大纲编辑、删除、展开和预览流，只是把外层承载换成更清晰的工作区结构。
                </Paragraph>
              </Space>
              <Space wrap size={[8, 8]}>
                <Tag color="blue" style={{ borderRadius: 999, paddingInline: 10 }}>
                  已显示 {visibleOutlineCount}
                </Tag>
                <Tag color="purple" style={{ borderRadius: 999, paddingInline: 10 }}>
                  总计 {sortedOutlines.length}
                </Tag>
              </Space>
            </div>

            <Divider style={{ margin: 0, borderColor: token.colorBorderSecondary }} />

            <div style={{ flex: 1, overflowY: 'auto', paddingRight: isMobile ? 0 : 4 }}>
              {outlines.length === 0 ? (
                <Card
                  variant="borderless"
                  style={{
                    borderRadius: 22,
                    background: `linear-gradient(180deg, ${token.colorBgContainer} 0%, ${token.colorFillAlter} 100%)`,
                    border: `1px dashed ${token.colorBorder}`,
                    minHeight: 320,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                  styles={{ body: { width: '100%' } }}
                >
                  <Empty description="还没有大纲，先创建一条主线，再决定是否交给 AI 继续细化。">
                    <Space wrap>
                      <Button icon={<PlusOutlined />} onClick={showManualCreateOutlineModal}>
                        手动创建
                      </Button>
                      <Button
                        type="primary"
                        icon={<ThunderboltOutlined />}
                        onClick={showGenerateModal}
                        loading={Boolean(isGenerating || hasActiveTrackedOutlineGenerateTask)}
                      >
                        智能生成大纲
                      </Button>
                    </Space>
                  </Empty>
                </Card>
              ) : (
                <>
                  <List>
                    {outlineListItems}
                  </List>

                  {visibleOutlineCount < sortedOutlines.length ? (
                    <Card
                      bordered={false}
                      style={{
                        marginTop: 8,
                        borderRadius: 18,
                        background: `linear-gradient(135deg, color-mix(in srgb, ${token.colorPrimaryBg} 92%, transparent) 0%, color-mix(in srgb, ${token.colorBgContainer} 96%, white 4%) 100%)`,
                        border: panelBorder,
                        boxShadow: `0 14px 28px color-mix(in srgb, ${token.colorText} 6%, transparent)`,
                      }}
                      styles={{ body: { padding: '12px 16px' } }}
                    >
                      <Text style={{ display: 'block', fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: token.colorTextTertiary }}>
                        Progressive Outline Render
                      </Text>
                      <Text strong style={{ display: 'block', marginTop: 6 }}>
                        还有 {sortedOutlines.length - visibleOutlineCount} 个大纲正在继续接管
                      </Text>
                      <Text type="secondary" style={{ display: 'block', marginTop: 6, lineHeight: 1.7 }}>
                        页面已经先展示首批大纲卡片，系统正在继续补齐剩余条目；原有排序、展开和批量操作逻辑保持不变。
                      </Text>
                    </Card>
                  ) : null}
                </>
              )}
            </div>
          </Space>
        </Card>
      </div>


    </>


  );


}
