import React, { useEffect, useRef, useState } from 'react';
import {
  Alert,
  Button,
  Card,
  Checkbox,
  Collapse,
  Divider,
  Form,
  Input,
  InputNumber,
  message,
  Modal,
  Radio,
  Select,
  Space,
  Switch,
  Tag,
  Typography,
  theme,
} from 'antd';
import {
  CheckCircleOutlined,
  CloseCircleOutlined,
  ReloadOutlined,
} from '@ant-design/icons';

import type {
  ChapterQualityMetricsSummary,
  CreativeMode,
  PlotStage,
  QualityPreset,
  StoryFocus,
  StoryQualityGateDecision,
  StoryRepairGuidance,
} from '../types';
import {
  getQualityGateRecommendedDefaults,
  getQualityTrendLabel,
  getRepairGuidanceDisplay,
} from '../utils/storyCreationQualitySummary';
import {
  CREATIVE_MODE_OPTIONS,
  PLOT_STAGE_OPTIONS,
  QUALITY_PRESET_OPTIONS,
  STORY_FOCUS_OPTIONS,
} from '../utils/generationPreferenceOptions';
import { chapterPartialRegenerationApi } from '../services/modules/chapterPartialRegeneration';
import { useStore } from '../store';
import { SSEProgressModal } from './SSEProgressModal';

const { TextArea } = Input;
const { Panel } = Collapse;
const { Text } = Typography;

const REGENERATION_STREAM_INACTIVITY_TIMEOUT_MS = 90000;
const REGENERATION_HEARTBEAT_SUFFIX = '（仍在生成中）';

const appendRegenerationHeartbeatHint = (message: string) => {
  const normalized = message.trim();
  if (!normalized) {
    return `正在重新生成...${REGENERATION_HEARTBEAT_SUFFIX}`;
  }

  if (normalized.endsWith(REGENERATION_HEARTBEAT_SUFFIX)) {
    return normalized;
  }

  return `${normalized}${REGENERATION_HEARTBEAT_SUFFIX}`;
};

const FOCUS_AREA_OPTIONS: Array<{ value: string; label: string }> = [
  { value: 'pacing', label: '节奏把控' },
  { value: 'emotion', label: '情感渲染' },
  { value: 'description', label: '场景描写' },
  { value: 'dialogue', label: '对话质量' },
  { value: 'conflict', label: '冲突强度' },
  { value: 'outline', label: '大纲贴合' },
  { value: 'rule_grounding', label: '规则落地' },
  { value: 'opening', label: '开场钩子' },
  { value: 'payoff', label: '回报兑现' },
  { value: 'cliffhanger', label: '章末牵引' },
];

const EXTRA_FOCUS_AREA_LABELS: Record<string, string> = {
  relationship_continuity: "关系连续性",
  foreshadow_continuity: "伏笔连续性",
  character_continuity: "角色连续性",
  organization_continuity: "组织连续性",
  career_continuity: "职业成长连续性",
};

const getFocusAreaLabel = (value: string): string => {
  return FOCUS_AREA_OPTIONS.find((item) => item.value === value)?.label || EXTRA_FOCUS_AREA_LABELS[value] || value;
};

interface Suggestion {
  category: string;
  content: string;
  priority: string;
}

interface ChapterRegenerationModalProps {
  visible: boolean;
  onCancel: () => void;
  onSuccess: (newContent: string, wordCount: number) => void;
  chapterId: string;
  chapterTitle: string;
  chapterNumber: number;
  suggestions?: Suggestion[];
  hasAnalysis: boolean;
  repairGuidance?: StoryRepairGuidance | null;
  qualityMetricsSummary?: ChapterQualityMetricsSummary | null;
  qualityGate?: StoryQualityGateDecision | null;
}

type ModificationSource = 'custom' | 'analysis_suggestions' | 'mixed';

interface RegenerationFormValues {
  modification_source: ModificationSource;
  custom_instructions?: string;
  preserve_structure?: boolean;
  preserve_character_traits?: boolean;
  preserve_dialogues?: string[];
  preserve_plot_points?: string[];
  style_id?: string | number;
  target_word_count: number;
  focus_areas?: string[];
  creative_mode?: CreativeMode;
  story_focus?: StoryFocus;
  plot_stage?: PlotStage;
  story_creation_brief?: string;
  quality_preset?: QualityPreset;
  quality_notes?: string;
  enable_web_research?: boolean;
  web_research_query?: string;
}

interface RegenerationRequest {
  modification_source: ModificationSource;
  custom_instructions?: string;
  selected_suggestion_indices: number[];
  preserve_elements: {
    preserve_structure: boolean;
    preserve_dialogues: string[];
    preserve_plot_points: string[];
    preserve_character_traits: boolean;
  };
  style_id?: string | number;
  target_word_count: number;
  focus_areas: string[];
  creative_mode?: CreativeMode;
  story_focus?: StoryFocus;
  plot_stage?: PlotStage;
  story_creation_brief?: string;
  quality_preset?: QualityPreset;
  quality_notes?: string;
  story_repair_summary?: string;
  story_repair_targets?: string[];
  story_preserve_strengths?: string[];
  enable_web_research?: boolean;
  web_research_query?: string;
}

const ChapterRegenerationModal: React.FC<ChapterRegenerationModalProps> = ({
  visible,
  onCancel,
  onSuccess,
  chapterId,
  chapterTitle,
  chapterNumber,
  suggestions = [],
  hasAnalysis,
  repairGuidance = null,
  qualityMetricsSummary = null,
  qualityGate = null,
}) => {
  const { token } = theme.useToken();
  const alphaColor = (color: string, alpha: number) => `color-mix(in srgb, ${color} ${(alpha * 100).toFixed(0)}%, transparent)`;
  const currentProjectId = useStore((state) => state.currentProject?.id);
  const [form] = Form.useForm<RegenerationFormValues>();
  const [modal, contextHolder] = Modal.useModal();
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<'idle' | 'generating' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [progressMessage, setProgressMessage] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [selectedSuggestions, setSelectedSuggestions] = useState<number[]>([]);
  const [modificationSource, setModificationSource] = useState<ModificationSource>('custom');
  const regenerationEnableWebResearch = Form.useWatch('enable_web_research', form) as boolean | undefined;
  const mountedRef = useRef(false);
  const requestAbortRef = useRef<AbortController | null>(null);
  const requestCancelledRef = useRef(false);
  const requestIdRef = useRef(0);
  const successTimeoutRef = useRef<number | null>(null);

  const repairGuidanceDisplay = getRepairGuidanceDisplay(repairGuidance);
  const effectiveQualityGate = qualityGate ?? qualityMetricsSummary?.quality_gate ?? null;
  const recommendedFocusAreas = (repairGuidanceDisplay?.rawFocusAreas || []).filter((item) =>
    FOCUS_AREA_OPTIONS.some((option) => option.value === item),
  );
  const recommendedRepairDefaults = getQualityGateRecommendedDefaults(effectiveQualityGate);
  const recommendedFocusAreasKey = recommendedFocusAreas.join(',');
  const recommendedRepairDefaultsKey = [
    recommendedRepairDefaults.creative_mode || '',
    recommendedRepairDefaults.story_focus || '',
    recommendedRepairDefaults.quality_preset || '',
  ].join(',');
  const hasRepairGuidance = Boolean(
    repairGuidanceDisplay?.summary
      || repairGuidanceDisplay?.repairTargets.length
      || repairGuidanceDisplay?.preserveStrengths.length,
  );
  const recentFocusAreas = (qualityMetricsSummary?.recent_focus_areas || []).filter(Boolean);
  const recentFailedMetricCounts = (qualityMetricsSummary?.recent_failed_metric_counts || []).filter((item) => Boolean(item?.label || item?.key));
  const qualityGateCounts = qualityMetricsSummary?.quality_gate_counts || null;
  const qualityGateSignalCount = (qualityGateCounts?.pass ?? 0) + (qualityGateCounts?.repairable ?? 0) + (qualityGateCounts?.blocked ?? 0);
  const continuityWarningCount = effectiveQualityGate?.continuity_warning_count
    ?? qualityMetricsSummary?.continuity_preflight?.warning_count
    ?? 0;
  const trendDirection = qualityMetricsSummary?.overall_score_trend;
  const trendDelta = qualityMetricsSummary?.overall_score_delta;
  const trendLabel = getQualityTrendLabel(trendDirection);
  const trendColor = trendDirection === 'rising' ? 'green' : trendDirection === 'falling' ? 'red' : 'blue';
  const hasQualitySignals = Boolean(
    effectiveQualityGate?.summary
      || effectiveQualityGate?.recommended_action_label
      || recentFocusAreas.length
      || recentFailedMetricCounts.length
      || continuityWarningCount
      || qualityGateSignalCount
      || trendLabel,
  );

  const clearSuccessTimeout = () => {
    if (successTimeoutRef.current !== null) {
      window.clearTimeout(successTimeoutRef.current);
      successTimeoutRef.current = null;
    }
  };

  const cancelActiveRequest = () => {
    requestCancelledRef.current = true;
    requestIdRef.current += 1;
    requestAbortRef.current?.abort();
    requestAbortRef.current = null;
    clearSuccessTimeout();
  };

  const beginRequest = () => {
    requestCancelledRef.current = false;
    const nextRequestId = requestIdRef.current + 1;
    requestIdRef.current = nextRequestId;
    return nextRequestId;
  };

  const isRequestActive = (requestId: number) => (
    mountedRef.current
    && !requestCancelledRef.current
    && requestIdRef.current === requestId
  );

  useEffect(() => {
    mountedRef.current = true;

    return () => {
      mountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (!visible) {
      cancelActiveRequest();
      return;
    }

    const defaultSource: ModificationSource = hasAnalysis && suggestions.length > 0 ? 'mixed' : 'custom';

    beginRequest();
    setLoading(false);
    setStatus('idle');
    setProgress(0);
    setErrorMessage('');
    setWordCount(0);
    setSelectedSuggestions([]);
    setModificationSource(defaultSource);

    form.resetFields();
    form.setFieldsValue({
      modification_source: defaultSource,
      target_word_count: 3000,
      preserve_structure: false,
      preserve_character_traits: true,
      focus_areas: recommendedFocusAreas,
      enable_web_research: false,
      web_research_query: '',
      ...recommendedRepairDefaults,
    });
  }, [
    visible,
    hasAnalysis,
    suggestions.length,
    form,
    recommendedFocusAreas,
    recommendedRepairDefaults,
    recommendedFocusAreasKey,
    recommendedRepairDefaultsKey,
  ]);

  useEffect(() => {
    return () => {
      cancelActiveRequest();
    };
  }, []);

  const handleSubmit = async () => {
    let abortController: AbortController | null = null;

    try {
      const values = await form.validateFields();
      const hasCustomInstructions = Boolean(values.custom_instructions?.trim());
      const hasFocusAreas = Array.isArray(values.focus_areas) && values.focus_areas.length > 0;

      if (values.modification_source === 'custom' && !hasCustomInstructions && !hasFocusAreas && !hasRepairGuidance) {
        message.error('请输入自定义修改要求，或直接使用自动修复建议 / 重点优化方向。');
        return;
      }

      if (values.modification_source === 'analysis_suggestions' && selectedSuggestions.length === 0) {
        message.error('请选择至少一条分析建议。');
        return;
      }

      if (
        values.modification_source === 'mixed'
        && selectedSuggestions.length === 0
        && !hasCustomInstructions
        && !hasFocusAreas
        && !hasRepairGuidance
      ) {
        message.error('请至少选择一条建议、输入自定义要求，或直接使用自动修复建议 / 重点优化方向。');
        return;
      }

      cancelActiveRequest();
      const requestId = beginRequest();
      abortController = new AbortController();
      requestAbortRef.current = abortController;

      setLoading(true);
      setStatus('generating');
      setProgress(0);
      setWordCount(0);
      setErrorMessage('');
      setProgressMessage('正在重新生成...');

      const requestData: RegenerationRequest = {
        modification_source: values.modification_source,
        custom_instructions: values.custom_instructions,
        selected_suggestion_indices: selectedSuggestions,
        preserve_elements: {
          preserve_structure: Boolean(values.preserve_structure),
          preserve_dialogues: values.preserve_dialogues || [],
          preserve_plot_points: values.preserve_plot_points || [],
          preserve_character_traits: values.preserve_character_traits !== false,
        },
        style_id: values.style_id,
        target_word_count: values.target_word_count,
        focus_areas: values.focus_areas || [],
        creative_mode: values.creative_mode,
        story_focus: values.story_focus,
        plot_stage: values.plot_stage,
        story_creation_brief: values.story_creation_brief,
        quality_preset: values.quality_preset,
        quality_notes: values.quality_notes,
        enable_web_research: values.enable_web_research,
        web_research_query: values.enable_web_research && values.web_research_query?.trim()
          ? values.web_research_query.trim()
          : undefined,
        story_repair_summary: repairGuidanceDisplay?.summary || undefined,
        story_repair_targets: repairGuidanceDisplay?.repairTargets.length
          ? repairGuidanceDisplay.repairTargets.slice(0, 3)
          : undefined,
        story_preserve_strengths: repairGuidanceDisplay?.preserveStrengths.length
          ? repairGuidanceDisplay.preserveStrengths.slice(0, 2)
          : undefined,
      };

      const result = await chapterPartialRegenerationApi.regenerateChapterInBackground(
        chapterId,
        requestData,
        {
          signal: abortController.signal,
          inactivityTimeoutMs: REGENERATION_STREAM_INACTIVITY_TIMEOUT_MS,
          onProgress: (msg: string, nextProgress: number, _status: string, nextWordCount?: number) => {
            if (!isRequestActive(requestId)) {
              return;
            }
            setProgress(nextProgress);
            setProgressMessage(msg || '正在重新生成...');
            if (nextWordCount !== undefined) {
              setWordCount(nextWordCount);
            }
          },
          onHeartbeat: () => {
            if (!isRequestActive(requestId)) {
              return;
            }
            setProgressMessage((prev) => appendRegenerationHeartbeatHint(prev || '正在重新生成...'));
          },
          onError: (error: string, code?: number) => {
            if (!isRequestActive(requestId)) {
              return;
            }
            console.error('SSE Error:', error, code);
            setStatus('error');
            setErrorMessage(error || '生成失败');
            message.error(`生成失败: ${error || '生成失败'}`);
          },
        },
        currentProjectId,
      );

      if (!isRequestActive(requestId)) {
        return;
      }
      const regeneratedContent = result.content || '';
      const finalWordCount = result.word_count || regeneratedContent.length;
      setProgress(100);
      setStatus('success');
      setProgressMessage('生成完成');
      setWordCount(finalWordCount);
      message.success('重新生成完成。');

      successTimeoutRef.current = window.setTimeout(() => {
        if (!isRequestActive(requestId)) {
          return;
        }
        onSuccess(regeneratedContent, finalWordCount);
      }, 500);
    } catch (error: unknown) {
      const err = error as Error;
      if (requestCancelledRef.current || err.name === 'AbortError') {
        return;
      }
      if (!mountedRef.current) {
        return;
      }
      console.error('生成失败:', error);
      setStatus('error');
      setErrorMessage(err.message || '生成失败');
      message.error(`生成失败: ${err.message || '生成失败'}`);
    } finally {
      if (abortController && requestAbortRef.current === abortController) {
        requestAbortRef.current = null;
      }
      if (mountedRef.current && !requestCancelledRef.current) {
        setLoading(false);
      }
    }
  };

  const handleSuggestionSelect = (index: number, checked: boolean) => {
    if (checked) {
      setSelectedSuggestions((current) => [...current, index]);
      return;
    }
    setSelectedSuggestions((current) => current.filter((item) => item !== index));
  };

  const handleCancel = () => {
    if (!loading) {
      onCancel();
      return;
    }

    modal.confirm({
      title: '确认取消',
      content: '生成正在进行中，确定要取消吗？',
      centered: true,
      onOk: () => {
        cancelActiveRequest();
        setLoading(false);
        setStatus('idle');
        onCancel();
      },
    });
  };

  const regenerationGuideSteps = [
    '先确认这轮重写主要依赖自定义要求、分析建议还是混合模式，再决定本章的修订主线。',
    '再补充重点方向、保留策略和联网检索，把“重写约束”放在真正提交任务之前校准清楚。',
    '最后再开始重生成；进入运行态后优先观察进度、质量信号与修复建议，不要频繁重开新的重写请求。',
  ];
  const regenerationWorkspaceFocus = status === 'generating'
    ? {
        title: `跟进第 ${chapterNumber} 章的重生成进度`,
        note: '当前后台任务已经启动，适合先观察生成进度、字数与质量提示，再决定下一轮是否继续追加修复要求。',
      }
    : status === 'success'
      ? {
          title: '复核这一版重生成结果',
          note: '当前已经得到新的章节结果，适合先确认字数、牵引和修复效果，再决定是否接受本轮输出。',
        }
      : status === 'error'
        ? {
            title: '先处理这轮重生成阻塞',
            note: '当前请求已经返回错误，适合先看失败信息和配置条件，再重新发起下一次重写。',
          }
        : regenerationEnableWebResearch
          ? {
              title: '确认是否需要外部资料支撑',
              note: '当前已经开启联网检索，适合先确认职业、时代、规则或场景细节是否真的值得引入额外上下文。',
            }
          : modificationSource === 'analysis_suggestions' && selectedSuggestions.length === 0
            ? {
                title: '先勾选本轮要采纳的分析建议',
                note: '当前以分析建议为主，但还没有选择具体建议，适合先缩小修订目标，再提交这一轮重生成。',
              }
            : hasRepairGuidance
              ? {
                  title: '围绕自动修复建议组织这轮重写',
                  note: '当前已经加载修复摘要、短板与保留优势，适合先让这一轮信息收敛，再补充少量自定义要求。',
                }
              : {
                  title: '定义本章这一轮的重写目标',
                  note: '当前更适合先说清楚章末牵引、情绪浓度、结构保留与重点方向，再把请求交给现有重生成链路。',
                };

  const sectionLabelStyle = {
    display: 'block',
    fontSize: 11,
    letterSpacing: '0.08em',
    textTransform: 'uppercase' as const,
    color: token.colorTextTertiary,
    marginBottom: 6,
  };

  return (
    <>
      {contextHolder}
      <Modal
        title={(
          <div>
            <Text style={sectionLabelStyle}>Chapter Regeneration</Text>
            <Text strong style={{ display: 'block', fontSize: 18, marginBottom: 4 }}>
              重新生成章节
            </Text>
            <Text type="secondary">
              第{chapterNumber}章：{chapterTitle}
            </Text>
          </div>
        )}
        open={visible}
        onCancel={handleCancel}
        width={860}
        centered
        styles={{
          body: {
            maxHeight: 'calc(100vh - 220px)',
            overflowY: 'auto',
            overflowX: 'hidden',
          },
        }}
        footer={
          status === 'success'
            ? null
            : [
                <Button key="cancel" onClick={handleCancel} disabled={loading}>
                  取消
                </Button>,
                <Button
                  key="submit"
                  type="primary"
                  onClick={handleSubmit}
                  loading={loading}
                  icon={<ReloadOutlined />}
                >
                  开始重新生成
                </Button>,
              ]
        }
      >
        <Card
          size="small"
          style={{
            marginBottom: 16,
            borderRadius: 22,
            border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
            background: `linear-gradient(135deg, ${alphaColor(token.colorPrimaryBg, 0.84)} 0%, ${alphaColor(token.colorBgContainer, 0.98)} 100%)`,
          }}
          styles={{ body: { padding: 16 } }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 16,
            }}
          >
            <div>
              <Text style={sectionLabelStyle}>Regeneration Guide</Text>
              <Text strong style={{ display: 'block', fontSize: 17, marginBottom: 8 }}>
                本章重生成工作台
              </Text>
              <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
                这里不会改变原有后台任务逻辑，只是把本章重写的配置顺序和判断重点提前说明，帮助你更稳定地组织这一轮修订请求。
              </Text>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {regenerationGuideSteps.map((item, index) => (
                  <span
                    key={item}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '6px 12px',
                      borderRadius: 999,
                      background: token.colorBgContainer,
                      border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
                      color: token.colorText,
                      fontSize: 12,
                    }}
                  >
                    <span style={{ color: token.colorPrimary, fontWeight: 700 }}>{index + 1}</span>
                    {item}
                  </span>
                ))}
              </div>
            </div>
            <div
              style={{
                borderRadius: 18,
                padding: '16px 18px 14px',
                background: `linear-gradient(180deg, ${alphaColor(token.colorBgContainer, 0.98)} 0%, ${alphaColor(token.colorFillQuaternary, 0.5)} 100%)`,
                border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
              }}
            >
              <Text style={sectionLabelStyle}>当前工作焦点</Text>
              <Text strong style={{ display: 'block', fontSize: 16, marginBottom: 8 }}>
                {regenerationWorkspaceFocus.title}
              </Text>
              <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
                {regenerationWorkspaceFocus.note}
              </Text>
              <Space wrap size={[8, 8]}>
                <Tag color="blue">第 {chapterNumber} 章</Tag>
                <Tag color="purple">建议 {suggestions.length} 条</Tag>
                <Tag color={hasAnalysis ? 'green' : 'default'}>{hasAnalysis ? '已加载分析结果' : '无章节分析'}</Tag>
                <Tag color={hasRepairGuidance ? 'orange' : 'default'}>{hasRepairGuidance ? '已加载自动修复建议' : '未启用自动修复建议'}</Tag>
              </Space>
            </div>
          </div>
        </Card>

        {status === 'success' && (
          <Alert
            message="重新生成成功"
            description={`共生成 ${wordCount} 字`}
            type="success"
            showIcon
            icon={<CheckCircleOutlined />}
            style={{ marginBottom: 16 }}
          />
        )}

        {status === 'error' && (
          <Alert
            message="生成失败"
            description={errorMessage}
            type="error"
            showIcon
            icon={<CloseCircleOutlined />}
            style={{ marginBottom: 16 }}
          />
        )}

        {repairGuidanceDisplay && (
          <Alert
            type="info"
            showIcon
            style={{
              marginBottom: 16,
              borderRadius: 18,
              border: `1px solid ${alphaColor(token.colorInfo, 0.16)}`,
              background: `linear-gradient(135deg, ${alphaColor(token.colorInfoBg, 0.94)} 0%, ${alphaColor(token.colorBgContainer, 0.98)} 100%)`,
            }}
            message="已加载自动修复建议"
            description={(
              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                {repairGuidanceDisplay.summary && <span>{repairGuidanceDisplay.summary}</span>}

                {repairGuidanceDisplay.weakestMetricLabel && (
                  <div>
                    <Tag color="orange">当前短板</Tag>
                    <span>
                      {repairGuidanceDisplay.weakestMetricLabel}
                      {typeof repairGuidanceDisplay.weakestMetricValue === 'number'
                        ? ` ${repairGuidanceDisplay.weakestMetricValue.toFixed(1)}`
                        : ''}
                    </span>
                  </div>
                )}

                {repairGuidanceDisplay.repairTargets.length > 0 && (
                  <div>
                    <strong>下一轮修复：</strong>
                    <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {repairGuidanceDisplay.repairTargets.map((item) => (
                        <Tag key={item} color="blue">
                          {item}
                        </Tag>
                      ))}
                    </div>
                  </div>
                )}

                {repairGuidanceDisplay.preserveStrengths.length > 0 && (
                  <div>
                    <strong>保留优势：</strong>
                    <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {repairGuidanceDisplay.preserveStrengths.map((item) => (
                        <Tag key={item} color="green">
                          {item}
                        </Tag>
                      ))}
                    </div>
                  </div>
                )}

                {recommendedFocusAreas.length > 0 && (
                  <div>
                    <strong>已预选重点方向：</strong>
                    <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {recommendedFocusAreas.map((area) => (
                        <Tag key={area}>{getFocusAreaLabel(area)}</Tag>
                      ))}
                    </div>
                  </div>
                )}
              </Space>
            )}
          />
        )}

        {hasQualitySignals && (
          <Alert
            type={effectiveQualityGate?.requires_manual_review ? 'warning' : 'info'}
            showIcon
            style={{
              marginBottom: 16,
              borderRadius: 18,
              border: `1px solid ${alphaColor(effectiveQualityGate?.requires_manual_review ? token.colorWarning : token.colorInfo, 0.16)}`,
              background: effectiveQualityGate?.requires_manual_review
                ? `linear-gradient(135deg, ${alphaColor(token.colorWarningBg, 0.94)} 0%, ${alphaColor(token.colorBgContainer, 0.98)} 100%)`
                : `linear-gradient(135deg, ${alphaColor(token.colorInfoBg, 0.94)} 0%, ${alphaColor(token.colorBgContainer, 0.98)} 100%)`,
            }}
            message="最近质量信号"
            description={(
              <Space direction="vertical" size={8} style={{ width: '100%' }}>
                {effectiveQualityGate?.summary && <span>{effectiveQualityGate.summary}</span>}

                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {trendLabel && (
                    <Tag color={trendColor}>
                      {trendLabel}
                      {typeof trendDelta === 'number' ? ` ${trendDelta > 0 ? '+' : ''}${trendDelta.toFixed(1)}` : ''}
                    </Tag>
                  )}
                  {(qualityGateCounts?.blocked ?? 0) > 0 && <Tag color="red">人工复核 {(qualityGateCounts?.blocked ?? 0)}</Tag>}
                  {(qualityGateCounts?.repairable ?? 0) > 0 && <Tag color="orange">自动修复 {(qualityGateCounts?.repairable ?? 0)}</Tag>}
                  {(qualityGateCounts?.pass ?? 0) > 0 && <Tag color="green">通过 {(qualityGateCounts?.pass ?? 0)}</Tag>}
                  {continuityWarningCount > 0 && <Tag color="gold">连续性预警 {continuityWarningCount}</Tag>}
                </div>

                {effectiveQualityGate?.recommended_action_label && (
                  <div>
                    <strong>建议动作：</strong>
                    <Tag color="magenta" style={{ marginLeft: 8 }}>
                      {effectiveQualityGate.recommended_action_label}
                    </Tag>
                  </div>
                )}

                {recentFailedMetricCounts.length > 0 && (
                  <div>
                    <strong>最近反复失分：</strong>
                    <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {recentFailedMetricCounts.map((item) => (
                        <Tag key={`${item.key || item.label}-${item.count || 0}`} color="volcano">
                          {item.label || item.key}
                          {typeof item.count === 'number' ? ` ×${item.count}` : ''}
                        </Tag>
                      ))}
                    </div>
                  </div>
                )}

                {recentFocusAreas.length > 0 && (
                  <div>
                    <strong>建议动作：</strong>
                    <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                      {recentFocusAreas.map((area) => (
                        <Tag key={area}>{getFocusAreaLabel(area)}</Tag>
                      ))}
                    </div>
                  </div>
                )}
              </Space>
            )}
          />
        )}

        <Form form={form} layout="vertical" disabled={loading || status === 'success'}>
          <Card
            size="small"
            style={{
              marginBottom: 16,
              borderRadius: 20,
              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.9)}`,
              background: alphaColor(token.colorBgContainer, 0.98),
            }}
            styles={{ body: { padding: 16 } }}
          >
            <Text style={sectionLabelStyle}>Modification Source</Text>
            <Text strong style={{ display: 'block', marginBottom: 8 }}>
              修改来源
            </Text>
            <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 14 }}>
              选择这一轮更依赖你的主动要求、章节分析建议，还是把两者混合起来使用。
            </Text>
            <Form.Item
              name="modification_source"
              label="修改来源"
              rules={[{ required: true, message: '请选择修改来源。' }]}
              style={{ marginBottom: 0 }}
            >
              <Radio.Group onChange={(event) => setModificationSource(event.target.value)}>
                <Radio value="custom">仅自定义修改</Radio>
                {hasAnalysis && suggestions.length > 0 && (
                  <>
                    <Radio value="analysis_suggestions">仅分析建议</Radio>
                    <Radio value="mixed">混合模式</Radio>
                  </>
                )}
              </Radio.Group>
            </Form.Item>
          </Card>

          {hasAnalysis && suggestions.length > 0 && (
            (modificationSource === 'analysis_suggestions' || modificationSource === 'mixed') && (
              <Form.Item label={`选择分析建议 (${selectedSuggestions.length}/${suggestions.length})`}>
                <Card
                  size="small"
                  style={{
                    maxHeight: 320,
                    overflow: 'auto',
                    borderRadius: 18,
                    border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                    background: `linear-gradient(180deg, ${alphaColor(token.colorBgElevated, 0.98)} 0%, ${alphaColor(token.colorFillQuaternary, 0.48)} 100%)`,
                  }}
                >
                  <Space direction="vertical" style={{ width: '100%' }}>
                    {suggestions.map((suggestion, index) => (
                      <Checkbox
                        key={index}
                        checked={selectedSuggestions.includes(index)}
                        onChange={(event) => handleSuggestionSelect(index, event.target.checked)}
                      >
                        <Space>
                          <Tag
                            color={
                              suggestion.priority === 'high'
                                ? 'red'
                              : suggestion.priority === 'medium'
                                  ? 'orange'
                                  : 'blue'
                            }
                          >
                            {suggestion.category}
                          </Tag>
                          <span style={{ fontSize: 13 }}>{suggestion.content}</span>
                        </Space>
                      </Checkbox>
                    ))}
                  </Space>
                </Card>
              </Form.Item>
            )
          )}

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: 16,
              alignItems: 'start',
              marginBottom: 16,
            }}
          >
            {(modificationSource === 'custom' || modificationSource === 'mixed') && (
              <Card
                size="small"
                style={{
                  borderRadius: 20,
                  border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.9)}`,
                  background: alphaColor(token.colorBgContainer, 0.98),
                }}
                styles={{ body: { padding: 16 } }}
              >
                <Text style={sectionLabelStyle}>Custom Instructions</Text>
                <Text strong style={{ display: 'block', marginBottom: 8 }}>
                  自定义修改要求
                </Text>
                <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 14 }}>
                  把你最在意的调整目标说清楚，例如章末牵引、情绪浓度、冲突强度或叙事克制感。
                </Text>
                <Form.Item
                  name="custom_instructions"
                  label="自定义修改要求"
                  tooltip="描述你希望如何改进这一章。"
                  extra={repairGuidanceDisplay ? '若留空，系统会结合自动修复建议与重点方向进行重生成。' : undefined}
                  style={{ marginBottom: 0 }}
                >
                  <TextArea
                    rows={6}
                    placeholder="例如：增强情绪张力，保持主角行为逻辑一致，并在章末留下更强的牵引。"
                    showCount
                    maxLength={1000}
                  />
                </Form.Item>
              </Card>
            )}

            <Card
              size="small"
              style={{
                borderRadius: 20,
                border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.9)}`,
                background: `linear-gradient(180deg, ${alphaColor(token.colorBgElevated, 0.98)} 0%, ${alphaColor(token.colorFillQuaternary, 0.46)} 100%)`,
              }}
              styles={{ body: { padding: 16 } }}
            >
              <Text style={sectionLabelStyle}>Web Research</Text>
              <Text strong style={{ display: 'block', marginBottom: 8 }}>
                联网检索
              </Text>
              <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 14 }}>
                当章节涉及职业、时代、规则或场景细节时，先补外部资料再重生成，通常会更稳。
              </Text>
              <Form.Item
                name="enable_web_research"
                label="联网检索"
                valuePropName="checked"
                tooltip="重生成前补充实时外部参考，适合职业、时代、场景、规则等细节型章节。"
                style={{ marginBottom: regenerationEnableWebResearch ? 12 : 0 }}
              >
                <div>
                  <Switch checkedChildren="开启" unCheckedChildren="关闭" />
                  <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginTop: 6 }}>
                    开启后会先补充外部资料，再注入整章重生成提示词，帮助提升设定落地与细节可信度。
                  </div>
                </div>
              </Form.Item>

              {regenerationEnableWebResearch && (
                <Form.Item
                  name="web_research_query"
                  label="联网检索查询词"
                  tooltip="可留空，系统会根据当前章节内容与重生成要求自动生成查询词。"
                  style={{ marginBottom: 0 }}
                >
                  <TextArea
                    rows={3}
                    placeholder="例如：民国巡捕房办案流程、古代驿站制度、夜市摊贩吆喝细节"
                    showCount
                    maxLength={300}
                  />
                </Form.Item>
              )}
            </Card>
          </div>

          <Collapse
            ghost
            style={{
              marginBottom: 8,
              borderRadius: 20,
              overflow: 'hidden',
              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
              background: alphaColor(token.colorBgContainer, 0.96),
              padding: '2px 12px',
            }}
          >
            <Panel header="高级选项" key="advanced">
              <Form.Item name="focus_areas" label="重点优化方向">
                <Checkbox.Group>
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
                      gap: 8,
                    }}
                  >
                    {FOCUS_AREA_OPTIONS.map((option) => (
                      <Checkbox key={option.value} value={option.value}>
                        {option.label}
                      </Checkbox>
                    ))}
                  </div>
                </Checkbox.Group>
              </Form.Item>

              <Divider />

              <Form.Item
                name="creative_mode"
                label="创作模式"
                tooltip="显式指定这一轮重生成更偏向的创作模式。"
              >
                <Select allowClear placeholder="默认沿用项目偏好" optionLabelProp="label">
                  {CREATIVE_MODE_OPTIONS.map((option) => (
                    <Select.Option key={option.value} value={option.value} label={option.label}>
                      <div>{option.label}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>{option.description}</div>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item
                name="story_focus"
                label="结构侧重点"
                tooltip="指定本轮重生成优先承担的叙事任务。"
              >
                <Select allowClear placeholder="默认沿用项目偏好" optionLabelProp="label">
                  {STORY_FOCUS_OPTIONS.map((option) => (
                    <Select.Option key={option.value} value={option.value} label={option.label}>
                      <div>{option.label}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>{option.description}</div>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item
                name="plot_stage"
                label="剧情阶段"
                tooltip="帮助系统理解当前章节更像铺陈、高潮还是收束回收。"
              >
                <Select allowClear placeholder="默认沿用项目偏好" optionLabelProp="label">
                  {PLOT_STAGE_OPTIONS.map((option) => (
                    <Select.Option key={option.value} value={option.value} label={option.label}>
                      <div>{option.label}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>{option.description}</div>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item
                name="story_creation_brief"
                label="创作总控摘要"
                tooltip="用几句话告诉系统这一轮重生成必须守住的目标、节奏和约束。"
              >
                <TextArea
                  rows={3}
                  placeholder="例如：优先补强这一章的情绪拉扯和结尾牵引，减少解释性旁白，让冲突与选择自己落地。"
                  showCount
                  maxLength={600}
                />
              </Form.Item>

              <Form.Item
                name="quality_preset"
                label="质量预设"
                tooltip="为这一轮重生成施加统一质量偏好，控制更偏推进、氛围、情绪或干净表达。"
              >
                <Select allowClear placeholder="默认沿用项目偏好" optionLabelProp="label">
                  {QUALITY_PRESET_OPTIONS.map((option) => (
                    <Select.Option key={option.value} value={option.value} label={option.label}>
                      <div>{option.label}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>{option.description}</div>
                      <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>适合：{option.bestFor}</div>
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>

              <Form.Item
                name="quality_notes"
                label="额外质量要求"
                tooltip="补充这一轮重生成需要特别强化或压制的表达习惯。"
              >
                <TextArea
                  rows={3}
                  placeholder="例如：减少解释性总结，优先通过动作、对话和场景细节传递情绪变化。"
                  showCount
                  maxLength={600}
                />
              </Form.Item>

              <Divider />

              <Form.Item label="保留元素">
                <Space direction="vertical" style={{ width: '100%' }}>
                  <Form.Item name="preserve_structure" valuePropName="checked" noStyle>
                    <Checkbox>保留整体结构和情节框架</Checkbox>
                  </Form.Item>
                  <Form.Item name="preserve_character_traits" valuePropName="checked" noStyle>
                    <Checkbox>保持角色性格一致</Checkbox>
                  </Form.Item>
                </Space>
              </Form.Item>

              <Divider />

              <Form.Item
                name="target_word_count"
                label="目标字数"
                tooltip="生成内容的目标字数，实际结果可能存在一定浮动。"
              >
                <InputNumber min={500} max={10000} step={500} style={{ width: '100%' }} />
              </Form.Item>
            </Panel>
          </Collapse>
        </Form>

        <SSEProgressModal
          visible={status === 'generating'}
          progress={progress}
          message={`${progressMessage || '正在重新生成...'} · 已生成 ${wordCount} 字`}
          title="重新生成章节"
          blocking={false}
        />
      </Modal>
    </>
  );
};

export default ChapterRegenerationModal;
