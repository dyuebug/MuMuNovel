import { Suspense, lazy, useEffect, useRef, useState } from 'react';
import { Modal, Spin, Alert, Tabs, Card, Tag, List, Empty, Statistic, Row, Col, Button, message, Space, Typography, theme } from 'antd';
import {
  ThunderboltOutlined,
  BulbOutlined,
  FireOutlined,
  HeartOutlined,
  TeamOutlined,
  TrophyOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  ReloadOutlined,
  EditOutlined
} from '@ant-design/icons';
import type { AnalysisTask, ChapterAnalysisResponse } from '../types';
import { chapterApi } from '../services/modularApi';
import { getAxiosErrorStatus, isRequestCancelledError, silentRequestConfig } from '../services/core/httpClient';
import { getQualityTrendLabel } from '../utils/storyCreationQualitySummary';
import { MAX_CONSECUTIVE_TASK_POLL_ERRORS } from '../utils/taskPolling';
import { isAnalysisTaskRetrying } from '../utils/analysisTasks';
import InlineDeferredPanel from './InlineDeferredPanel';
import WorkflowEntryFallback from './WorkflowEntryFallback';

const { Text } = Typography;

// 判断是否为移动设备
const LazyChapterRegenerationModal = lazy(() => import('./ChapterRegenerationModal'));
const LazyChapterContentComparison = lazy(() => import('./ChapterContentComparison'));

const isMobileDevice = () => window.innerWidth < 768;

const isChapterAnalysisNotFoundError = (error: unknown) => {
  if (getAxiosErrorStatus(error) !== 404) {
    return false;
  }

  const detail = (error as { response?: { data?: { detail?: unknown } } }).response?.data?.detail;
  return detail === 'Chapter analysis not found' || (error as Error).message === 'Chapter analysis not found';
};

const ANALYSIS_PLOT_STAGE_LABELS: Record<string, string> = {
  development: '发展阶段',
  climax: '高潮阶段',
  ending: '结局阶段',
};

const ANALYSIS_MEMORY_TYPE_LABELS: Record<string, string> = {
  chapter_summary: '章节摘要',
  hook: '钩子',
  foreshadow: '伏笔',
  plot_point: '情节点',
  character_event: '角色事件',
};

const ANALYSIS_INLINE_TERM_LABELS: Array<[string, string]> = [
  ['chapter_summary', '章节摘要'],
  ['character_event', '角色事件'],
  ['plot_point', '情节点'],
  ['foreshadow', '伏笔'],
  ['hook', '钩子'],
  ['revelation', '揭示'],
  ['resolution', '解决'],
  ['transition', '过渡'],
  ['conflict', '冲突'],
  ['planted', '已埋下'],
  ['resolved', '已回收'],
];

const ANALYSIS_QUALITY_FOCUS_LABELS: Record<string, string> = {
  conflict: "冲突链推进",
  rule_grounding: "规则落地",
  outline: "大纲贴合",
  dialogue: "对白自然度",
  opening: "开场钩子",
  payoff: "回报兑现",
  cliffhanger: "章尾牵引",
  pacing: "节奏稳定度",
  relationship_continuity: "关系连续性",
  foreshadow_continuity: "伏笔连续性",
  character_continuity: "角色连续性",
  organization_continuity: "组织连续性",
  career_continuity: "职业成长连续性",
};

const ANALYSIS_HOOK_TYPE_LABELS: Record<string, string> = {
  opening: '开场钩子',
  conflict: '冲突钩子',
  emotional: '情绪钩子',
  suspense: '悬念钩子',
  mystery: '谜团钩子',
  reversal: '反转钩子',
  payoff: '回报钩子',
  cliffhanger: '章尾钩子',
};

const ANALYSIS_HOOK_POSITION_LABELS: Record<string, string> = {
  beginning: '开头',
  opening: '开头',
  middle: '中段',
  ending: '结尾',
  end: '结尾',
  closing: '结尾',
};

const ANALYSIS_EMOTION_LABELS: Record<string, string> = {
  joy: '喜悦',
  sadness: '悲伤',
  anger: '愤怒',
  fear: '恐惧',
  surprise: '惊讶',
  anticipation: '期待',
  tension: '紧张',
  relief: '释然',
  anxiety: '焦虑',
  calm: '平静',
  excitement: '兴奋',
};

const ANALYSIS_CONFLICT_TYPE_LABELS: Record<string, string> = {
  internal: '内在冲突',
  interpersonal: '人际冲突',
  external: '外部冲突',
  environmental: '环境冲突',
  ideological: '观念冲突',
  relationship: '关系冲突',
  survival: '生存冲突',
  mystery: '谜团冲突',
};

const localizeQualityFocusArea = (value?: string | null): string => {
  if (!value) {
    return "";
  }
  return ANALYSIS_QUALITY_FOCUS_LABELS[value] || value;
};

const localizeAnalysisPlotStage = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_PLOT_STAGE_LABELS[value] || value;
};

const localizeAnalysisMemoryType = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_MEMORY_TYPE_LABELS[value] || value;
};

const localizeAnalysisMemoryText = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_INLINE_TERM_LABELS.reduce(
    (result, [source, label]) => result.replaceAll(source, label),
    value,
  );
};

const localizeHookType = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_HOOK_TYPE_LABELS[value] || value;
};

const localizeHookPosition = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_HOOK_POSITION_LABELS[value] || value;
};

const localizeEmotionLabel = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_EMOTION_LABELS[value] || value;
};

const localizeConflictType = (value?: string | null): string => {
  if (!value) {
    return '';
  }
  return ANALYSIS_CONFLICT_TYPE_LABELS[value] || value;
};

const formatAnalysisScore = (value: unknown, digits = 1): string => {
  const normalized = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  return normalized.toFixed(digits);
};

const formatAnalysisInteger = (value: unknown): number => (
  typeof value === 'number' && Number.isFinite(value) ? value : 0
);

const formatAnalysisTextList = (value: unknown): string[] => (
  Array.isArray(value) ? value.filter((item): item is string => typeof item === 'string' && item.trim().length > 0) : []
);

interface ChapterAnalysisProps {
  chapterId: string;
  visible: boolean;
  onClose: () => void;
}

const areAnalysisTasksEqual = (left?: AnalysisTask | null, right?: AnalysisTask | null): boolean => {
  if (!left || !right) {
    return left === right;
  }

  return (
    left.has_task === right.has_task
    && left.task_id === right.task_id
    && left.chapter_id === right.chapter_id
    && left.status === right.status
    && left.progress === right.progress
    && left.error_message === right.error_message
    && left.error_code === right.error_code
    && left.auto_recovered === right.auto_recovered
    && left.created_at === right.created_at
    && left.started_at === right.started_at
    && left.completed_at === right.completed_at
  );
};

const areAnalysisResultsEqual = (
  left?: ChapterAnalysisResponse | null,
  right?: ChapterAnalysisResponse | null,
): boolean => {
  if (!left || !right) {
    return left === right;
  }

  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch {
    return false;
  }
};

export default function ChapterAnalysis({ chapterId, visible, onClose }: ChapterAnalysisProps) {
  const { token } = theme.useToken();
  const [task, setTask] = useState<AnalysisTask | null>(null);
  const [analysis, setAnalysis] = useState<ChapterAnalysisResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(isMobileDevice());
  const [regenerationModalVisible, setRegenerationModalVisible] = useState(false);
  const [comparisonModalVisible, setComparisonModalVisible] = useState(false);
  const [draftPreviewVisible, setDraftPreviewVisible] = useState(false);
  const [draftPreviewLoading, setDraftPreviewLoading] = useState(false);
  const [applyingDraft, setApplyingDraft] = useState(false);
  const [chapterInfo, setChapterInfo] = useState<{ title: string; chapter_number: number; content: string; project_id?: string } | null>(null);
  const [draftContent, setDraftContent] = useState('');
  const [newGeneratedContent, setNewGeneratedContent] = useState('');
  const [newContentWordCount, setNewContentWordCount] = useState(0);
  const pollIntervalRef = useRef<number | null>(null);
  const pollTimeoutRef = useRef<number | null>(null);
  const pollErrorCountRef = useRef(0);
  const requestAbortRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);
  const draftPreviewRequestIdRef = useRef(0);
  const draftApplyRequestIdRef = useRef(0);
  const taskRef = useRef<AnalysisTask | null>(null);
  const analysisRef = useRef<ChapterAnalysisResponse | null>(null);

  const stopPolling = () => {
    if (pollIntervalRef.current) {
      window.clearInterval(pollIntervalRef.current);
      pollIntervalRef.current = null;
    }
    if (pollTimeoutRef.current) {
      window.clearTimeout(pollTimeoutRef.current);
      pollTimeoutRef.current = null;
    }
    pollErrorCountRef.current = 0;
  };

  const abortActiveRequest = () => {
    requestAbortRef.current?.abort();
    requestAbortRef.current = null;
  };

  const beginRequest = () => {
    abortActiveRequest();
    const abortController = new AbortController();
    requestAbortRef.current = abortController;
    return abortController;
  };

  useEffect(() => {
    mountedRef.current = true;
    if (visible && chapterId) {
      void fetchAnalysisStatus();
    }

    const handleResize = () => {
      setIsMobile(isMobileDevice());
    };

    window.addEventListener('resize', handleResize);

    return () => {
      mountedRef.current = false;
      draftPreviewRequestIdRef.current += 1;
      draftApplyRequestIdRef.current += 1;
      window.removeEventListener('resize', handleResize);
      abortActiveRequest();
      stopPolling();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, chapterId]);

  useEffect(() => {
    taskRef.current = task;
  }, [task]);

  useEffect(() => {
    analysisRef.current = analysis;
  }, [analysis]);

  const updateTask = (nextTask: AnalysisTask | null) => {
    if (areAnalysisTasksEqual(taskRef.current, nextTask)) {
      return;
    }
    taskRef.current = nextTask;
    setTask(nextTask);
  };

  const updateAnalysis = (nextAnalysis: ChapterAnalysisResponse | null) => {
    if (areAnalysisResultsEqual(analysisRef.current, nextAnalysis)) {
      return;
    }
    analysisRef.current = nextAnalysis;
    setAnalysis(nextAnalysis);
  };

  const loadChapterInfo = async (signal?: AbortSignal) => {
    try {
      const chapterData = await chapterApi.getChapter(chapterId, signal ? { signal } : undefined);
      if ((signal && signal.aborted) || !mountedRef.current) {
        return null;
      }
      setChapterInfo({
        title: chapterData.title,
        chapter_number: chapterData.chapter_number,
        content: chapterData.content || '',
        project_id: chapterData.project_id,
      });
      return chapterData;
    } catch (error) {
      if (isRequestCancelledError(error)) {
        throw error;
      }
      console.error('Failed to load chapter info:', error);
      return null;
    }
  };

  const fetchAnalysisStatus = async () => {
    const abortController = beginRequest();

    try {
      setLoading(true);
      setError(null);
      setTask(null);
      setAnalysis(null);

      const chapterData = await loadChapterInfo(abortController.signal);
      if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
        return;
      }

      const taskData: AnalysisTask = await chapterApi.getChapterAnalysisStatus(
        chapterId,
        chapterData?.project_id || chapterInfo?.project_id,
        { signal: abortController.signal },
      );

      if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
        return;
      }

      if (taskData.status === 'none' || !taskData.has_task) {
        updateTask(null);
        updateAnalysis(null);
        setError(null);
        return;
      }

      updateTask(taskData);

      if (taskData.status === 'completed') {
        await fetchAnalysisResult();
      } else if (taskData.status === 'running' || taskData.status === 'pending' || isAnalysisTaskRetrying(taskData)) {
        startPolling();
      } else if (taskData.status === 'failed' && taskData.auto_recovered) {
        setError(taskData.error_message || '\u5206\u6790\u4efb\u52a1\u5df2\u81ea\u52a8\u6062\u590d\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5');
      }
    } catch (err) {
      if (isRequestCancelledError(err) || abortController.signal.aborted) {
        return;
      }
      if (mountedRef.current) {
        setError((err as Error).message);
      }
    } finally {
      if (mountedRef.current && requestAbortRef.current === abortController) {
        requestAbortRef.current = null;
        setLoading(false);
      }
    }
  };

  const fetchAnalysisResult = async () => {
    const abortController = beginRequest();

    try {
      const data: ChapterAnalysisResponse = await chapterApi.getChapterAnalysis(
        chapterId,
        false,
        silentRequestConfig({ signal: abortController.signal }),
      );
      if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
        return;
      }
      if (!data?.analysis) {
        updateAnalysis(null);
        setError('分析任务已完成，但返回结果不完整，请稍后重试或重新分析');
        return;
      }
      updateAnalysis(data);
    } catch (err) {
      if (isRequestCancelledError(err) || abortController.signal.aborted) {
        return;
      }
      if (isChapterAnalysisNotFoundError(err)) {
        updateAnalysis(null);
        setError(null);
        return;
      }
      if (mountedRef.current) {
        setError((err as Error).message);
      }
    } finally {
      if (mountedRef.current && requestAbortRef.current === abortController) {
        requestAbortRef.current = null;
      }
    }
  };

  const startPolling = () => {
    stopPolling();
    pollErrorCountRef.current = 0;

    const poll = async () => {
      const abortController = beginRequest();

      try {
        const taskData: AnalysisTask = await chapterApi.getChapterAnalysisStatus(
          chapterId,
          chapterInfo?.project_id,
          { signal: abortController.signal },
        );
        if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
          return;
        }
        pollErrorCountRef.current = 0;
        if (taskData.status === 'none' || !taskData.has_task) {
          updateTask(null);
          updateAnalysis(null);
          return;
        }
        updateTask(taskData);

        if (taskData.status === 'completed') {
          stopPolling();
          await fetchAnalysisResult();
          await loadChapterInfo();
        } else if (taskData.status === 'failed') {
          if (isAnalysisTaskRetrying(taskData)) {
            return;
          }

          stopPolling();
          setError(taskData.auto_recovered
            ? (taskData.error_message || '\u5206\u6790\u4efb\u52a1\u5df2\u81ea\u52a8\u6062\u590d\uff0c\u8bf7\u7a0d\u540e\u91cd\u8bd5')
            : (taskData.error_message || '\u5206\u6790\u5931\u8d25'));
        }
      } catch (err) {
        if (isRequestCancelledError(err) || abortController.signal.aborted) {
          return;
        }
        pollErrorCountRef.current += 1;
        console.error('Failed to poll chapter analysis status:', err);
        if (pollErrorCountRef.current < MAX_CONSECUTIVE_TASK_POLL_ERRORS) {
          return;
        }
        stopPolling();
        if (mountedRef.current) {
          setError('\u7ae0\u8282\u5206\u6790\u72b6\u6001\u540c\u6b65\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u5237\u65b0\u91cd\u8bd5');
          message.error('\u7ae0\u8282\u5206\u6790\u72b6\u6001\u540c\u6b65\u5931\u8d25\uff0c\u8bf7\u7a0d\u540e\u5237\u65b0\u91cd\u8bd5');
        }
      } finally {
        if (mountedRef.current && requestAbortRef.current === abortController) {
          requestAbortRef.current = null;
        }
      }
    };

    void poll();
    pollIntervalRef.current = window.setInterval(() => {
      void poll();
    }, 2000);

    pollTimeoutRef.current = window.setTimeout(() => {
      abortActiveRequest();
      stopPolling();
    }, 300000);
  };

  const triggerAnalysis = async () => {
    const abortController = beginRequest();

    try {
      setLoading(true);
      setError(null);
      setTask(null);
      setAnalysis(null);

      const chapterData = await loadChapterInfo(abortController.signal);
      if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
        return;
      }

      await chapterApi.triggerChapterAnalysis(
        chapterId,
        chapterData?.project_id || chapterInfo?.project_id,
      );

      if (abortController.signal.aborted || requestAbortRef.current !== abortController || !mountedRef.current) {
        return;
      }

      onClose();
    } catch (err) {
      if (isRequestCancelledError(err) || abortController.signal.aborted) {
        return;
      }
      if (mountedRef.current) {
        setError((err as Error).message);
      }
    } finally {
      if (mountedRef.current && requestAbortRef.current === abortController) {
        requestAbortRef.current = null;
        setLoading(false);
      }
    }
  };


  const renderStatusIcon = () => {
    if (!task) return null;

    switch (task.status) {
      case 'pending':
        return <ClockCircleOutlined style={{ color: 'var(--color-warning)' }} />;
      case 'running':
        return <Spin />;
      case 'completed':
        return <CheckCircleOutlined style={{ color: 'var(--color-success)' }} />;
      case 'failed':
        return <CloseCircleOutlined style={{ color: 'var(--color-error)' }} />;
      default:
        return null;
    }
  };

  const renderProgress = () => {
    if (!task || task.status === 'completed') return null;

    return (
      <div style={{
        padding: '40px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '300px'
      }}>
        {/* 标题和图标 */}
        <div style={{
          textAlign: 'center',
          marginBottom: 32
        }}>
          {renderStatusIcon()}
          <div style={{
            fontSize: 20,
            fontWeight: 'bold',
            marginTop: 16,
            color: task.status === 'failed' ? 'var(--color-error)' : 'var(--color-text-primary)'
          }}>
            {task.status === 'pending' && '等待分析...'}
            {task.status === 'running' && '正在分析中...'}
            {task.status === 'failed' && '分析失败'}
          </div>
        </div>

        {/* 进度条 */}
        <div style={{
          width: '100%',
          maxWidth: '500px',
          marginBottom: 16
        }}>
          <div style={{
            height: 12,
            background: 'var(--color-bg-layout)',
            borderRadius: 6,
            overflow: 'hidden',
            marginBottom: 12
          }}>
            <div style={{
              height: '100%',
              background: task.status === 'failed'
                ? 'var(--color-error)'
                : task.progress === 100
                  ? 'var(--color-success)'
                  : 'var(--color-primary)',
              width: `${task.progress}%`,
              transition: 'all 0.3s ease',
              borderRadius: 6,
              boxShadow: task.progress > 0 && task.status !== 'failed'
                ? '0 0 10px rgba(24, 144, 255, 0.3)'
                : 'none'
            }} />
          </div>

          {/* 进度百分比 */}
          <div style={{
            textAlign: 'center',
            fontSize: 32,
            fontWeight: 'bold',
            color: task.status === 'failed' ? 'var(--color-error)' :
              task.progress === 100 ? 'var(--color-success)' : 'var(--color-primary)',
            marginBottom: 8
          }}>
            {task.progress}%
          </div>
        </div>

        {/* 状态消息 */}
        <div style={{
          textAlign: 'center',
          fontSize: 16,
          color: 'var(--color-text-secondary)',
          minHeight: 24,
          marginBottom: 16
        }}>
          {task.status === 'pending' && '分析任务已创建，正在队列中...'}
          {task.status === 'running' && '正在提取关键信息和记忆片段...'}
        </div>

        {/* 错误信息 */}
        {task.status === 'failed' && task.error_message && (
          <Alert
            message="分析失败"
            description={<div style={{ wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>{task.error_message}</div>}
            type="error"
            showIcon
            style={{
              marginTop: 16,
              maxWidth: '500px',
              width: '100%'
            }}
          />
        )}

        {/* 提示文字 */}
        {task.status !== 'failed' && (
          <div style={{
            textAlign: 'center',
            fontSize: 13,
            color: 'var(--color-text-tertiary)',
            marginTop: 16
          }}>
            分析过程需要一定时间，请耐心等待
          </div>
        )}
      </div>
    );
  };

  // 将分析建议转换为重新生成组件需要的格式
  const convertSuggestionsForRegeneration = () => {
    if (!analysis?.analysis?.suggestions) return [];

    return analysis.analysis.suggestions.map((suggestion, index) => ({
      category: '改进建议',
      content: suggestion,
      priority: index < 3 ? 'high' : 'medium'
    }));
  };

  const checkerResult = analysis?.checker_result;
  const draftResult = analysis?.auto_revision_draft;
  const checkerIssues = checkerResult?.issues || [];
  const checkerPriorityActions = checkerResult?.priority_actions || [];
  const checkerSeverityCounts = checkerResult?.severity_counts;
  const checkerCriticalCount = checkerSeverityCounts?.critical || 0;
  const checkerMajorCount = checkerSeverityCounts?.major || 0;
  const checkerMinorCount = checkerSeverityCounts?.minor || 0;
  const checkerIssueTotal = checkerIssues.length;
  const draftUnresolvedIssues = draftResult?.unresolved_issues || [];
  const draftCriticalCount = draftResult?.critical_count ?? 0;
  const draftMajorCount = draftResult?.major_count ?? 0;
  const draftPriorityIssueCount = draftResult?.priority_issue_count ?? (draftCriticalCount + draftMajorCount);
  const draftAppliedIssueCount = draftResult?.applied_issue_count ?? draftResult?.applied_critical_count ?? 0;
  const analysisSuggestionCount = formatAnalysisTextList(analysis?.analysis?.suggestions).length;
  const chapterAnalysisGuideSteps = [
    '先确认本章当前是准备发起分析、跟进运行进度，还是进入结果复核阶段，再决定你需要停留的工作区。',
    '再优先看概览里的质量信号、质检问题和自动修订草稿，把真正影响下一步动作的信息先收拢出来。',
    '最后再进入钩子、伏笔、角色和记忆等细分标签页，避免一开始就在细节里来回切换。',
  ];
  const analysisTaskStatusLabel = !task
    ? '未开始'
    : task.status === 'pending'
      ? '排队中'
      : task.status === 'running'
        ? '分析中'
        : task.status === 'completed'
          ? '已完成'
          : task.status === 'failed'
            ? '失败'
            : task.status;
  const chapterAnalysisWorkspaceFocus = error
    ? {
        title: '先处理这一轮分析阻塞',
        note: '当前已经返回错误信息，更适合先确认章节上下文或任务状态，再重新触发新的分析请求。',
      }
    : loading && !task
      ? {
          title: '正在准备章节分析上下文',
          note: '当前正在读取章节信息与分析状态，适合先等待基础数据就绪，再决定是发起新分析还是进入结果复核。',
        }
      : task && (task.status === 'pending' || task.status === 'running' || isAnalysisTaskRetrying(task))
        ? {
            title: '跟进当前章节分析进度',
            note: '当前后台分析已经启动，适合先看进度和状态提示，不要急着重复发起新的分析请求。',
          }
        : task?.status === 'failed'
          ? {
              title: '确认失败原因后再决定是否重试',
              note: '当前任务未完成，更适合先阅读失败提示和自动恢复情况，再判断是否需要重新分析。',
            }
          : draftResult
            ? {
                title: '优先复核自动修订草稿与高优先问题',
                note: '当前已经得到自动修订草稿，适合先确认处理范围和剩余问题，再决定是应用草稿还是转去重生成。',
              }
            : checkerResult
              ? {
                  title: '先用概览页锁定主要质量短板',
                  note: '当前已经加载文本质检结果，更适合先处理优先修复项和质量趋势，再继续查看细分结构标签页。',
                }
              : task?.status === 'completed' && analysis
                ? {
                    title: '从本章分析结果决定下一步动作',
                    note: '当前结果已经完整返回，适合先看概览中的摘要、建议和评分，再决定是否进入重生成或内容复核。',
                  }
                : {
                    title: '确认是否发起本章的首次分析',
                    note: '当前还没有可展示的分析结果，适合先准备好本章上下文，再由现有分析链路生成这一轮诊断信息。',
                  };
  const sectionLabelStyle = {
    display: 'block',
    fontSize: 11,
    letterSpacing: '0.08em',
    textTransform: 'uppercase' as const,
    color: token.colorTextTertiary,
    marginBottom: 6,
  };

  const getSeverityTagColor = (severity?: string) => {
    switch ((severity || '').toLowerCase()) {
      case 'critical':
        return 'red';
      case 'major':
      case 'warning':
        return 'orange';
      case 'minor':
      case 'info':
        return 'blue';
      default:
        return 'default';
    }
  };

  const getSeverityLabel = (severity?: string) => {
    switch ((severity || '').toLowerCase()) {
      case 'critical':
        return '严重';
      case 'major':
        return '重要';
      case 'warning':
        return '警告';
      case 'minor':
        return '一般';
      case 'info':
        return '提示';
      default:
        return severity || '未知';
    }
  };

  const resetDraftPreviewState = () => {
    setDraftPreviewVisible(false);
    setDraftPreviewLoading(false);
    setDraftContent('');
  };

  const openDraftPreview = async () => {
    if (!draftResult?.history_id) {
      message.warning('当前草稿缺少历史记录标识，无法查看全文');
      return;
    }

    draftPreviewRequestIdRef.current += 1;
    const requestId = draftPreviewRequestIdRef.current;
    try {
      setDraftPreviewLoading(true);
      setDraftPreviewVisible(true);
      const response = await chapterApi.getAutoRevisionDraft(chapterId, draftResult.history_id);
      if (!mountedRef.current || draftPreviewRequestIdRef.current !== requestId) {
        return;
      }
      setDraftContent(response.auto_revision_draft.revised_text || response.auto_revision_draft.revised_text_preview || '');
    } catch (err) {
      if (!mountedRef.current || draftPreviewRequestIdRef.current !== requestId) {
        return;
      }
      message.error((err as Error).message || '加载自动修订草稿失败');
      setDraftPreviewVisible(false);
    } finally {
      if (mountedRef.current && draftPreviewRequestIdRef.current === requestId) {
        setDraftPreviewLoading(false);
      }
    }
  };

  const refreshAfterDraftApplied = async () => {
    setAnalysis(null);
    setTask(null);
    await loadChapterInfo();
    await fetchAnalysisStatus();
  };

  const applyDraft = async (allowStale = false) => {
    if (!draftResult?.history_id) {
      message.warning('当前草稿缺少历史记录标识，无法应用');
      return;
    }

    draftApplyRequestIdRef.current += 1;
    const requestId = draftApplyRequestIdRef.current;
    try {
      setApplyingDraft(true);
      await chapterApi.applyAutoRevisionDraft(chapterId, {
        history_id: draftResult.history_id,
        allow_stale: allowStale,
      });
      if (!mountedRef.current || draftApplyRequestIdRef.current !== requestId) {
        return;
      }
      message.success('自动修订草稿已应用到章节正文');
      resetDraftPreviewState();
      await refreshAfterDraftApplied();
    } catch (err) {
      if (!mountedRef.current || draftApplyRequestIdRef.current !== requestId) {
        return;
      }
      const error = err as Error & { response?: { status?: number; data?: { detail?: string } } };
      const status = error.response?.status;
      const detail = error.response?.data?.detail || error.message;

      if (status === 409 && !allowStale) {
        Modal.confirm({
          title: '草稿已过期',
          content: detail || '自动修订草稿已过期，是否仍要强制应用？',
          okText: '仍要应用',
          cancelText: '取消',
          centered: true,
          onOk: async () => {
            await applyDraft(true);
          },
        });
        return;
      }

      message.error(detail || '应用自动修订草稿失败');
    } finally {
      if (mountedRef.current && draftApplyRequestIdRef.current === requestId) {
        setApplyingDraft(false);
      }
    }
  };

  const renderAnalysisResult = () => {
    if (!analysis) return null;

    const { analysis: analysis_data, memories } = analysis;
    if (!analysis_data) {
      return (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="分析任务已完成，但返回结果不完整，请稍后重试或重新分析"
          style={{ padding: isMobile ? '32px 0' : '48px 0' }}
        />
      );
    }
    const suggestions = formatAnalysisTextList(analysis_data.suggestions);
    const hasSuggestions = suggestions.length > 0;
    const hasCheckerResult = !!checkerResult;
    const hasDraftResult = !!draftResult;
    const qualityMetricsSummary = analysis.quality_metrics_summary;
    const effectiveQualityGate = analysis.quality_metrics?.quality_gate ?? qualityMetricsSummary?.quality_gate ?? null;
    const recentFailedMetricCounts = qualityMetricsSummary?.recent_failed_metric_counts || [];
    const recentFocusAreas = qualityMetricsSummary?.recent_focus_areas || [];
    const continuityWarningCount = effectiveQualityGate?.continuity_warning_count
      ?? qualityMetricsSummary?.continuity_preflight?.warning_count
      ?? 0;
    const qualityGateCounts = qualityMetricsSummary?.quality_gate_counts || null;
    const qualitySignalCount = (qualityGateCounts?.pass ?? 0) + (qualityGateCounts?.repairable ?? 0) + (qualityGateCounts?.blocked ?? 0);
    const hasQualitySignals = Boolean(
      effectiveQualityGate?.summary
      || effectiveQualityGate?.recommended_action_label
      || recentFailedMetricCounts.length
      || recentFocusAreas.length
      || continuityWarningCount
      || qualitySignalCount
      || qualityMetricsSummary?.overall_score_trend,
    );

    return (
      <Tabs
        defaultActiveKey="overview"
        size={isMobile ? 'small' : 'middle'}
        tabBarGutter={isMobile ? 8 : 16}
        style={{ height: '100%' }}
        tabBarStyle={{ marginBottom: isMobile ? 8 : 16 }}
        items={[
          {
            key: 'overview',
            label: '概览',
            icon: <TrophyOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(100dvh - 260px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: isMobile ? 0 : '8px' }}>
                {/* 根据建议重新生成按钮 */}
                {hasSuggestions && (
                  <Alert
                    message="发现改进建议"
                    description={
                      <div>
                        <p style={{ marginBottom: 12 }}>已分析出 {suggestions.length} 条改进建议，您可以根据这些建议重新生成章节内容。</p>
                        <Button
                          type="primary"
                          icon={<EditOutlined />}
                          onClick={() => setRegenerationModalVisible(true)}
                          size={isMobile ? 'small' : 'middle'}
                        >
                          根据建议重新生成
                        </Button>
                      </div>
                    }
                    type="info"
                    showIcon
                    style={{ marginBottom: 16 }}
                  />
                )}

                {hasQualitySignals && (
                  <Alert
                    message="质量趋势信号"
                    type={effectiveQualityGate?.requires_manual_review ? 'warning' : 'info'}
                    showIcon
                    style={{ marginBottom: 16 }}
                    description={
                      <div>
                        {effectiveQualityGate?.summary && <p style={{ marginBottom: 8 }}>{effectiveQualityGate.summary}</p>}
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
                          {qualityMetricsSummary?.overall_score_trend && (
                            <Tag color={qualityMetricsSummary.overall_score_trend === 'rising' ? 'green' : qualityMetricsSummary.overall_score_trend === 'falling' ? 'red' : 'blue'}>
                              趋势：{getQualityTrendLabel(qualityMetricsSummary.overall_score_trend)}
                              {typeof qualityMetricsSummary.overall_score_delta === 'number' ? ` ${qualityMetricsSummary.overall_score_delta > 0 ? '+' : ''}${qualityMetricsSummary.overall_score_delta.toFixed(1)}` : ''}
                            </Tag>
                          )}
                          {(qualityGateCounts?.blocked ?? 0) > 0 && <Tag color="red">人工复核 {(qualityGateCounts?.blocked ?? 0)}</Tag>}
                          {(qualityGateCounts?.repairable ?? 0) > 0 && <Tag color="orange">自动修复 {(qualityGateCounts?.repairable ?? 0)}</Tag>}
                          {(qualityGateCounts?.pass ?? 0) > 0 && <Tag color="green">通过 {(qualityGateCounts?.pass ?? 0)}</Tag>}
                          {continuityWarningCount > 0 && <Tag color="gold">连续性预警 {continuityWarningCount}</Tag>}
                        </div>
                        {effectiveQualityGate?.recommended_action_label && (
                          <div style={{ marginBottom: 8 }}>
                            <strong>建议动作：</strong>
                            <Tag color="magenta" style={{ marginLeft: 8 }}>{effectiveQualityGate.recommended_action_label}</Tag>
                          </div>
                        )}
                        {recentFailedMetricCounts.length > 0 && (
                          <div style={{ marginBottom: 8 }}>
                            <strong>最近反复失分：</strong>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                              {recentFailedMetricCounts.map((item) => (
                                <Tag key={`${item.key || item.label}-${item.count || 0}`} color="volcano">
                                  {item.label || item.key}
                                  {typeof item.count === 'number' ? ` ${item.count} 次` : ''}
                                </Tag>
                              ))}
                            </div>
                          </div>
                        )}
                        {recentFocusAreas.length > 0 && (
                          <div style={{ marginBottom: 12 }}>
                            <strong>重点关注：</strong>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                              {recentFocusAreas.map((area) => (
                                <Tag key={area}>{localizeQualityFocusArea(area)}</Tag>
                              ))}
                            </div>
                          </div>
                        )}
                        <Button
                          type="primary"
                          icon={<EditOutlined />}
                          onClick={() => setRegenerationModalVisible(true)}
                          size={isMobile ? 'small' : 'middle'}
                        >
                          按质量信号重生成
                        </Button>
                      </div>
                    }
                  />
                )}

                {hasDraftResult && (
                  <Alert
                    message="发现自动修订草稿"
                    description={
                      <div>
                        <p style={{ marginBottom: 8, wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                          {draftResult.change_summary || '系统已根据高优先问题生成一份自动修订草稿，您可以先预览，再决定是否应用。'}
                        </p>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: draftUnresolvedIssues.length > 0 ? 12 : 0 }}>
                          <Tag color="red">高优先问题 {draftPriorityIssueCount}</Tag>
                          {draftMajorCount > 0 && <Tag color="orange">中等问题 {draftMajorCount}</Tag>}
                          <Tag color="green">已处理 {draftAppliedIssueCount}</Tag>
                          <Tag color="blue">草稿字数 {draftResult.revised_word_count}</Tag>
                          {draftResult.is_stale && <Tag color="orange">草稿已过期</Tag>}
                        </div>
                        {draftUnresolvedIssues.length > 0 && (
                          <div style={{ marginBottom: 12 }}>
                            <div style={{ fontWeight: 500, marginBottom: 4 }}>仍待处理</div>
                            <ul style={{ margin: 0, paddingLeft: 20 }}>
                              {draftUnresolvedIssues.map((issue, index) => (
                                <li key={`${issue}-${index}`} style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{issue}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                          <Button
                            onClick={openDraftPreview}
                            loading={draftPreviewLoading}
                            size={isMobile ? 'small' : 'middle'}
                          >
                            查看修订草稿
                          </Button>
                          <Button
                            type="primary"
                            onClick={() => applyDraft(false)}
                            loading={applyingDraft}
                            size={isMobile ? 'small' : 'middle'}
                          >
                            应用自动修订草稿
                          </Button>
                          {hasSuggestions && (
                            <Button
                              icon={<EditOutlined />}
                              onClick={() => setRegenerationModalVisible(true)}
                              size={isMobile ? 'small' : 'middle'}
                            >
                              根据建议重新生成
                            </Button>
                          )}
                        </div>
                      </div>
                    }
                    type={draftResult.is_stale ? 'warning' : 'success'}
                    showIcon
                    style={{ marginBottom: 16 }}
                  />
                )}

                {hasCheckerResult && (
                  <Card title="文本质检结果" style={{ marginBottom: 16 }} size={isMobile ? 'small' : 'default'}>
                    <div style={{ marginBottom: 16 }}>
                      <div style={{ fontWeight: 500, marginBottom: 8 }}>{checkerResult.overall_assessment || '已完成文本质检'}</div>
                      <Row gutter={isMobile ? 8 : 16}>
                        <Col span={isMobile ? 8 : 6}>
                          <Statistic title="严重" value={checkerCriticalCount} valueStyle={{ color: 'var(--color-error)' }} />
                        </Col>
                        <Col span={isMobile ? 8 : 6}>
                          <Statistic title="重要" value={checkerMajorCount} valueStyle={{ color: 'var(--color-warning)' }} />
                        </Col>
                        <Col span={isMobile ? 8 : 6}>
                          <Statistic title="一般" value={checkerMinorCount} valueStyle={{ color: 'var(--color-primary)' }} />
                        </Col>
                        <Col span={isMobile ? 24 : 6}>
                          <Statistic title="问题总数" value={checkerIssueTotal} />
                        </Col>
                      </Row>
                    </div>

                    {checkerPriorityActions.length > 0 && (
                      <Card type="inner" title="优先修复项" size="small" style={{ marginBottom: 16 }}>
                        <List
                          dataSource={checkerPriorityActions}
                          renderItem={(item, index) => (
                            <List.Item>
                              <span style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{index + 1}. {item}</span>
                            </List.Item>
                          )}
                        />
                      </Card>
                    )}

                    <Card type="inner" title={`问题列表 (${checkerIssueTotal})`} size="small">
                      {checkerIssueTotal > 0 ? (
                        <List
                          dataSource={checkerIssues}
                          renderItem={(issue, index) => {
                            const issueTitle = (issue as { title?: string }).title || issue.category || `问题 ${index + 1}`;
                            const issueLocation = issue.location || (issue as { impact?: string }).impact || '';
                            return (
                              <List.Item>
                                <List.Item.Meta
                                  title={
                                    <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 8 }}>
                                      <Tag color={getSeverityTagColor(issue.severity)}>{getSeverityLabel(issue.severity)}</Tag>
                                      <span style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{issueTitle}</span>
                                      {issueLocation && <Tag style={{ maxWidth: '100%', whiteSpace: 'normal', wordBreak: 'break-word' }}>{issueLocation}</Tag>}
                                    </div>
                                  }
                                  description={
                                    <div style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                                      {issue.evidence && <p style={{ marginBottom: 8 }}><strong>证据：</strong>{issue.evidence}</p>}
                                      {issue.impact && <p style={{ marginBottom: 8 }}><strong>影响：</strong>{issue.impact}</p>}
                                      {issue.suggestion && <p style={{ marginBottom: 0 }}><strong>建议：</strong>{issue.suggestion}</p>}
                                    </div>
                                  }
                                />
                              </List.Item>
                            );
                          }}
                        />
                      ) : (
                        <Empty description="未发现需要修复的问题" />
                      )}
                    </Card>
                  </Card>
                )}

                <Card title="整体评分" style={{ marginBottom: 16 }} size={isMobile ? 'small' : 'default'}>
                  <Row gutter={isMobile ? 8 : 16}>
                    <Col span={isMobile ? 12 : 6}>
                      <Statistic
                        title="整体质量"
                        value={formatAnalysisInteger(analysis_data.overall_quality_score)}
                        suffix="/ 10"
                        valueStyle={{ color: 'var(--color-success)' }}
                      />
                    </Col>
                    <Col span={isMobile ? 12 : 6}>
                      <Statistic
                        title="节奏把控"
                        value={formatAnalysisInteger(analysis_data.pacing_score)}
                        suffix="/ 10"
                      />
                    </Col>
                    <Col span={isMobile ? 12 : 6}>
                      <Statistic
                        title="吸引力"
                        value={formatAnalysisInteger(analysis_data.engagement_score)}
                        suffix="/ 10"
                      />
                    </Col>
                    <Col span={isMobile ? 12 : 6}>
                      <Statistic
                        title="连贯性"
                        value={formatAnalysisInteger(analysis_data.coherence_score)}
                        suffix="/ 10"
                      />
                    </Col>
                  </Row>
                </Card>

                {analysis_data.analysis_report && (
                  <Card title="分析摘要" style={{ marginBottom: 16 }} size={isMobile ? 'small' : 'default'}>
                    <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: isMobile ? 13 : 14, margin: 0, wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                      {analysis_data.analysis_report}
                    </pre>
                  </Card>
                )}

                {hasSuggestions && (
                  <Card title={<><BulbOutlined /> 改进建议</>} size={isMobile ? 'small' : 'default'}>
                    <List
                      dataSource={suggestions}
                      renderItem={(item, index) => (
                        <List.Item>
                          <span style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{index + 1}. {item}</span>
                        </List.Item>
                      )}
                    />
                  </Card>
                )}
              </div>
            )
          },
          {
            key: 'hooks',
            label: `钩子 (${analysis_data.hooks?.length || 0})`,
            icon: <ThunderboltOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(80vh - 180px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: '8px' }}>
                <Card size={isMobile ? 'small' : 'default'}>
                  {Array.isArray(analysis_data.hooks) && analysis_data.hooks.length > 0 ? (
                    <List
                      dataSource={analysis_data.hooks}
                      renderItem={(hook) => (
                        <List.Item>
                          <List.Item.Meta
                            title={
                              <div style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                                <Tag color="blue">{localizeHookType(hook.type)}</Tag>
                                <Tag color="orange">{localizeHookPosition(hook.position)}</Tag>
                                <Tag color="red">强度: {formatAnalysisInteger(hook.strength)}/10</Tag>
                              </div>
                            }
                            description={<div style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{hook.content || ''}</div>}
                          />
                        </List.Item>
                      )}
                    />
                  ) : (
                    <Empty description="暂无钩子" />
                  )}
                </Card>
              </div>
            )
          },
          {
            key: 'foreshadows',
            label: `伏笔 (${analysis_data.foreshadows?.length || 0})`,
            icon: <FireOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(80vh - 180px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: '8px' }}>
                <Card size={isMobile ? 'small' : 'default'}>
                  {Array.isArray(analysis_data.foreshadows) && analysis_data.foreshadows.length > 0 ? (
                    <List
                      dataSource={analysis_data.foreshadows}
                      renderItem={(foreshadow) => (
                        <List.Item>
                          <List.Item.Meta
                            title={
                              <div>
                                <Tag color={foreshadow.type === 'planted' ? 'green' : 'purple'}>
                                  {foreshadow.type === 'planted' ? '已埋下' : '已回收'}
                                </Tag>
                                <Tag>强度: {formatAnalysisInteger(foreshadow.strength)}/10</Tag>
                                <Tag>隐藏度: {formatAnalysisInteger(foreshadow.subtlety)}/10</Tag>
                                {foreshadow.reference_chapter && (
                                  <Tag color="cyan">呼应第{foreshadow.reference_chapter}章</Tag>
                                )}
                              </div>
                            }
                            description={<div style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{foreshadow.content || ''}</div>}
                          />
                        </List.Item>
                      )}
                    />
                  ) : (
                    <Empty description="暂无伏笔" />
                  )}
                </Card>
              </div>
            )
          },
          {
            key: 'emotion',
            label: '情感曲线',
            icon: <HeartOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(80vh - 180px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: '8px' }}>
                <Card size={isMobile ? 'small' : 'default'}>
                  {analysis_data.emotional_tone ? (
                    <div>
                      <Row gutter={isMobile ? 8 : 16} style={{ marginBottom: isMobile ? 16 : 24 }}>
                        <Col span={isMobile ? 24 : 12}>
                          <Statistic
                            title="主导情绪"
                            value={localizeEmotionLabel(analysis_data.emotional_tone)}
                          />
                        </Col>
                        <Col span={isMobile ? 24 : 12}>
                          <Statistic
                            title="情感强度"
                            value={formatAnalysisScore((typeof analysis_data.emotional_intensity === 'number' ? analysis_data.emotional_intensity : 0) * 10)}
                            suffix="/ 10"
                          />
                        </Col>
                      </Row>
                      <Card type="inner" title="剧情阶段" size="small">
                        <p><strong>阶段：</strong>{localizeAnalysisPlotStage(analysis_data.plot_stage)}</p>
                        <p><strong>冲突等级：</strong>{formatAnalysisInteger(analysis_data.conflict_level)} / 10</p>
                        {Array.isArray(analysis_data.conflict_types) && analysis_data.conflict_types.length > 0 && (
                          <div style={{ marginTop: 8 }}>
                            <strong>冲突类型：</strong>
                            {analysis_data.conflict_types.map((type, idx) => (
                              <Tag key={idx} color="red" style={{ margin: 4 }}>
                                {localizeConflictType(type)}
                              </Tag>
                            ))}
                          </div>
                        )}
                      </Card>
                    </div>
                  ) : (
                    <Empty description="暂无情感分析" />
                  )}
                </Card>
              </div>
            )
          },
          {
            key: 'characters',
            label: `角色 (${analysis_data.character_states?.length || 0})`,
            icon: <TeamOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(80vh - 180px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: '8px' }}>
                <Card size={isMobile ? 'small' : 'default'}>
                  {Array.isArray(analysis_data.character_states) && analysis_data.character_states.length > 0 ? (
                    <List
                      dataSource={analysis_data.character_states}
                      renderItem={(char) => (
                        <List.Item>
                          <Card
                            type="inner"
                            title={char.character_name || '未命名角色'}
                            size="small"
                            style={{ width: '100%' }}
                          >
                            <p><strong>状态变化：</strong>{char.state_before || '未知'} → {char.state_after || '未知'}</p>
                            <p><strong>心理变化：</strong>{char.psychological_change || '暂无'}</p>
                            <p><strong>关键事件：</strong>{char.key_event || '暂无'}</p>
                            {char.relationship_changes && typeof char.relationship_changes === 'object' && Object.keys(char.relationship_changes).length > 0 && (
                              <div>
                                <strong>关系变化：</strong>
                                {Object.entries(char.relationship_changes).map(([name, change]) => (
                                  <Tag key={name} color="blue" style={{ margin: 4 }}>
                                    与{name}: {change}
                                  </Tag>
                                ))}
                              </div>
                            )}
                          </Card>
                        </List.Item>
                      )}
                    />
                  ) : (
                    <Empty description="暂无角色分析" />
                  )}
                </Card>
              </div>
            )
          },
          {
            key: 'memories',
            label: `记忆 (${memories?.length || 0})`,
            icon: <FireOutlined />,
            children: (
              <div style={{ height: isMobile ? 'calc(80vh - 180px)' : 'calc(90vh - 220px)', overflowY: 'auto', paddingRight: '8px' }}>
                <Card size={isMobile ? 'small' : 'default'}>
                  {Array.isArray(memories) && memories.length > 0 ? (
                    <List
                      dataSource={memories}
                      renderItem={(memory) => (
                        <List.Item>
                          <List.Item.Meta
                            title={
                              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
                                <Tag color="blue">{localizeAnalysisMemoryType(memory.type)}</Tag>
                                <Tag color="orange">重要性: {formatAnalysisScore(memory.importance)}</Tag>
                                {memory.is_foreshadow === 1 && <Tag color="green">已埋下伏笔</Tag>}
                                {memory.is_foreshadow === 2 && <Tag color="purple">已回收伏笔</Tag>}
                                <span style={{ minWidth: 0, wordBreak: 'break-word', overflowWrap: 'anywhere' }}>{localizeAnalysisMemoryText(memory.title || '')}</span>
                              </div>
                            }
                            description={
                              <div style={{ wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                                <p>{memory.content || ''}</p>
                                <div>
                                  {formatAnalysisTextList(memory.tags).map((tag, idx) => (
                                    <Tag key={idx} style={{ margin: 2 }}>{localizeAnalysisMemoryText(tag)}</Tag>
                                  ))}
                                </div>
                              </div>
                            }
                          />
                        </List.Item>
                      )}
                    />
                  ) : (
                    <Empty description="暂无记忆片段" />
                  )}
                </Card>
              </div>
            )
          }
        ]}
      />
    );
  };

  return (
    <Modal
      title={(
        <div>
          <Text style={sectionLabelStyle}>Chapter Analysis</Text>
          <Text strong style={{ display: 'block', fontSize: 18, marginBottom: 4 }}>
            章节分析
          </Text>
          <Text type="secondary">
            {chapterInfo ? `第${chapterInfo.chapter_number}章：${chapterInfo.title}` : `章节 ID：${chapterId}`}
          </Text>
        </div>
      )}
      open={visible}
      onCancel={onClose}
      width={isMobile ? 'calc(100vw - 32px)' : '90%'}
      centered
      style={{
        maxWidth: isMobile ? 'calc(100vw - 32px)' : '1400px',
        margin: isMobile ? '0 auto' : undefined,
        padding: isMobile ? '0 16px' : undefined
      }}
      styles={{
        body: {
          padding: isMobile ? '12px' : '24px',
          paddingBottom: 0,
          maxHeight: isMobile ? 'calc(100dvh - 200px)' : 'calc(90vh - 150px)',
          overflowY: 'auto',
          overflowX: 'hidden'
        }
      }}
      footer={(
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: isMobile ? 'stretch' : 'flex-end' }}>
          <Button
            key="close"
            onClick={onClose}
            size={isMobile ? 'middle' : 'middle'}
            style={isMobile ? { flex: '1 1 100%', minHeight: 38 } : undefined}
          >
            关闭
          </Button>
          {!task && !loading && (
            <Button
              key="analyze"
              type="primary"
              icon={<ReloadOutlined />}
              onClick={triggerAnalysis}
              loading={loading}
              size={isMobile ? 'middle' : 'middle'}
              style={isMobile ? { flex: '1 1 100%', minHeight: 38 } : undefined}
            >
              开始分析
            </Button>
          )}
          {task && task.status === 'failed' && (
            <Button
              key="reanalyze-failed"
              type="primary"
              icon={<ReloadOutlined />}
              onClick={triggerAnalysis}
              loading={loading}
              danger
              size={isMobile ? 'middle' : 'middle'}
              style={isMobile ? { flex: '1 1 100%', minHeight: 38 } : undefined}
            >
              重新分析
            </Button>
          )}
          {task && task.status === 'completed' && (
            <Button
              key="reanalyze-completed"
              type="default"
              icon={<ReloadOutlined />}
              onClick={triggerAnalysis}
              loading={loading}
              size={isMobile ? 'middle' : 'middle'}
              style={isMobile ? { flex: '1 1 100%', minHeight: 38 } : undefined}
            >
              重新分析
            </Button>
          )}
        </div>
      )}
    >
      <Card
        size="small"
        style={{
          marginBottom: 16,
          borderRadius: 22,
          border: `1px solid ${token.colorBorderSecondary}`,
          background: `linear-gradient(135deg, ${token.colorPrimaryBg} 0%, ${token.colorBgContainer} 100%)`,
        }}
        styles={{ body: { padding: 16 } }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: 16,
          }}
        >
          <div>
            <Text style={sectionLabelStyle}>Analysis Guide</Text>
            <Text strong style={{ display: 'block', fontSize: 17, marginBottom: 8 }}>
              本章分析工作台
            </Text>
            <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
              这里不改变原有分析、轮询、草稿应用或重生成联动逻辑，只把阅读顺序和决策重点提前说明，帮助你先看对的信号，再进入更细的分析标签页。
            </Text>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {chapterAnalysisGuideSteps.map((item, index) => (
                <span
                  key={item}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    padding: '6px 12px',
                    borderRadius: 999,
                    background: token.colorBgContainer,
                    border: `1px solid ${token.colorBorderSecondary}`,
                    color: token.colorText,
                    fontSize: 12,
                  }}
                >
                  <span style={{ color: token.colorPrimary, fontWeight: 700 }}>{index + 1}</span>
                  {item}
                </span>
              ))}
            </div>
          </div>
          <div
            style={{
              borderRadius: 18,
              padding: '16px 18px 14px',
              background: `linear-gradient(180deg, ${token.colorBgContainer} 0%, ${token.colorFillAlter} 100%)`,
              border: `1px solid ${token.colorBorderSecondary}`,
            }}
          >
            <Text style={sectionLabelStyle}>当前工作焦点</Text>
            <Text strong style={{ display: 'block', fontSize: 16, marginBottom: 8 }}>
              {chapterAnalysisWorkspaceFocus.title}
            </Text>
            <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
              {chapterAnalysisWorkspaceFocus.note}
            </Text>
            <Space wrap size={[8, 8]}>
              <Tag color="blue">{chapterInfo ? `第 ${chapterInfo.chapter_number} 章` : '章节信息加载中'}</Tag>
              <Tag color={task?.status === 'failed' ? 'red' : task?.status === 'completed' ? 'green' : task ? 'gold' : 'default'}>
                状态：{analysisTaskStatusLabel}
              </Tag>
              <Tag color={analysisSuggestionCount > 0 ? 'purple' : 'default'}>
                建议 {analysisSuggestionCount} 条
              </Tag>
              <Tag color={checkerIssueTotal > 0 ? 'orange' : 'default'}>
                质检问题 {checkerIssueTotal}
              </Tag>
              <Tag color={draftResult ? 'cyan' : 'default'}>
                {draftResult ? `草稿已生成 · 已处理 ${draftAppliedIssueCount}` : '未生成自动修订草稿'}
              </Tag>
            </Space>
          </div>
        </div>
      </Card>

      {loading && !task && (
        <InlineDeferredPanel
          eyebrow="Analysis Workspace"
          title="正在恢复章节分析工作台"
          message="系统正在准备章节信息、任务状态与分析入口，原有分析查询、轮询恢复与结果接管逻辑保持不变。"
          minHeight={260}
          tags={[
            { label: chapterInfo ? `第 ${chapterInfo.chapter_number} 章` : '章节信息准备中', color: 'blue' },
            { label: '分析状态同步中', color: 'processing' },
            { label: '分析链路保持原样', color: 'green' },
          ]}
        />
      )}

      {error && (
        <Alert
          message="错误"
          description={<div style={{ wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>{error}</div>}
          type="error"
          showIcon
        />
      )}

      {!loading && !error && !task && !analysis && (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="暂无分析结果，可点击下方“开始分析”生成章节分析"
          style={{ padding: isMobile ? '32px 0' : '48px 0' }}
        />
      )}

      {task && task.status !== 'completed' && renderProgress()}
      {task && task.status === 'completed' && analysis && renderAnalysisResult()}
      {task && task.status === 'completed' && !analysis && !loading && (
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE}
          description="分析已完成，但暂无可展示结果，请稍后重试或重新分析"
          style={{ padding: isMobile ? '32px 0' : '48px 0' }}
        />
      )}

      {/* 自动修订草稿预览 */}
      <Modal
        title="自动修订草稿预览"
        open={draftPreviewVisible}
        onCancel={resetDraftPreviewState}
        width={isMobile ? 'calc(100vw - 32px)' : '80%'}
        centered
        style={{ maxWidth: '1200px' }}
        footer={[
          <Button key="close-draft-preview" onClick={resetDraftPreviewState} disabled={applyingDraft}>
            关闭
          </Button>,
          <Button
            key="apply-draft"
            type="primary"
            loading={applyingDraft}
            onClick={() => applyDraft(false)}
          >
            应用自动修订草稿
          </Button>
        ]}
      >
        {draftPreviewLoading ? (
          <InlineDeferredPanel
            eyebrow="Draft Preview"
            title="正在展开自动修订草稿预览"
            message="系统正在恢复修订摘要、正文预览与应用入口，原有草稿请求、应用提交流程与状态处理保持不变。"
            minHeight={240}
            tags={[
              { label: '修订草稿拉取中', color: 'processing' },
              { label: '应用入口待接管', color: 'gold' },
              { label: '草稿逻辑保持原样', color: 'green' },
            ]}
          />
        ) : (
          <div>
            {draftResult && (
              <Card size="small" style={{ marginBottom: 16 }}>
                <Row gutter={isMobile ? 8 : 16}>
                  <Col span={isMobile ? 24 : 8}>
                    <Statistic title="高优先问题" value={draftPriorityIssueCount} valueStyle={{ color: 'var(--color-error)' }} />
                  </Col>
                  <Col span={isMobile ? 24 : 8}>
                    <Statistic title="已处理" value={draftAppliedIssueCount} valueStyle={{ color: 'var(--color-success)' }} />
                  </Col>
                  <Col span={isMobile ? 24 : 8}>
                    <Statistic title="草稿字数" value={draftResult.revised_word_count} />
                  </Col>
                </Row>
                {draftResult.change_summary && (
                  <div style={{ marginTop: 16, wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                    <strong>修订摘要：</strong>{draftResult.change_summary}
                  </div>
                )}
              </Card>
            )}
            <Card size="small" title="修订正文">
              <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit', fontSize: isMobile ? 13 : 14, margin: 0, wordBreak: 'break-word', overflowWrap: 'anywhere' }}>
                {draftContent || draftResult?.revised_text_preview || '暂无可预览内容'}
              </pre>
            </Card>
          </div>
        )}
      </Modal>

      {/* 重新生成Modal */}
      {chapterInfo && (
        <Suspense
          fallback={(
            <WorkflowEntryFallback
              eyebrow="Regeneration Workspace"
              title="正在接管章节重生成面板"
              message="系统正在恢复重生成建议、质量门槛与替换入口，原有重新生成链路和成功回调保持不变。"
              tags={[
                { label: '章节重生成', color: 'magenta' },
                { label: '建议面板恢复中', color: 'processing' },
                { label: '替换逻辑保持原样', color: 'green' },
              ]}
            />
          )}
        >
          <LazyChapterRegenerationModal
          visible={regenerationModalVisible}
          onCancel={() => setRegenerationModalVisible(false)}
          onSuccess={(newContent: string, wordCount: number) => {
            // 保存新生成的内容
            setNewGeneratedContent(newContent);
            setNewContentWordCount(wordCount);
            // 关闭重新生成对话框
            setRegenerationModalVisible(false);
            // 打开对比界面
            setComparisonModalVisible(true);
          }}
          chapterId={chapterId}
          chapterTitle={chapterInfo.title}
          chapterNumber={chapterInfo.chapter_number}
          suggestions={convertSuggestionsForRegeneration()}
          hasAnalysis={Boolean(analysis)}
          repairGuidance={analysis?.quality_metrics?.repair_guidance ?? analysis?.quality_metrics_summary?.repair_guidance ?? null}
          qualityMetricsSummary={analysis?.quality_metrics_summary ?? null}
          qualityGate={analysis?.quality_metrics?.quality_gate ?? analysis?.quality_metrics_summary?.quality_gate ?? null}
          />
        </Suspense>
      )}

      {/* 内容对比组件 */}
      {chapterInfo && comparisonModalVisible && (
        <Suspense
          fallback={(
            <WorkflowEntryFallback
              eyebrow="Comparison Review"
              title="正在展开正文对比审阅面板"
              message="系统正在恢复原稿、新稿与应用确认区，原有对比、应用和放弃逻辑保持不变。"
              tags={[
                { label: '正文对比', color: 'geekblue' },
                { label: '审阅面板恢复中', color: 'processing' },
                { label: '确认逻辑保持原样', color: 'green' },
              ]}
            />
          )}
        >
          <LazyChapterContentComparison
          visible={comparisonModalVisible}
          onClose={() => setComparisonModalVisible(false)}
          chapterId={chapterId}
          projectId={chapterInfo.project_id}
          chapterTitle={chapterInfo.title}
          originalContent={chapterInfo.content}
          newContent={newGeneratedContent}
          wordCount={newContentWordCount}
          onApply={async () => {
            // 应用新内容后刷新章节信息和分析
            setChapterInfo(null);
            setAnalysis(null);

            // 重新加载章节内容
            await loadChapterInfo();

            // 刷新分析状态
            await fetchAnalysisStatus();
          }}
          onDiscard={() => {
            // 放弃新内容，清空状态
            setNewGeneratedContent('');
            setNewContentWordCount(0);
          }}
          />
        </Suspense>
      )}
    </Modal>
  );
}
