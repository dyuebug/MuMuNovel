import { useCallback, useMemo } from 'react';
import { Button, Card, Collapse, Form, Input, Radio, Select, Space, Switch, Tag, Typography, theme } from 'antd';
import type { FormInstance } from 'antd';

import type { CreativeMode, PlotStage, QualityPreset, StoryFocus } from '../types';
import {
  CREATION_PRESETS,
  getCreationPresetById,
  getCreationPresetByModes,
  type CreationPresetId,
} from '../utils/creationPresetsCore';
import {
  buildCreationBlueprint,
  buildStoryExecutionChecklist,
  buildStoryObjectiveCard,
  buildStoryRepetitionRiskCard,
  buildStoryResultCard,
  buildStoryAcceptanceCard,
  buildStoryCharacterArcCard,
  buildVolumePacingPlan,
} from '../utils/creationPresetsStory';
import {
  CREATIVE_MODE_OPTIONS,
  QUALITY_PRESET_OPTIONS,
  STORY_FOCUS_OPTIONS,
} from '../utils/generationPreferenceOptions';

const { TextArea } = Input;
const { Text } = Typography;

type OutlineGenerateFormValues = {
  mode?: 'auto' | 'new' | 'continue';
  chapter_count?: number;
  narrative_perspective?: string;
  theme?: string;
  story_direction?: string;
  target_words?: number;
  plot_stage?: PlotStage;
  creative_mode?: CreativeMode;
  story_focus?: StoryFocus;
  story_creation_brief?: string;
  quality_preset?: QualityPreset;
  quality_notes?: string;
  requirements?: string;
  model?: string;
  keep_existing?: boolean;
  enable_web_research?: boolean;
  web_research_query?: string;
};

type OutlineProjectSnapshot = {
  narrative_perspective?: string | null;
  theme?: string | null;
} | null | undefined;

type ModelOption = {
  value: string;
  label: string;
};

type OutlineGenerateModalContentProps = {
  generateForm: FormInstance<OutlineGenerateFormValues>;
  currentProject: OutlineProjectSnapshot;
  outlinesCount: number;
  loadedModels: ModelOption[];
  defaultModel?: string;
  projectDefaultCreativeMode?: CreativeMode;
  projectDefaultStoryFocus?: StoryFocus;
  projectDefaultPlotStage?: PlotStage;
  projectDefaultStoryCreationBrief?: string;
  projectDefaultQualityPreset?: QualityPreset;
  projectDefaultQualityNotes?: string;
};

export default function OutlineGenerateModalContent({
  generateForm,
  currentProject,
  outlinesCount,
  loadedModels,
  defaultModel,
  projectDefaultCreativeMode,
  projectDefaultStoryFocus,
  projectDefaultPlotStage,
  projectDefaultStoryCreationBrief,
  projectDefaultQualityPreset,
  projectDefaultQualityNotes,
}: OutlineGenerateModalContentProps) {
  const { token } = theme.useToken();
  const alphaColor = (color: string, alpha: number) => `color-mix(in srgb, ${color} ${(alpha * 100).toFixed(0)}%, transparent)`;
  const hasOutlines = outlinesCount > 0;
  const initialMode = hasOutlines ? 'continue' : 'new';

  const selectedOutlineChapterCount = Form.useWatch('chapter_count', generateForm) as number | undefined;
  const selectedOutlineCreativeMode = Form.useWatch('creative_mode', generateForm) as CreativeMode | undefined;
  const selectedOutlineStoryFocus = Form.useWatch('story_focus', generateForm) as StoryFocus | undefined;
  const selectedOutlinePlotStage = Form.useWatch('plot_stage', generateForm) as PlotStage | undefined;
  const selectedOutlineQualityPreset = Form.useWatch('quality_preset', generateForm) as QualityPreset | undefined;
  const outlineEnableWebResearch = Form.useWatch('enable_web_research', generateForm) as boolean | undefined;

  const activeOutlineCreationPreset = useMemo(
    () => getCreationPresetByModes(selectedOutlineCreativeMode, selectedOutlineStoryFocus),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus],
  );

  const outlineCreationBlueprint = useMemo(
    () => buildCreationBlueprint(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryObjectiveCard = useMemo(
    () => buildStoryObjectiveCard(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryResultCard = useMemo(
    () => buildStoryResultCard(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryExecutionChecklist = useMemo(
    () => buildStoryExecutionChecklist(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryRepetitionRiskCard = useMemo(
    () => buildStoryRepetitionRiskCard(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryAcceptanceCard = useMemo(
    () => buildStoryAcceptanceCard(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineStoryCharacterArcCard = useMemo(
    () => buildStoryCharacterArcCard(selectedOutlineCreativeMode, selectedOutlineStoryFocus, {
      scene: 'outline',
      plotStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineCreativeMode, selectedOutlineStoryFocus, selectedOutlinePlotStage],
  );

  const outlineVolumePacingPlan = useMemo(
    () => buildVolumePacingPlan(selectedOutlineChapterCount, {
      preferredStage: selectedOutlinePlotStage,
    }),
    [selectedOutlineChapterCount, selectedOutlinePlotStage],
  );

  const outlineSelectedCreativeModeLabel = selectedOutlineCreativeMode
    ? (CREATIVE_MODE_OPTIONS.find((item) => item.value === selectedOutlineCreativeMode)?.label || selectedOutlineCreativeMode)
    : '默认';
  const outlineSelectedStoryFocusLabel = selectedOutlineStoryFocus
    ? (STORY_FOCUS_OPTIONS.find((item) => item.value === selectedOutlineStoryFocus)?.label || selectedOutlineStoryFocus)
    : '默认';
  const outlineSelectedQualityPresetLabel = selectedOutlineQualityPreset
    ? (QUALITY_PRESET_OPTIONS.find((item) => item.value === selectedOutlineQualityPreset)?.label || selectedOutlineQualityPreset)
    : '默认';

  const applyOutlineCreationPreset = useCallback((presetId: CreationPresetId) => {
    const preset = getCreationPresetById(presetId);
    if (!preset) return;
    generateForm.setFieldsValue({
      creative_mode: preset.creativeMode,
      story_focus: preset.storyFocus,
    });
  }, [generateForm]);
  const outlineGenerateGuideSteps = [
    '先决定这轮是续写现有大纲还是全新生成，再确认章节规模，避免后面反复重开生成模式。',
    '再校准创作模式、聚焦方向、剧情阶段和质量预设，把大纲的创作目标在提交前一次说清楚。',
    '最后才按需展开高级策略或联网检索，让额外上下文服务于已经明确的生成主线。',
  ];
  const outlineGenerateWorkspaceFocus = outlineEnableWebResearch
    ? {
        title: '确认这轮大纲是否真的需要外部资料支撑',
        note: '当前已经开启联网检索，更适合用于职业、时代、规则或世界观细节明确的大纲生成，不必给普通续写增加额外噪音。',
      }
    : !hasOutlines
      ? {
          title: '先定义第一版大纲的生成方向',
          note: '当前项目还没有可续写的大纲，更适合先稳定章节规模和创作偏好，再产出第一版结构骨架。',
        }
      : activeOutlineCreationPreset
        ? {
            title: `围绕「${activeOutlineCreationPreset.label}」预设推进本轮大纲`,
            note: '当前已经形成比较明确的创作倾向，适合先确认预设与章节数是否匹配，再提交这轮大纲生成。',
          }
        : {
            title: '收束这轮大纲生成的控制条件',
            note: '当前更适合先确认生成模式、创作偏好和质量预设，再进入更细的策略卡片，避免信息顺序打乱。',
          };

  return (
    <>
        <div
          style={{
            marginTop: 8,
            marginBottom: 18,
            padding: '16px 18px',
            borderRadius: 20,
            background: `linear-gradient(135deg, ${alphaColor(token.colorPrimaryBg, 0.9)} 0%, ${alphaColor(token.colorBgElevated, 0.98)} 100%)`,
            border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
          }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
              gap: 16,
            }}
          >
            <div>
              <Text style={{ display: 'block', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: token.colorTextTertiary, marginBottom: 6 }}>
                Outline Drafting Guide
              </Text>
              <Text strong style={{ display: 'block', fontSize: 17, marginBottom: 8 }}>
                大纲生成控制台
              </Text>
              <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
                这里不改变原有生成请求或配置结构，只把设置顺序和判断重点前置，让本轮大纲生成更贴近当前项目目标。
              </Text>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {outlineGenerateGuideSteps.map((item, index) => (
                  <span
                    key={item}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '6px 12px',
                      borderRadius: 999,
                      background: token.colorBgContainer,
                      border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
                      color: token.colorText,
                      fontSize: 12,
                    }}
                  >
                    <span style={{ color: token.colorPrimary, fontWeight: 700 }}>{index + 1}</span>
                    {item}
                  </span>
                ))}
              </div>
            </div>
            <div
              style={{
                borderRadius: 18,
                padding: '16px 18px 14px',
                background: `linear-gradient(180deg, ${alphaColor(token.colorBgContainer, 0.98)} 0%, ${alphaColor(token.colorFillQuaternary, 0.5)} 100%)`,
                border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
              }}
            >
              <Text style={{ display: 'block', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: token.colorTextTertiary, marginBottom: 6 }}>
                当前工作焦点
              </Text>
              <Text strong style={{ display: 'block', fontSize: 16, marginBottom: 8 }}>
                {outlineGenerateWorkspaceFocus.title}
              </Text>
              <Text type="secondary" style={{ display: 'block', lineHeight: 1.7, marginBottom: 12 }}>
                {outlineGenerateWorkspaceFocus.note}
              </Text>
              <Space wrap size={[8, 8]}>
                <Tag color="blue">{hasOutlines ? '已有大纲可续写' : '将生成首版大纲'}</Tag>
                <Tag color="purple">章节数 {selectedOutlineChapterCount || 0}</Tag>
                <Tag color="cyan">创作模式 {outlineSelectedCreativeModeLabel}</Tag>
                <Tag color="green">聚焦 {outlineSelectedStoryFocusLabel}</Tag>
                <Tag color="gold">质量预设 {outlineSelectedQualityPresetLabel}</Tag>
              </Space>
            </div>
          </div>
        </div>
        <Form


          form={generateForm}


          layout="vertical"


          style={{ marginTop: 16 }}


          initialValues={{


            mode: initialMode,


            chapter_count: 5,


            narrative_perspective: currentProject?.narrative_perspective || "第三人称",


            creative_mode: projectDefaultCreativeMode,


            story_focus: projectDefaultStoryFocus,


            plot_stage: projectDefaultPlotStage || 'development',


            story_creation_brief: projectDefaultStoryCreationBrief,


            quality_preset: projectDefaultQualityPreset,


            quality_notes: projectDefaultQualityNotes,


            keep_existing: true,


            theme: currentProject?.theme || '',


            model: defaultModel,


            enable_web_research: false,


          }}


        >


          {hasOutlines && (


            <Form.Item


              label="生成模式"


              name="mode"


              tooltip="自动判断：根据是否有大纲自动选择；全新生成：删除旧大纲重新生成；续写模式：基于已有大纲继续创作"


            >


              <Radio.Group buttonStyle="solid">


                <Radio.Button value="auto">自动判断</Radio.Button>


                <Radio.Button value="new">全新生成</Radio.Button>


                <Radio.Button value="continue">续写模式</Radio.Button>


              </Radio.Group>


            </Form.Item>


          )}


          <Form.Item


            noStyle


            shouldUpdate={(prevValues, currentValues) => prevValues.mode !== currentValues.mode}


          >


            {({ getFieldValue }) => {


              const mode = getFieldValue('mode');


              const isContinue = mode === 'continue' || (mode === 'auto' && hasOutlines);


              // 续写模式不显示主题输入，使用项目原有主题


              if (isContinue) {


                return null;


              }


              // 全新生成模式需要输入主题


              return (


                <Form.Item


                  label="故事主题"


                  name="theme"


                  rules={[{ required: true, message: '请输入故事主题' }]}


                >


                  <TextArea rows={3} placeholder="描述你的故事主题、核心设定和主要情节..." />


                </Form.Item>


              );


            }}


          </Form.Item>


          <Form.Item


            noStyle


            shouldUpdate={(prevValues, currentValues) => prevValues.mode !== currentValues.mode}


          >


            {({ getFieldValue }) => {


              const mode = getFieldValue('mode');


              const isContinue = mode === 'continue' || (mode === 'auto' && hasOutlines);


              return (


                <>


                  {isContinue && (


                    <>


                      <Form.Item


                        label="故事发展方向"


                        name="story_direction"


                        tooltip="告诉系统你希望故事接下来如何发展"


                      >


                        <TextArea


                          rows={3}


                          placeholder="例如：主角遇到新的挑战、引入新角色、揭示关键秘密等..."


                        />


                      </Form.Item>


                      <Form.Item


                        label="情节阶段"


                        name="plot_stage"


                        tooltip="帮助系统理解当前故事所处的阶段"


                      >


                        <Select>


                          <Select.Option value="development">发展阶段 - 继续展开情节</Select.Option>


                          <Select.Option value="climax">高潮阶段 - 矛盾激化</Select.Option>


                          <Select.Option value="ending">结局阶段 - 收束伏笔</Select.Option>


                        </Select>


                      </Form.Item>


                    </>


                  )}


                  <Form.Item


                    label={isContinue ? "续写章节数" : "章节数量"}


                    name="chapter_count"


                    rules={[{ required: true, message: '请输入章节数量' }]}


                  >


                    <Input


                      type="number"


                      min={1}


                      max={50}


                      placeholder={isContinue ? "建议5-10章" : "如：30"}


                    />


                  </Form.Item>


                  <Form.Item


                    label="叙事视角"


                    name="narrative_perspective"


                    rules={[{ required: true, message: '请选择叙事视角' }]}


                  >


                    <Select>


                      <Select.Option value="第一人称">第一人称</Select.Option>


                      <Select.Option value="第三人称">第三人称</Select.Option>


                      <Select.Option value="全知视角">全知视角</Select.Option>


                    </Select>


                  </Form.Item>

                  <Card
                    size="small"
                    title="常用生成控制"
                    style={{
                      marginBottom: 8,
                      borderRadius: 18,
                      border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
                      background: `linear-gradient(135deg, ${alphaColor(token.colorPrimaryBg, 0.72)} 0%, ${alphaColor(token.colorBgContainer, 0.98)} 100%)`,
                    }}
                    styles={{ body: { padding: 12 } }}
                  >
                    <div
                      style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                        gap: 12,
                      }}
                    >
                      <Form.Item
                        label="质量预设"
                        name="quality_preset"
                        tooltip="为这轮大纲施加统一的质量偏好，控制更偏推进、氛围、情绪或干净表达"
                        style={{ marginBottom: 0 }}
                      >
                        <Select allowClear placeholder="默认沿用项目偏好" optionLabelProp="label">
                          {QUALITY_PRESET_OPTIONS.map((option) => (
                            <Select.Option key={option.value} value={option.value} label={option.label}>
                              <div>{option.label}</div>
                              <div style={{ fontSize: 12, color: 'var(--color-text-secondary)' }}>{option.description}</div>
                              <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>适合：{option.bestFor}</div>
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>

                      {loadedModels.length > 0 && (
                        <Form.Item
                          label="AI 模型"
                          name="model"
                          tooltip="选择用于生成的 AI 模型，不选则使用系统默认模型"
                          style={{ marginBottom: 0 }}
                        >
                          <Select
                            placeholder={defaultModel ? `默认：${loadedModels.find(m => m.value === defaultModel)?.label || defaultModel}` : '使用系统默认模型'}
                            allowClear
                            showSearch
                            optionFilterProp="label"
                            options={loadedModels}
                            onChange={(value) => {
                              console.log('用户在下拉框中选择了模型:', value);
                              generateForm.setFieldsValue({ model: value });
                              console.log('已同步到 Form，当前 Form 值:', generateForm.getFieldsValue());
                            }}
                          />
                          <div style={{ color: 'var(--color-text-tertiary)', fontSize: 12, marginTop: 4 }}>
                            {defaultModel ? `当前默认模型：${loadedModels.find(m => m.value === defaultModel)?.label || defaultModel}` : '当前未配置默认模型'}
                          </div>
                        </Form.Item>
                      )}
                    </div>
                  </Card>

                  <Collapse
                    size="small"
                    style={{
                      marginBottom: 12,
                      borderRadius: 18,
                      overflow: 'hidden',
                      border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                    }}
                    items={[
                      {
                        key: 'outline-advanced',
                        label: (
                          <div>
                            <div>{'更多策略与参考卡片（按需展开）'}</div>
                            <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)', marginTop: 4 }}>
                              {`预设：${activeOutlineCreationPreset?.label || '未选择'} · 模式：${outlineSelectedCreativeModeLabel} · 聚焦：${outlineSelectedStoryFocusLabel} · 质量：${outlineSelectedQualityPresetLabel}`}
                            </div>
                          </div>
                        ),
                        children: (
                          <div style={{ maxHeight: 'min(72vh, 720px)', overflowY: 'auto', paddingRight: 4 }}>

                  <Card
                    size="small"
                    title="创作预设"
                    style={{
                      marginBottom: 12,
                      borderRadius: 18,
                      border: `1px solid ${alphaColor(token.colorPrimary, 0.12)}`,
                      background: alphaColor(token.colorBgElevated, 0.98),
                    }}
                  >
                    <Space wrap>
                      {CREATION_PRESETS.map((preset) => (
                        <Button
                          key={preset.id}
                          type={activeOutlineCreationPreset?.id === preset.id ? 'primary' : 'default'}
                          onClick={() => applyOutlineCreationPreset(preset.id)}
                        >
                          {preset.label}
                        </Button>
                      ))}
                      <Button
                        onClick={() => generateForm.setFieldsValue({
                          creative_mode: projectDefaultCreativeMode,
                          story_focus: projectDefaultStoryFocus,
                          plot_stage: projectDefaultPlotStage || 'development',
                          story_creation_brief: projectDefaultStoryCreationBrief,
                          quality_preset: projectDefaultQualityPreset,
                          quality_notes: projectDefaultQualityNotes,
                        })}
                      >
                        恢复项目默认
                      </Button>
                    </Space>

                    {activeOutlineCreationPreset && (
                      <div style={{ marginTop: 12, color: 'var(--color-text-secondary)' }}>
                        当前预设：<strong>{activeOutlineCreationPreset.label}</strong>，{activeOutlineCreationPreset.description}
                      </div>
                    )}
                  </Card>

                  {outlineCreationBlueprint && (
                    <Card
                      size="small"
                      title="结构蓝图预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineCreationBlueprint.summary}
                      </div>
                      <div style={{ fontWeight: 600, marginBottom: 8 }}>本轮大纲节拍</div>
                      <Space direction="vertical" size={6} style={{ display: 'flex' }}>
                        {outlineCreationBlueprint.beats.map((beat, index) => (
                          <div key={beat}>{index + 1}. {beat}</div>
                        ))}
                      </Space>
                      {outlineCreationBlueprint.risks.length > 0 && (
                        <div style={{ marginTop: 12, color: 'var(--color-warning)' }}>
                          结构提醒：{outlineCreationBlueprint.risks.join('；')}
                        </div>
                      )}
                    </Card>
                  )}

                  {outlineStoryObjectiveCard && (
                    <Card
                      size="small"
                      title="目标卡预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryObjectiveCard.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['目标', outlineStoryObjectiveCard.objective],
                          ['阻力', outlineStoryObjectiveCard.obstacle],
                          ['转折', outlineStoryObjectiveCard.turn],
                          ['钩子', outlineStoryObjectiveCard.hook],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineStoryResultCard && (
                    <Card
                      size="small"
                      title="结果卡预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryResultCard.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['推进', outlineStoryResultCard.progress],
                          ['揭示', outlineStoryResultCard.reveal],
                          ['关系', outlineStoryResultCard.relationship],
                          ['余波', outlineStoryResultCard.fallout],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineStoryExecutionChecklist && (
                    <Card
                      size="small"
                      title="执行清单预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryExecutionChecklist.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['开场', outlineStoryExecutionChecklist.opening],
                          ['加压', outlineStoryExecutionChecklist.pressure],
                          ['转折', outlineStoryExecutionChecklist.pivot],
                          ['收束', outlineStoryExecutionChecklist.closing],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineStoryRepetitionRiskCard && (
                    <Card
                      size="small"
                      title="重复风险预警"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryRepetitionRiskCard.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['开场风险', outlineStoryRepetitionRiskCard.openingRisk],
                          ['加压风险', outlineStoryRepetitionRiskCard.pressureRisk],
                          ['转折风险', outlineStoryRepetitionRiskCard.pivotRisk],
                          ['收尾风险', outlineStoryRepetitionRiskCard.closingRisk],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineStoryAcceptanceCard && (
                    <Card
                      size="small"
                      title="验收卡预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryAcceptanceCard.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['任务命中', outlineStoryAcceptanceCard.missionCheck],
                          ['变化落地', outlineStoryAcceptanceCard.changeCheck],
                          ['新鲜度', outlineStoryAcceptanceCard.freshnessCheck],
                          ['收束质量', outlineStoryAcceptanceCard.closingCheck],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineStoryCharacterArcCard && (
                    <Card
                      size="small"
                      title="角色弧光预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineStoryCharacterArcCard.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {[
                          ['外在线', outlineStoryCharacterArcCard.externalLine],
                          ['内在线', outlineStoryCharacterArcCard.internalLine],
                          ['关系线', outlineStoryCharacterArcCard.relationshipLine],
                          ['落点', outlineStoryCharacterArcCard.arcLanding],
                        ].map(([label, value]) => (
                          <div
                            key={label}
                            style={{
                              padding: '10px 12px',
                              border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                              borderRadius: 12,
                              background: alphaColor(token.colorFillQuaternary, 0.56),
                            }}
                          >
                            <div style={{ fontWeight: 600, marginBottom: 4 }}>{label}</div>
                            <div style={{ color: 'var(--color-text-secondary)' }}>{value}</div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  {outlineVolumePacingPlan && (
                    <Card
                      size="small"
                      title="卷级节奏预览"
                      style={{
                        marginBottom: 12,
                        borderRadius: 18,
                        border: `1px solid ${alphaColor(token.colorBorderSecondary, 0.88)}`,
                      }}
                    >
                      <div style={{ color: 'var(--color-text-secondary)', marginBottom: 10 }}>
                        {outlineVolumePacingPlan.summary}
                      </div>
                      <Space direction="vertical" size={8} style={{ display: 'flex' }}>
                        {outlineVolumePacingPlan.segments.map((segment) => (
                          <div key={`${segment.stage}-${segment.startChapter}`}>
                            <strong>第{segment.startChapter}-{segment.endChapter}章 · {segment.label}</strong>
                            <div style={{ color: 'var(--color-text-secondary)', marginTop: 2 }}>
                              {segment.mission}
                            </div>
                          </div>
                        ))}
                      </Space>
                    </Card>
                  )}

                  <Form.Item


                    label="创作模式"


                    name="creative_mode"


                    tooltip="可选：让本轮大纲更偏向钩子、情绪、悬念、关系或爽点回收"


                  >


                    <Select allowClear placeholder="默认均衡，不额外强调单一方向" optionLabelProp="label">


                      {CREATIVE_MODE_OPTIONS.map((option) => (


                        <Select.Option key={option.value} value={option.value} label={option.label}>


                          <div>{option.label}</div>


                          <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>{option.description}</div>


                        </Select.Option>


                      ))}


                    </Select>


                  </Form.Item>


                  <Form.Item


                    label="结构侧重点"


                    name="story_focus"


                    tooltip="可选：指定本轮大纲更偏向主线推进、人物塑形、冲突升级等叙事任务"


                  >


                    <Select allowClear placeholder="默认均衡承担多种功能" optionLabelProp="label">


                      {STORY_FOCUS_OPTIONS.map((option) => (


                        <Select.Option key={option.value} value={option.value} label={option.label}>


                          <div>{option.label}</div>


                          <div style={{ fontSize: 12, color: 'var(--color-text-tertiary)' }}>{option.description}</div>


                        </Select.Option>


                      ))}


                    </Select>


                  </Form.Item>


                  <Form.Item
                    label="创作总控摘要"
                    name="story_creation_brief"
                    tooltip="用几句话告诉系统这轮大纲最该守住的创作目标、节奏与约束"
                  >
                    <TextArea
                      rows={3}
                      placeholder="例如：开篇先立目标和代价，再用钩子推动角色被迫做出选择。"
                      showCount
                      maxLength={600}
                    />
                  </Form.Item>

                  <Form.Item
                    label="额外质量要求"
                    name="quality_notes"
                    tooltip="补充这轮大纲要特别强化或压制的表达习惯"
                  >
                    <TextArea
                      rows={3}
                      placeholder="例如：减少解释性旁白，优先让冲突、选择和章尾牵引落在剧情动作里。"
                      showCount
                      maxLength={600}
                    />
                  </Form.Item>

                  <Form.Item
                    label="联网检索"
                    name="enable_web_research"
                    valuePropName="checked"
                    tooltip="生成前补充实时外部参考，可用于加强设定、职业与时代细节。"
                    style={{ marginBottom: outlineEnableWebResearch ? 12 : 0 }}
                  >
                    <div>
                      <Switch checkedChildren="开启" unCheckedChildren="关闭" />
                      <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginTop: 6 }}>
                        开启后会先补充外部资料，再注入大纲生成提示词，帮助提升设定可信度与时代细节。
                      </div>
                    </div>
                  </Form.Item>

                  {outlineEnableWebResearch && (
                    <Form.Item
                      label="联网检索查询词"
                      name="web_research_query"
                      tooltip="可留空，系统会根据题材与要求自动生成查询词。"
                    >
                      <TextArea
                        rows={2}
                        placeholder="例如：民国巡捕房办案细节、古代夜市风俗、悬疑开篇节奏案例"
                        showCount
                        maxLength={300}
                      />
                    </Form.Item>
                  )}

                  <Form.Item label="其他要求" name="requirements">


                    <TextArea rows={2} placeholder="其他特殊要求（可选）" />


                  </Form.Item>
                          </div>
                        ),
                      },
                    ]}
                  />


                </>


              );


            }}


          </Form.Item>


          {/* 自定义模型选择 - 移到外层，所有模式都显示 */}


        </Form>
    </>
  );
}
