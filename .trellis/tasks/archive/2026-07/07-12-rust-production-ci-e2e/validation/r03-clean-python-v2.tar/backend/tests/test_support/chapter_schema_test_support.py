"""Retired chapter schema source-map kept only for tests and rollback seams."""
from pydantic import BaseModel, ConfigDict, Field, field_validator
from typing import Any, Dict, List, Optional

from tests.test_support.schemas.generation_preferences import (
    CreativeModeValue,
    PlotStageValue,
    QualityPresetValue,
    StoryFocusValue,
    normalize_optional_choice,
    normalize_optional_text,
)
from tests.test_support.schemas.quality import (
    ActiveStoryRepairPayload,
    ChapterLatestQualityMetrics,
    ChapterQualityMetricsSummary,
)
from datetime import datetime


class ChapterBase(BaseModel):
    """章节基础模型"""

    title: str = Field(..., description="章节标题")
    chapter_number: int = Field(..., description="章节序号")
    content: Optional[str] = Field(None, description="章节内容")
    summary: Optional[str] = Field(None, description="章节摘要")
    word_count: Optional[int] = Field(0, description="字数")
    status: Optional[str] = Field("draft", description="章节状态")
    outline_id: Optional[str] = Field(None, description="关联的大纲ID")
    sub_index: Optional[int] = Field(1, description="大纲下的子章节序号")
    expansion_plan: Optional[str] = Field(None, description="展开规划详情(JSON)")


class ChapterCreate(BaseModel):
    """创建章节的请求模型"""

    project_id: str = Field(..., description="所属项目ID")
    title: str = Field(..., description="章节标题")
    chapter_number: int = Field(..., description="章节序号")
    content: Optional[str] = Field(None, description="章节内容")
    summary: Optional[str] = Field(None, description="章节摘要")
    status: Optional[str] = Field("draft", description="章节状态")
    outline_id: Optional[str] = Field(None, description="关联的大纲ID")
    sub_index: Optional[int] = Field(1, description="大纲下的子章节序号")
    expansion_plan: Optional[str] = Field(None, description="展开规划详情(JSON)")


class ChapterUpdate(BaseModel):
    """更新章节的请求模型"""

    title: Optional[str] = None
    content: Optional[str] = None
    summary: Optional[str] = None
    status: Optional[str] = None


class ChapterResponse(BaseModel):
    """章节响应模型"""

    id: str
    project_id: str
    title: str
    chapter_number: int
    content: Optional[str] = None
    summary: Optional[str] = None
    word_count: int = 0
    status: str
    outline_id: Optional[str] = None
    sub_index: Optional[int] = 1
    expansion_plan: Optional[str] = None
    outline_title: Optional[str] = None
    outline_order: Optional[int] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ChapterListResponse(BaseModel):
    """章节列表响应模型"""

    total: int
    items: list[ChapterResponse]


class ProjectChapterQualityTrendItem(BaseModel):
    """项目章节质量趋势条目"""

    chapter_id: str
    chapter_number: int
    title: str
    status: Optional[str] = None
    history_id: Optional[str] = None
    generated_at: Optional[str] = None
    latest_quality_metrics: Optional[ChapterLatestQualityMetrics] = None


class ProjectChapterQualityTrendResponse(BaseModel):
    """项目章节质量趋势响应"""

    project_id: str
    has_metrics: bool
    total_chapters: int
    analyzed_chapters: int
    items: List[ProjectChapterQualityTrendItem]
    quality_metrics_summary: Optional[ChapterQualityMetricsSummary] = None


class AnalysisTaskStatusResponse(BaseModel):
    """单章节分析任务状态响应"""

    has_task: bool
    task_id: Optional[str] = None
    chapter_id: str
    status: str
    progress: int = 0
    error_message: Optional[str] = None
    error_code: Optional[str] = None
    auto_recovered: bool = False
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


class BatchAnalysisStatusRequest(BaseModel):
    """批量查询分析状态请求"""

    chapter_ids: Optional[List[str]] = Field(
        None,
        description="待查询章节ID列表；为空时查询项目下全部章节",
    )


class BatchAnalysisStatusResponse(BaseModel):
    """批量查询分析状态响应"""

    project_id: str
    total: int
    items: Dict[str, AnalysisTaskStatusResponse]


class BatchAnalyzeUnanalyzedRequest(BaseModel):
    """一键分析未分析章节请求"""

    chapter_ids: Optional[List[str]] = Field(
        None,
        description="可选：限定待分析章节ID列表；为空则自动识别项目内全部未分析章节",
    )


class BatchAnalyzeUnanalyzedResponse(BaseModel):
    """一键分析未分析章节响应"""

    project_id: str
    total_candidates: int = Field(0, description="候选章节总数（有内容章节）")
    total_started: int = Field(0, description="本次已启动分析任务数")
    total_skipped_no_content: int = Field(0, description="跳过：无内容章节数")
    total_skipped_running: int = Field(0, description="跳过：已在分析中的章节数")
    total_already_completed: int = Field(0, description="跳过：已完成分析章节数")
    started_tasks: Dict[str, AnalysisTaskStatusResponse] = Field(
        default_factory=dict,
        description="本次启动的分析任务状态映射",
    )


class ChapterGenerateRequest(BaseModel):
    """AI章节生成请求模型"""

    model_config = ConfigDict(extra="forbid")

    style_id: Optional[int] = Field(None, description="写作风格ID；为空时使用项目默认配置")
    target_word_count: Optional[int] = Field(
        3000,
        description="目标字数，默认3000字",
        ge=500,
        le=10000,
    )
    enable_analysis: bool = Field(True, description="是否在生成后自动执行章节分析")
    enable_mcp: bool = Field(True, description="是否启用MCP工具增强")
    enable_web_research: Optional[bool] = Field(
        None,
        description="是否启用联网检索增强（通过 Exa/Grok 补充参考）",
    )
    web_research_query: Optional[str] = Field(None, description="联网检索查询词；为空时自动生成 query")
    model: Optional[str] = Field(None, description="指定本次生成使用的AI模型")
    narrative_perspective: Optional[str] = Field(
        None,
        description="叙事视角，可选 first_person/third_person/omniscient",
    )
    creative_mode: Optional[CreativeModeValue] = Field(
        None,
        description="创作模式：balanced/hook/emotion/suspense/relationship/payoff",
    )
    story_focus: Optional[StoryFocusValue] = Field(
        None,
        description="结构侧重点：advance_plot/deepen_character/escalate_conflict/reveal_mystery/relationship_shift/foreshadow_payoff",
    )
    plot_stage: Optional[PlotStageValue] = Field(
        None,
        description="剧情阶段：development/climax/ending",
    )
    story_creation_brief: Optional[str] = Field(
        None,
        description="本轮创作总控摘要",
        max_length=1200,
    )
    quality_preset: Optional[QualityPresetValue] = Field(
        None,
        description="质量预设：balanced/plot_drive/immersive/emotion_drama/clean_prose",
    )
    quality_notes: Optional[str] = Field(None, description="质量补充偏好", max_length=600)
    story_repair_summary: Optional[str] = Field(None, description="剧情质量修复摘要")
    story_repair_targets: Optional[list[str]] = Field(None, description="剧情质量修复目标")
    story_preserve_strengths: Optional[list[str]] = Field(None, description="需要保留的既有优势")

    @field_validator(
        "creative_mode",
        "story_focus",
        "plot_stage",
        "quality_preset",
        mode="before",
    )
    @classmethod
    def normalize_generation_choices(cls, value):
        return normalize_optional_choice(value)

    @field_validator(
        "story_creation_brief",
        "quality_notes",
        "story_repair_summary",
        mode="before",
    )
    @classmethod
    def normalize_generation_texts(cls, value):
        return normalize_optional_text(value)


class BatchGenerateRequest(BaseModel):
    """批量章节生成请求模型"""

    model_config = ConfigDict(extra="forbid")

    start_chapter_number: int = Field(..., description="起始章节号")
    count: int = Field(..., description="生成章节数", ge=1, le=20)
    style_id: Optional[int] = Field(None, description="写作风格ID")
    target_word_count: Optional[int] = Field(
        3000,
        description="目标字数，默认3000字",
        ge=500,
        le=10000,
    )
    enable_analysis: bool = Field(False, description="是否在生成后自动执行章节分析")
    enable_mcp: bool = Field(True, description="是否启用MCP工具增强")
    enable_web_research: Optional[bool] = Field(
        None,
        description="是否启用联网检索增强（通过 Exa/Grok 补充参考）",
    )
    web_research_query: Optional[str] = Field(None, description="联网检索查询词；为空时自动生成 query")
    max_retries: int = Field(3, description="失败时的最大重试次数", ge=0, le=5)
    model: Optional[str] = Field(None, description="指定本次生成使用的AI模型")
    creative_mode: Optional[CreativeModeValue] = Field(
        None,
        description="创作模式：balanced/hook/emotion/suspense/relationship/payoff",
    )
    story_focus: Optional[StoryFocusValue] = Field(
        None,
        description="结构侧重点：advance_plot/deepen_character/escalate_conflict/reveal_mystery/relationship_shift/foreshadow_payoff",
    )
    plot_stage: Optional[PlotStageValue] = Field(
        None,
        description="剧情阶段：development/climax/ending",
    )
    story_creation_brief: Optional[str] = Field(
        None,
        description="本轮创作总控摘要",
        max_length=1200,
    )
    quality_preset: Optional[QualityPresetValue] = Field(
        None,
        description="质量预设：balanced/plot_drive/immersive/emotion_drama/clean_prose",
    )
    quality_notes: Optional[str] = Field(None, description="质量补充偏好", max_length=600)
    story_repair_summary: Optional[str] = Field(None, description="剧情质量修复摘要")
    story_repair_targets: Optional[list[str]] = Field(None, description="剧情质量修复目标")
    story_preserve_strengths: Optional[list[str]] = Field(None, description="需要保留的既有优势")

    @field_validator(
        "creative_mode",
        "story_focus",
        "plot_stage",
        "quality_preset",
        mode="before",
    )
    @classmethod
    def normalize_generation_choices(cls, value):
        return normalize_optional_choice(value)

    @field_validator(
        "story_creation_brief",
        "quality_notes",
        "story_repair_summary",
        mode="before",
    )
    @classmethod
    def normalize_generation_texts(cls, value):
        return normalize_optional_text(value)


class BatchGenerateResponse(BaseModel):
    """批量生成响应模型"""

    batch_id: str = Field(..., description="批次ID")
    message: str = Field(..., description="响应消息")
    chapters_to_generate: list[dict] = Field(..., description="待生成章节列表")
    estimated_time_minutes: int = Field(..., description="预估耗时（分钟）")


class BatchGenerateStatusResponse(BaseModel):
    """Batch generation status response."""

    batch_id: str
    status: str
    total: int
    completed: int
    current_chapter_id: Optional[str] = None
    current_chapter_number: Optional[int] = None
    current_retry_count: Optional[int] = None
    max_retries: Optional[int] = None
    failed_chapters: list[dict] = Field(default_factory=list)
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    error_message: Optional[str] = None
    stage_code: Optional[str] = None
    execution_mode: Optional[str] = None
    checkpoint: Optional[Dict[str, Any]] = None
    latest_quality_metrics: Optional[ChapterLatestQualityMetrics] = None
    quality_metrics_summary: Optional[ChapterQualityMetricsSummary] = None
    quality_profile_summary: Optional[Dict[str, Any]] = None
    active_story_repair_payload: Optional[ActiveStoryRepairPayload] = None
    terminal_reason: Optional[str] = None
    terminal_label: Optional[str] = None
    review_required: bool = False
    can_resume: bool = False


class RegenerationTaskResponse(BaseModel):
    """重新生成任务响应"""

    task_id: str
    chapter_id: str
    status: str
    message: str
    estimated_time_seconds: int = 120


class RegenerationTaskStatus(BaseModel):
    """重新生成任务状态"""

    task_id: str
    chapter_id: str
    status: str
    progress: int
    error_message: Optional[str] = None
    created_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    original_word_count: Optional[int] = None
    regenerated_word_count: Optional[int] = None
    version_number: Optional[int] = None


class SceneData(BaseModel):
    """场景数据模型"""

    location: str = Field(..., description="场景地点")
    characters: List[str] = Field(..., description="参与角色列表")
    purpose: str = Field(..., description="场景目的")


class ExpansionPlanUpdate(BaseModel):
    """章节规划更新模型"""

    summary: Optional[str] = Field(None, description="章节情节概要")
    key_events: Optional[List[str]] = Field(None, description="关键事件列表")
    character_focus: Optional[List[str]] = Field(None, description="涉及角色列表")
    emotional_tone: Optional[str] = Field(None, description="情感基调")
    narrative_goal: Optional[str] = Field(None, description="叙事目标")
    conflict_type: Optional[str] = Field(None, description="冲突类型")
    estimated_words: Optional[int] = Field(None, description="预估字数", ge=500, le=10000)
    scenes: Optional[List[SceneData]] = Field(None, description="场景列表")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "key_events": ["主角遇到挑战", "关键决策时刻"],
                "character_focus": ["张三", "李四"],
                "emotional_tone": "紧张激烈",
                "narrative_goal": "推进主线剧情",
                "conflict_type": "内心冲突",
                "estimated_words": 3000,
                "scenes": [
                    {
                        "location": "城市广场",
                        "characters": ["张三", "李四"],
                        "purpose": "初次相遇",
                    }
                ],
            }
        }
    )


class ExpansionPlanResponse(BaseModel):
    """章节规划响应模型"""

    id: str = Field(..., description="章节ID")
    expansion_plan: Optional[Dict[str, Any]] = Field(None, description="规划数据")
    message: str = Field(..., description="响应消息")


class PartialRegenerateResponse(BaseModel):
    """局部重写响应模型"""

    success: bool = Field(..., description="是否成功")
    new_text: str = Field(..., description="重写后的新内容")
    word_count: int = Field(..., description="新内容字数")
    original_word_count: int = Field(..., description="原文字数")
    message: str = Field("重写成功", description="响应消息")

