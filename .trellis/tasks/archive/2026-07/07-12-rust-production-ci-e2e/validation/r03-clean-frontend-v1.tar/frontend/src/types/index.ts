// 用户类型定义
export interface User {
  user_id: string;
  username: string;
  display_name: string;
  avatar_url?: string;
  trust_level: number;
  is_admin: boolean;
  linuxdo_id: string;
  created_at: string;
  last_login: string;
}

// 设置类型定义
export interface Settings {
  id: string;
  user_id: string;
  api_provider: string;
  api_key: string;
  has_api_key?: boolean;
  api_base_url: string;
  api_backup_urls?: string[];
  provider_type?: string;
  fallback_strategy?: 'auto' | 'manual';
  azure_api_version?: string;
  llm_model: string;
  temperature: number;
  max_tokens: number;
  system_prompt?: string;
  web_research_enabled?: boolean;
  web_research_exa_enabled?: boolean;
  web_research_grok_enabled?: boolean;
  web_research_exa_api_key?: string;
  web_research_exa_base_url?: string;
  web_research_grok_api_key?: string;
  web_research_grok_base_url?: string;
  web_research_grok_model?: string;
  web_research_grok_search_enabled?: boolean;
  preferences?: string;
  created_at: string;
  updated_at: string;
}

export interface SettingsUpdate {
  api_provider?: string;
  api_key?: string;
  clear_api_key?: boolean;
  api_base_url?: string;
  api_backup_urls?: string[];
  provider_type?: string;
  fallback_strategy?: 'auto' | 'manual';
  azure_api_version?: string;
  llm_model?: string;
  temperature?: number;
  max_tokens?: number;
  system_prompt?: string;
  web_research_enabled?: boolean;
  web_research_exa_enabled?: boolean;
  web_research_grok_enabled?: boolean;
  web_research_exa_api_key?: string;
  web_research_exa_base_url?: string;
  web_research_grok_api_key?: string;
  web_research_grok_base_url?: string;
  web_research_grok_model?: string;
  web_research_grok_search_enabled?: boolean;
  preferences?: string;
}

// API预设相关类型定义
export interface APIKeyPresetConfig {
  api_provider: string;
  api_key: string;
  api_base_url?: string;
  api_backup_urls?: string[];
  provider_type?: string;
  fallback_strategy?: 'auto' | 'manual';
  azure_api_version?: string;
  llm_model: string;
  temperature: number;
  max_tokens: number;
  system_prompt?: string;
}

export interface APIKeyPreset {
  id: string;
  name: string;
  description?: string;
  is_active: boolean;
  created_at: string;
  config: APIKeyPresetConfig;
}

export interface PresetCreateRequest {
  name: string;
  description?: string;
  config: APIKeyPresetConfig;
}

export interface PresetUpdateRequest {
  name?: string;
  description?: string;
  config?: APIKeyPresetConfig;
}

export interface PresetListResponse {
  presets: APIKeyPreset[];
  total: number;
  active_preset_id?: string;
}

// LinuxDO 授权 URL 响应
export interface AuthUrlResponse {
  auth_url: string;
  state: string;
}

// 项目类型定义
export interface Project {
  id: string;  // UUID字符串
  title: string;
  description?: string;
  theme?: string;
  genre?: string;
  target_words?: number;
  current_words: number;
  status: 'planning' | 'writing' | 'revising' | 'completed';
  wizard_status?: 'incomplete' | 'completed';
  wizard_step?: number;
  outline_mode: 'one-to-one' | 'one-to-many';  // 大纲章节模式
  world_time_period?: string;
  world_location?: string;
  world_atmosphere?: string;
  world_rules?: string;
  chapter_count?: number;
  narrative_perspective?: string;
  character_count?: number;
  default_creative_mode?: CreativeMode;
  default_story_focus?: StoryFocus;
  default_plot_stage?: PlotStage;
  default_story_creation_brief?: string;
  default_quality_preset?: QualityPreset;
  default_quality_notes?: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectCreate {
  title: string;
  description?: string;
  theme?: string;
  genre?: string;
  target_words?: number;
  outline_mode?: 'one-to-one' | 'one-to-many';  // 大纲章节模式,默认one-to-many
  wizard_status?: 'incomplete' | 'completed';
  wizard_step?: number;
  world_time_period?: string;
  world_location?: string;
  world_atmosphere?: string;
  world_rules?: string;
  default_creative_mode?: CreativeMode;
  default_story_focus?: StoryFocus;
  default_plot_stage?: PlotStage;
  default_story_creation_brief?: string;
  default_quality_preset?: QualityPreset;
  default_quality_notes?: string;
}

export interface ProjectUpdate {
  title?: string;
  description?: string;
  theme?: string;
  genre?: string;
  target_words?: number;
  status?: 'planning' | 'writing' | 'revising' | 'completed';
  world_time_period?: string;
  world_location?: string;
  world_atmosphere?: string;
  world_rules?: string;
  default_creative_mode?: CreativeMode;
  default_story_focus?: StoryFocus;
  default_plot_stage?: PlotStage;
  default_story_creation_brief?: string;
  default_quality_preset?: QualityPreset;
  default_quality_notes?: string;
  chapter_count?: number;
  narrative_perspective?: string;
  character_count?: number;
  // current_words 由章节内容自动计算，不在此接口中
}

// 向导专用的项目更新接口，包含向导流程控制字段
export interface ProjectWizardUpdate extends ProjectUpdate {
  wizard_status?: 'incomplete' | 'completed';
  wizard_step?: number;
}

// 项目创建向导
export interface ProjectWizardRequest {
  title: string;
  theme: string;
  genre?: string;
  chapter_count: number;
  narrative_perspective: string;
  character_count?: number;
  target_words?: number;
  outline_mode?: 'one-to-one' | 'one-to-many';  // 大纲章节模式
  default_creative_mode?: CreativeMode;
  default_story_focus?: StoryFocus;
  default_plot_stage?: PlotStage;
  default_story_creation_brief?: string;
  default_quality_preset?: QualityPreset;
  default_quality_notes?: string;
  world_building?: {
    time_period: string;
    location: string;
    atmosphere: string;
    rules: string;
  };
  enable_web_research?: boolean;
  web_research_query?: string;
  world_building_research_query?: string;
  careers_research_query?: string;
  characters_research_query?: string;
  outline_research_query?: string;
}

export interface WorldBuildingResponse {
  project_id: string;
  time_period: string;
  location: string;
  atmosphere: string;
  rules: string;
  research_query?: string;
  research_assets?: ResearchAssetSummary[];
}

export interface ResearchAssetSummary {
  title: string;
  source?: string;
  summary?: string;
  usage_hint?: string;
  asset_type?: string;
}

// 大纲类型定义
export interface Outline {
  id: string;
  project_id: string;
  title: string;
  content: string;
  structure?: string;
  order_index: number;
  has_chapters?: boolean;
  created_at: string;
  updated_at: string;
}

export interface OutlineCreate {
  project_id: string;
  title: string;
  content: string;
  structure?: string;
  order_index: number;
}

export interface OutlineUpdate {
  title?: string;
  content?: string;
  structure?: string;  // 支持修改structure字段
  // order_index 只能通过 reorder 接口批量调整
}

// 角色类型定义
export interface Character {
  id: string;
  project_id: string;
  name: string;
  age?: string;
  gender?: string;
  is_organization: boolean;
  role_type?: string;
  personality?: string;
  background?: string;
  appearance?: string;
  relationships?: string;
  organization_type?: string;
  organization_purpose?: string;
  organization_members?: string;
  traits?: string;
  avatar_url?: string;
  // 组织扩展字段（从Organization表关联）
  power_level?: number;
  location?: string;
  motto?: string;
  color?: string;
  // 角色/组织状态
  status?: string;
  status_changed_chapter?: number;
  current_state?: string;
  state_updated_chapter?: number;
  // 职业相关字段
  main_career_id?: string;
  main_career_stage?: number;
  sub_careers?: Array<{
    career_id: string;
    stage: number;
  }>;
  created_at: string;
  updated_at: string;
}

export interface CharacterUpdate {
  name?: string;
  age?: string;
  gender?: string;
  is_organization?: boolean;
  role_type?: string;
  personality?: string;
  background?: string;
  appearance?: string;
  organization_type?: string;
  organization_purpose?: string;
  organization_members?: string;
  traits?: string;
  // 组织扩展字段
  power_level?: number;
  location?: string;
  motto?: string;
  color?: string;
}

// 展开规划数据结构
export interface ExpansionPlanData {
  key_events: string[];
  character_focus: string[];
  emotional_tone: string;
  narrative_goal: string;
  conflict_type: string;
  estimated_words: number;
  scenes?: Array<{
    location: string;
    characters: string[];
    purpose: string;
  }> | null;
}

// 章节类型定义
export interface Chapter {
  id: string;
  project_id: string;
  title: string;
  content?: string;
  summary?: string;
  chapter_number: number;
  word_count: number;
  status: 'draft' | 'writing' | 'completed';
  expansion_plan?: string; // JSON字符串，解析后为ExpansionPlanData
  outline_id?: string; // 关联的大纲ID
  sub_index?: number; // 大纲下的子章节序号
  outline_title?: string; // 大纲标题（从后端联表查询获得）
  outline_order?: number; // 大纲排序序号（从后端联表查询获得）
  created_at: string;
  updated_at: string;
}

export interface ChapterCreate {
  project_id: string;
  title: string;
  chapter_number: number;
  content?: string;
  summary?: string;
  status?: 'draft' | 'writing' | 'completed';
}

export interface ChapterUpdate {
  title?: string;
  content?: string;
  // chapter_number 不允许修改，由大纲顺序决定
  summary?: string;
  // word_count 自动计算，不允许手动修改
  status?: 'draft' | 'writing' | 'completed';
}

// 章节生成请求类型
export type CreativeMode = 'balanced' | 'hook' | 'emotion' | 'suspense' | 'relationship' | 'payoff';
export type StoryFocus = 'advance_plot' | 'deepen_character' | 'escalate_conflict' | 'reveal_mystery' | 'relationship_shift' | 'foreshadow_payoff';
export type PlotStage = 'development' | 'climax' | 'ending';
export type QualityPreset = 'balanced' | 'plot_drive' | 'immersive' | 'emotion_drama' | 'clean_prose';

export interface ChapterGenerateRequest {
  style_id?: number;
  target_word_count?: number;
  enable_analysis?: boolean;
  enable_mcp?: boolean;
  model?: string;
  narrative_perspective?: string;
  creative_mode?: CreativeMode;
  story_focus?: StoryFocus;
  plot_stage?: PlotStage;
  story_creation_brief?: string;
  quality_preset?: QualityPreset;
  quality_notes?: string;
  story_repair_summary?: string;
  story_repair_targets?: string[];
  story_preserve_strengths?: string[];
}

// 章节生成检查响应
export interface ChapterCanGenerateResponse {
  can_generate: boolean;
  reason: string;
  previous_chapters: {
    id: string;
    chapter_number: number;
    title: string;
    has_content: boolean;
    word_count: number;
  }[];
  chapter_number: number;
}

export interface StoryRepairGuidance {
  summary?: string;
  repair_targets?: string[];
  preserve_strengths?: string[];
  focus_areas?: string[];
  weakest_metric_key?: string | null;
  weakest_metric_label?: string | null;
  weakest_metric_value?: number | null;
  quality_stage?: string | null;
  quality_stage_label?: string | null;
  continuity_preflight?: StoryContinuityPreflight | null;
  quality_runtime_pressure?: StoryQualityRuntimePressure | null;
}

export interface StoryQualityGateMetric {
  key?: string | null;
  label?: string | null;
  value?: number | null;
  threshold?: number | null;
  gap?: number | null;
  focus_area?: string | null;
  repair_target?: string | null;
}

export interface StoryQualityMetricFrequency {
  key?: string | null;
  label?: string | null;
  focus_area?: string | null;
  count?: number;
}

export interface StoryContinuityPreflightWarning {
  ledger_label?: string | null;
  focus_area?: string | null;
  item?: string | null;
}

export interface StoryContinuityPreflight {
  status?: string;
  summary?: string;
  warning_count?: number;
  checked_item_count?: number;
  missing_item_count?: number;
  focus_areas?: string[];
  repair_targets?: string[];
  warnings?: StoryContinuityPreflightWarning[];
}

export interface StoryQualityGateDecision {
  status?: "pass" | "repairable" | "blocked" | "unknown" | string;
  decision?: "allow_save" | "auto_repair" | "manual_review" | "unknown" | string;
  label?: string;
  summary?: string;
  reason?: string;
  overall_score?: number | null;
  weak_metric_count?: number;
  failed_metrics?: StoryQualityGateMetric[];
  focus_areas?: string[];
  repair_targets?: string[];
  allow_save?: boolean;
  can_auto_repair?: boolean;
  requires_manual_review?: boolean;
  weakest_metric_key?: string | null;
  weakest_metric_label?: string | null;
  weakest_metric_value?: number | null;
  recommended_action?: string | null;
  recommended_action_label?: string | null;
  recommended_action_mode?: string | null;
  recommended_focus_area?: string | null;
  continuity_warning_count?: number;
  continuity_preflight?: StoryContinuityPreflight | null;
  pacing_imbalance?: StoryPacingImbalanceSummary | null;
  manual_review_threshold?: number | null;
  allow_save_threshold?: number | null;
  weak_metric_block_count?: number | null;
  allow_save_weak_metric_count?: number | null;
  normalized_gap_threshold?: number | null;
  quality_stage?: string | null;
  quality_stage_label?: string | null;
  quality_runtime_pressure?: StoryQualityRuntimePressure | null;
}

export interface ActiveStoryRepairPayload extends StoryRepairGuidance {
  source?: 'manual_request' | 'current_chapter_quality' | 'recent_history_summary' | 'manual_plus_current_chapter_quality' | 'manual_plus_recent_history_summary' | string;
  source_label?: string | null;
  scope?: 'chapter' | 'batch' | string | null;
  quality_gate?: StoryQualityGateDecision | null;
  quality_gate_status?: StoryQualityGateDecision['status'] | null;
  quality_gate_decision?: StoryQualityGateDecision['decision'] | null;
  quality_gate_label?: string | null;
  quality_gate_summary?: string | null;
  quality_gate_failed_metrics?: string[];
  updated_at?: string | null;
}

export interface ChapterQualityMetrics {
  overall_score: number;
  conflict_chain_hit_rate: number;
  rule_grounding_hit_rate: number;
  outline_alignment_rate: number;
  dialogue_naturalness_rate: number;
  opening_hook_rate: number;
  payoff_chain_rate: number;
  cliffhanger_rate: number;
  repair_guidance?: StoryRepairGuidance | null;
  quality_gate?: StoryQualityGateDecision | null;
}

export interface QualityRuntimeLedgerEntry {
  name?: string | null;
  state?: string | null;
  status?: string | null;
  pair?: string | null;
  label?: string | null;
  detail?: string | null;
  [key: string]: unknown;
}

export interface QualityRuntimePlanEntry {
  name?: string | null;
  status?: string | null;
  summary?: string | null;
  label?: string | null;
  target_chapter?: number | null;
  [key: string]: unknown;
}

export type QualityRuntimeLedgerItem = string | QualityRuntimeLedgerEntry;
export type QualityRuntimePlanItem = string | QualityRuntimePlanEntry;

export interface StoryQualityRuntimePressure {
  foreshadow_state_count?: number;
  character_state_count?: number;
  relationship_state_count?: number;
  organization_state_count?: number;
  career_state_count?: number;
  foreshadow_state_items?: string[];
  character_state_items?: string[];
  relationship_state_items?: string[];
  organization_state_items?: string[];
  career_state_items?: string[];
}

export interface QualityRuntimeContextSummary {
  plot_stage?: string;
  chapter_count?: number | null;
  current_chapter_number?: number | null;
  target_word_count?: number | null;
  genre?: string;
  genre_profiles?: string[];
  style_name?: string;
  style_preset_id?: string;
  style_profile?: string;
  quality_preset?: string;
  quality_notes?: string;
  creative_mode?: string;
  story_focus?: string;
  story_creation_brief?: string;
  story_long_term_goal?: string;
  chapter_number_span?: number[];
  character_focus?: string[];
  foreshadow_payoff_plan?: QualityRuntimePlanItem[];
  character_state_ledger?: QualityRuntimeLedgerItem[];
  relationship_state_ledger?: QualityRuntimeLedgerItem[];
  foreshadow_state_ledger?: QualityRuntimeLedgerItem[];
  organization_state_ledger?: QualityRuntimeLedgerItem[];
  career_state_ledger?: QualityRuntimeLedgerItem[];
}

export interface ChapterLatestQualityMetrics {
  overall_score?: number;
  conflict_chain_hit_rate?: number;
  rule_grounding_hit_rate?: number;
  outline_alignment_rate?: number;
  dialogue_naturalness_rate?: number;
  opening_hook_rate?: number;
  payoff_chain_rate?: number;
  cliffhanger_rate?: number;
  pacing_score?: number;
  chapter_id?: string;
  history_id?: string | null;
  generated_at?: string | null;
  repair_guidance?: StoryRepairGuidance | null;
  quality_gate?: StoryQualityGateDecision | null;
  quality_runtime_context?: QualityRuntimeContextSummary | null;
}

export interface StoryPacingImbalanceSignal {
  key?: string;
  label?: string;
  severity?: "watch" | "warning" | string;
  summary?: string;
  metric?: number | null;
}

export interface StoryPacingImbalanceSummary {
  status?: "stable" | "watch" | "warning" | string;
  window_size?: number;
  signal_count?: number;
  recent_progression_density?: number | null;
  recent_payoff_momentum?: number | null;
  recent_payoff_rate?: number | null;
  recent_cliffhanger_pull?: number | null;
  recent_tension_variation?: number | null;
  signals?: StoryPacingImbalanceSignal[];
  focus_areas?: string[];
  repair_targets?: string[];
  summary?: string;
}

export interface StoryVolumeGoalCompletionSummary {
  status?: "stable" | "watch" | "warning" | string;
  completion_rate?: number | null;
  expected_stage?: string;
  expected_stage_label?: string;
  current_stage?: string;
  current_stage_label?: string;
  stage_alignment?: number | null;
  focus_areas?: string[];
  repair_targets?: string[];
  profile_summary?: string;
  profile_focuses?: string[];
  style_profile?: string;
  genre_profiles?: string[];
  quality_preset?: string;
  summary?: string;
}

export interface StoryForeshadowPayoffDelaySummary {
  status?: "stable" | "watch" | "warning" | string;
  delay_index?: number | null;
  plan_count?: number;
  backlog_count?: number;
  recent_payoff_rate?: number | null;
  recent_payoff_momentum?: number | null;
  focus_areas?: string[];
  repair_targets?: string[];
  summary?: string;
}

export interface StoryRepairEffectivenessFocusAreaStat {
  focus_area?: string;
  label?: string;
  metric_key?: string;
  evaluated_pairs?: number;
  successful_pairs?: number;
  success_rate?: number | null;
  avg_delta?: number | null;
}

export interface StoryRepairEffectivenessSummary {
  status?: "stable" | "watch" | "warning" | string;
  success_rate?: number | null;
  evaluated_pairs?: number;
  successful_pairs?: number;
  recovered_focus_areas?: string[];
  unresolved_focus_areas?: string[];
  focus_area_stats?: StoryRepairEffectivenessFocusAreaStat[];
  summary?: string;
}

export interface ChapterQualityMetricsSummary {
  avg_overall_score?: number;
  avg_conflict_chain_hit_rate?: number;
  avg_rule_grounding_hit_rate?: number;
  avg_outline_alignment_rate?: number;
  avg_dialogue_naturalness_rate?: number;
  avg_opening_hook_rate?: number;
  avg_payoff_chain_rate?: number;
  avg_cliffhanger_rate?: number;
  avg_pacing_score?: number | null;
  chapter_count?: number;
  total_chapters?: number;
  analyzed_chapters?: number;
  last_generated_at?: string | null;
  overall_score_delta?: number;
  overall_score_trend?: 'rising' | 'falling' | 'stable' | string;
  recent_focus_areas?: string[];
  recent_failed_metric_counts?: StoryQualityMetricFrequency[];
  quality_gate_counts?: Record<string, number>;
  recent_manual_review_count?: number;
  recent_auto_repair_count?: number;
  continuity_preflight?: StoryContinuityPreflight | null;
  pacing_imbalance?: StoryPacingImbalanceSummary | null;
  volume_goal_completion?: StoryVolumeGoalCompletionSummary | null;
  foreshadow_payoff_delay?: StoryForeshadowPayoffDelaySummary | null;
  repair_effectiveness?: StoryRepairEffectivenessSummary | null;
  repair_guidance?: StoryRepairGuidance | null;
  quality_gate?: StoryQualityGateDecision | null;
  quality_runtime_context?: QualityRuntimeContextSummary | null;
}

export interface ChapterQualityProfileBlockSummary {
  title?: string;
  summary?: string;
  lines?: string[];
  prompt_blocks?: string[];
}

export interface ChapterQualityProfileSummary {
  version?: string;
  baseline_id?: string;
  genre_profiles?: string[];
  style_profile?: string;
  quality_dimensions?: string[];
  prompt_blocks?: string[];
  generation?: ChapterQualityProfileBlockSummary | null;
  checker?: ChapterQualityProfileBlockSummary | null;
  reviser?: ChapterQualityProfileBlockSummary | null;
  mcp_guard?: ChapterQualityProfileBlockSummary | null;
  external_assets_block?: ChapterQualityProfileBlockSummary | null;
  policy?: Record<string, unknown> | null;
  blocks?: Record<string, ChapterQualityProfileBlockSummary> | null;
}

export interface ProjectChapterQualityTrendItem {
  chapter_id: string;
  chapter_number: number;
  title: string;
  status?: string | null;
  history_id?: string | null;
  generated_at?: string | null;
  latest_quality_metrics?: ChapterLatestQualityMetrics | null;
}

export interface ProjectChapterQualityTrendResponse {
  project_id: string;
  has_metrics: boolean;
  total_chapters: number;
  analyzed_chapters: number;
  items: ProjectChapterQualityTrendItem[];
  quality_metrics_summary?: ChapterQualityMetricsSummary | null;
}

export interface ChapterQualityMetricsResponse {
  chapter_id: string;
  has_metrics: boolean;
  latest_metrics: ChapterQualityMetrics | null;
  history_id: string | null;
  generated_at: string | null;
  latest_quality_metrics?: ChapterLatestQualityMetrics | null;
  quality_metrics_summary?: ChapterQualityMetricsSummary | null;
  quality_profile_summary?: ChapterQualityProfileSummary | null;
}

// AI生成请求类型
export interface GenerateOutlineRequest {
  project_id: string;
  genre?: string;
  theme: string;
  chapter_count: number;
  narrative_perspective: string;
  world_context?: Record<string, unknown>;
  characters_context?: Character[];
  target_words?: number;
  requirements?: string;
  provider?: string;
  model?: string;
  // Generation mode for chapter creation
  mode?: 'auto' | 'new' | 'continue';
  story_direction?: string;
  plot_stage?: PlotStage;
  keep_existing?: boolean;
  creative_mode?: CreativeMode;
  story_focus?: StoryFocus;
  quality_preset?: QualityPreset;
  quality_notes?: string;
}

// 大纲重排序请求类型
export interface OutlineReorderItem {
  id: string;
  order_index: number;
}

export interface OutlineReorderRequest {
  orders: OutlineReorderItem[];
}

// 大纲展开相关类型定义
export interface ChapterPlanItem {
  sub_index: number;
  title: string;
  plot_summary: string;
  key_events: string[];
  character_focus: string[];
  emotional_tone: string;
  narrative_goal: string;
  conflict_type: string;
  estimated_words: number;
  scenes?: Array<{
    location: string;
    characters: string[];
    purpose: string;
  }>;
}

export interface OutlineExpansionRequest {
  target_chapter_count: number;
  expansion_strategy?: 'balanced' | 'climax' | 'detail';
  enable_scene_analysis?: boolean;
  auto_create_chapters?: boolean;
  provider?: string;
  model?: string;
}

export interface OutlineExpansionResponse {
  outline_id: string;
  outline_title: string;
  target_chapter_count: number;
  actual_chapter_count: number;
  expansion_strategy: string;
  chapter_plans: ChapterPlanItem[];
  created_chapters?: Array<{
    id: string;
    chapter_number: number;
    title: string;
    summary: string;
    outline_id: string;
    sub_index: number;
    status: string;
  }> | null;
}

export interface BatchOutlineExpansionRequest {
  project_id: string;
  outline_ids?: string[];
  chapters_per_outline: number;
  expansion_strategy?: 'balanced' | 'climax' | 'detail';
  enable_scene_analysis?: boolean;
  auto_create_chapters?: boolean;
  provider?: string;
  model?: string;
}

export interface BatchOutlineExpansionResponse {
  project_id: string;
  total_outlines_expanded: number;
  total_chapters_created: number;
  expansion_results: OutlineExpansionResponse[];
  skipped_outlines?: Array<{
    outline_id: string;
    outline_title: string;
    reason: string;
  }>;
}

export interface GenerateCharacterRequest {
  project_id: string;
  name?: string;
  role_type?: string;
  background?: string;
  requirements?: string;
  provider?: string;
  model?: string;
}

export interface PolishTextRequest {
  original_text?: string;
  text?: string;
  style?: string;
  project_id?: number;
  provider?: string;
  model?: string;
  temperature?: number;
  focus_mode?: 'balanced' | 'dialogue' | 'pacing' | 'emotion' | 'hook';
  preserve_paragraphs?: boolean;
  retain_hooks?: boolean;
}

export interface PolishTextResponse {
  original_text: string;
  polished_text: string;
  word_count_before: number;
  word_count_after: number;
}

export interface PolishBatchRequest {
  texts: string[];
  style?: string;
  provider?: string;
  model?: string;
  temperature?: number;
  focus_mode?: 'balanced' | 'dialogue' | 'pacing' | 'emotion' | 'hook';
  preserve_paragraphs?: boolean;
  retain_hooks?: boolean;
}

// 向导API响应类型
export interface GenerateCharactersResponse {
  characters: Character[];
  research_query?: string;
  research_assets?: ResearchAssetSummary[];
}

export interface GenerateOutlineResponse {
  outlines: Outline[];
  research_query?: string;
  research_assets?: ResearchAssetSummary[];
}

// API响应类型
export interface ApiResponse<T> {
  data: T;
  message?: string;
}

// 写作风格类型定义
export interface WritingStyle {
  id: number;
  user_id: string | null;  // NULL 表示全局预设风格
  name: string;
  style_type: 'preset' | 'custom';
  preset_id?: string;
  description?: string;
  prompt_content: string;
  is_default: boolean;
  order_index: number;
  created_at: string;
  updated_at: string;
}

export interface WritingStyleCreate {
  name: string;
  style_type?: 'preset' | 'custom';
  preset_id?: string;
  description?: string;
  prompt_content: string;
}

export interface WritingStyleUpdate {
  name?: string;
  description?: string;
  prompt_content?: string;
  order_index?: number;
}

export interface PresetStyle {
  id: string;
  name: string;
  description: string;
  prompt_content: string;
}

export interface WritingStyleListResponse {
  styles: WritingStyle[];
  total: number;
}

export interface PaginationResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

// 向导表单数据类型
export interface WizardBasicInfo {
  title: string;
  description: string;
  theme: string;
  genre: string | string[];
  chapter_count: number;
  narrative_perspective: string;
  character_count?: number;
  target_words?: number;
  outline_mode?: 'one-to-one' | 'one-to-many';  // 大纲章节模式
  default_creative_mode?: CreativeMode;
  default_story_focus?: StoryFocus;
  default_plot_stage?: PlotStage;
  default_story_creation_brief?: string;
  default_quality_preset?: QualityPreset;
  default_quality_notes?: string;
  model?: string;
  enable_mcp?: boolean;
  enable_web_research?: boolean;
  web_research_query?: string;
  world_building_research_query?: string;
  careers_research_query?: string;
  characters_research_query?: string;
  outline_research_query?: string;
}

// API 错误响应类型
export interface ApiError {
  response?: {
    data?: {
      detail?: string;
    };
  };
  message?: string;
}

// 章节分析任务相关类型
export interface AnalysisTask {
  has_task: boolean;
  task_id: string | null;
  chapter_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'none';
  progress: number;
  error_message?: string | null;
  error_code?: 'retrying' | 'json_parse_failed' | 'ai_empty' | 'stream_interrupted' | 'timeout' | 'chapter_empty' | 'project_missing' | 'analysis_missing' | 'unknown' | null;
  auto_recovered?: boolean;
  missing_result?: boolean;
  created_at?: string | null;
  started_at?: string | null;
  completed_at?: string | null;
  latest_quality_metrics?: ChapterLatestQualityMetrics | null;
  quality_metrics_summary?: ChapterQualityMetricsSummary | null;
  quality_profile_summary?: ChapterQualityProfileSummary | null;
}

export interface BatchAnalysisStatusResponse {
  project_id: string;
  total: number;
  items: Record<string, AnalysisTask>;
}

export interface BatchAnalyzeUnanalyzedRequest {
  chapter_ids?: string[];
}

export interface BatchAnalyzeUnanalyzedResponse {
  project_id: string;
  total_candidates: number;
  total_started: number;
  total_skipped_no_content: number;
  total_skipped_running: number;
  total_already_completed: number;
  started_tasks: Record<string, AnalysisTask>;
}

// 分析结果 - 钩子
export interface AnalysisHook {
  type: string;
  content: string;
  strength: number;
  position: string;
}

// 分析结果 - 伏笔
export interface AnalysisForeshadow {
  content: string;
  type: 'planted' | 'resolved';
  strength: number;
  subtlety: number;
  reference_chapter?: number;
}

// 分析结果 - 冲突
export interface AnalysisConflict {
  types: string[];
  parties: string[];
  level: number;
  description: string;
  resolution_progress: number;
}

// 分析结果 - 情感曲线
export interface AnalysisEmotionalArc {
  primary_emotion: string;
  intensity: number;
  curve: string;
  secondary_emotions: string[];
}

// 分析结果 - 角色状态
export interface AnalysisCharacterState {
  character_name: string;
  state_before: string;
  state_after: string;
  psychological_change: string;
  key_event: string;
  relationship_changes: Record<string, string>;
}

// 分析结果 - 情节点
export interface AnalysisPlotPoint {
  content: string;
  type: 'revelation' | 'conflict' | 'resolution' | 'transition';
  importance: number;
  impact: string;
}

// 分析结果 - 场景
export interface AnalysisScene {
  location: string;
  atmosphere: string;
  duration: string;
}

// 分析结果 - 评分
export interface AnalysisScores {
  pacing: number;
  engagement: number;
  coherence: number;
  overall: number;
}

// 完整分析数据 - 匹配后端PlotAnalysis模型
export interface AnalysisData {
  id: string;
  chapter_id: string;
  plot_stage: string;
  conflict_level: number;
  conflict_types: string[];
  emotional_tone: string;
  emotional_intensity: number;
  hooks: AnalysisHook[];
  hooks_count: number;
  foreshadows: AnalysisForeshadow[];
  foreshadows_planted: number;
  foreshadows_resolved: number;
  plot_points: AnalysisPlotPoint[];
  plot_points_count: number;
  character_states: AnalysisCharacterState[];
  scenes?: AnalysisScene[];
  pacing: string;
  overall_quality_score: number;
  pacing_score: number;
  engagement_score: number;
  coherence_score: number;
  analysis_report: string;
  suggestions: string[];
  dialogue_ratio: number;
  description_ratio: number;
  created_at: string;
}

// 记忆片段
export interface StoryMemory {
  id: string;
  type: 'hook' | 'foreshadow' | 'plot_point' | 'character_event';
  title: string;
  content: string;
  importance: number;
  tags: string[];
  is_foreshadow: 0 | 1 | 2; // 0=普通, 1=已埋下, 2=已回收
}

// 章节分析结果响应 - 匹配后端API返回
export interface ChapterTextCheckerIssue {
  severity: 'critical' | 'major' | 'minor';
  category: string;
  location: string;
  evidence: string;
  impact: string;
  suggestion: string;
}

export interface ChapterTextCheckerResult {
  overall_assessment: string;
  severity_counts: {
    critical: number;
    major: number;
    minor: number;
  };
  issues: ChapterTextCheckerIssue[];
  priority_actions: string[];
  revision_suggestions: string[];
  quality_profile_summary?: ChapterQualityProfileSummary | null;
}

export interface ChapterAutoRevisionDraft {
  history_id: string | null;
  critical_count: number;
  major_count: number;
  priority_issue_count: number;
  applied_critical_count: number;
  applied_issue_count: number;
  change_summary: string | null;
  revised_word_count: number;
  unresolved_issues: string[];
  revised_text_preview: string;
  has_full_text: boolean;
  revised_text?: string;
  is_stale: boolean;
  created_at: string | null;
  quality_profile_summary?: ChapterQualityProfileSummary | null;
}

export interface ChapterCandidateDraftFailedMetric {
  key?: string;
  label?: string;
  value?: number;
  threshold?: number;
  gap?: number;
  focus_area?: string | null;
  repair_target?: string | null;
}

export interface ChapterCandidateSelectionSummary {
  candidate_index?: number;
  candidate_count?: number;
  source?: string;
  selection_score?: number;
  overall_score?: number;
  quality_gate_decision?: string;
  quality_gate_status?: string;
  quality_gate_priority?: number;
  word_count?: number;
  target_word_count?: number;
  word_count_fit_score?: number;
  word_count_delta?: number;
  continuity_warning_count?: number;
  generation_path?: string;
  attempt_kind?: string;
  rerank_used?: boolean;
  word_budget_repair_used?: boolean;
  winner_candidate_index?: number;
}

export interface ChapterCandidateDraftQualityEvidence {
  item: string;
  snippet: string;
  matched_anchors: string[];
}

export interface ChapterCandidateDraftQualityFacet {
  status: string;
  summary?: string | null;
  matched_items: string[];
  missing_items: string[];
  repair_targets: string[];
  matched_evidence?: ChapterCandidateDraftQualityEvidence[];
}

export interface ChapterCandidateDraftQualityHighlights {
  continuity?: ChapterCandidateDraftQualityFacet | null;
  foreshadow?: ChapterCandidateDraftQualityFacet | null;
}

export interface ChapterCandidateDraftApplyRisk {
  status: string;
  summary?: string | null;
  items: string[];
}

export interface ChapterCandidateDraft {
  attempt_id: string;
  source: string;
  attempt_state: string;
  quality_gate_action?: string | null;
  quality_gate_decision?: string | null;
  word_count: number;
  summary_preview: string;
  content_preview: string;
  has_full_content: boolean;
  content_complete: boolean;
  can_apply: boolean;
  is_stale: boolean;
  created_at: string | null;
  repair_summary?: string | null;
  repair_targets: string[];
  preserve_strengths: string[];
  focus_areas: string[];
  failed_metrics: ChapterCandidateDraftFailedMetric[];
  candidate_selection?: ChapterCandidateSelectionSummary | null;
  quality_highlights?: ChapterCandidateDraftQualityHighlights | null;
  apply_risk?: ChapterCandidateDraftApplyRisk | null;
  content?: string;
}

export interface ChapterAnalysisResponse {
  chapter_id: string;
  analysis: AnalysisData;  // Backend returns analysis here instead of analysis_data
  memories: StoryMemory[];
  checker_result?: ChapterTextCheckerResult | null;
  checker_created_at?: string | null;
  auto_revision_draft?: ChapterAutoRevisionDraft | null;
  candidate_draft?: ChapterCandidateDraft | null;
  quality_metrics?: ChapterLatestQualityMetrics | null;
  quality_metrics_summary?: ChapterQualityMetricsSummary | null;
  quality_profile_summary?: ChapterQualityProfileSummary | null;
  created_at: string;
}

export interface ChapterAutoRevisionDraftResponse {
  chapter_id: string;
  auto_revision_draft: ChapterAutoRevisionDraft;
}

export interface ApplyAutoRevisionDraftRequest {
  history_id?: string;
  allow_stale?: boolean;
}

export interface ApplyAutoRevisionDraftResponse {
  success: boolean;
  chapter_id: string;
  word_count: number;
  old_word_count: number;
  draft_history_id: string;
  draft_created_at: string | null;
  stale_applied: boolean;
  message: string;
}

export interface ChapterCandidateDraftResponse {
  chapter_id: string;
  candidate_draft: ChapterCandidateDraft;
}

export interface ApplyCandidateDraftRequest {
  attempt_id?: string;
  allow_stale?: boolean;
}

export interface ApplyCandidateDraftResponse {
  success: boolean;
  chapter_id: string;
  word_count: number;
  old_word_count: number;
  draft_attempt_id: string;
  draft_created_at: string | null;
  stale_applied: boolean;
  message: string;
}

export interface TriggerAnalysisResponse {
  task_id: string;
  chapter_id: string;
  status: string;
  message: string;
}

// MCP 插件类型定义 - 优化后只包含必要字段
export interface MCPPlugin {
  id: string;
  plugin_name: string;
  display_name: string;
  description?: string;
  plugin_type: 'http' | 'stdio' | 'streamable_http' | 'sse';
  category: string;

  // HTTP类型字段
  server_url?: string;
  headers?: Record<string, string>;

  // Stdio类型字段
  command?: string;
  args?: string[];
  env?: Record<string, string>;

  // 状态字段
  enabled: boolean;
  status: 'active' | 'inactive' | 'error';
  last_error?: string;
  last_test_at?: string;

  // 时间戳
  created_at: string;
}

export interface MCPPluginCreate {
  plugin_name: string;
  display_name?: string;
  description?: string;
  server_type: 'http' | 'stdio' | 'streamable_http' | 'sse';
  server_url?: string;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  headers?: Record<string, string>;
  enabled?: boolean;
}

export interface MCPPluginUpdate {
  display_name?: string;
  description?: string;
  server_url?: string;
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  headers?: Record<string, string>;
  enabled?: boolean;
}

export interface MCPTool {
  name: string;
  description?: string;
  inputSchema?: Record<string, unknown>;
}

export interface MCPTestResult {
  success: boolean;
  message: string;
  tools?: MCPTool[];
  tools_count?: number;
  response_time_ms?: number;
  error?: string;
  error_type?: string;
  suggestions?: string[];
}

export interface MCPToolCallRequest {
  plugin_id: string;
  tool_name: string;
  arguments: Record<string, unknown>;
}

export interface MCPToolCallResponse {
  success: boolean;
  result?: unknown;
  error?: string;
}

// 伏笔管理类型定义
export type ForeshadowStatus = 'pending' | 'planted' | 'resolved' | 'partially_resolved' | 'abandoned';
export type ForeshadowSourceType = 'analysis' | 'manual';
export type ForeshadowCategory = 'identity' | 'mystery' | 'item' | 'relationship' | 'event' | 'ability' | 'prophecy';

export interface Foreshadow {
  id: string;
  project_id: string;
  title: string;
  content: string;
  hint_text?: string;
  resolution_text?: string;
  source_type?: ForeshadowSourceType;
  source_memory_id?: string;
  source_analysis_id?: string;
  plant_chapter_id?: string;
  plant_chapter_number?: number;
  target_resolve_chapter_id?: string;
  target_resolve_chapter_number?: number;
  actual_resolve_chapter_id?: string;
  actual_resolve_chapter_number?: number;
  status: ForeshadowStatus;
  is_long_term: boolean;
  importance: number;
  strength: number;
  subtlety: number;
  urgency: number;
  related_characters?: string[];
  related_foreshadow_ids?: string[];
  tags?: string[];
  category?: ForeshadowCategory;
  notes?: string;
  resolution_notes?: string;
  auto_remind: boolean;
  remind_before_chapters: number;
  include_in_context: boolean;
  created_at?: string;
  updated_at?: string;
  planted_at?: string;
  resolved_at?: string;
}

export interface ForeshadowCreate {
  project_id: string;
  title: string;
  content: string;
  hint_text?: string;
  resolution_text?: string;
  plant_chapter_number?: number;
  target_resolve_chapter_number?: number;
  is_long_term?: boolean;
  importance?: number;
  strength?: number;
  subtlety?: number;
  related_characters?: string[];
  tags?: string[];
  category?: ForeshadowCategory;
  notes?: string;
  resolution_notes?: string;
  auto_remind?: boolean;
  remind_before_chapters?: number;
  include_in_context?: boolean;
}

export interface ForeshadowUpdate {
  title?: string;
  content?: string;
  hint_text?: string;
  resolution_text?: string;
  plant_chapter_number?: number;
  target_resolve_chapter_number?: number;
  status?: ForeshadowStatus;
  is_long_term?: boolean;
  importance?: number;
  strength?: number;
  subtlety?: number;
  urgency?: number;
  related_characters?: string[];
  related_foreshadow_ids?: string[];
  tags?: string[];
  category?: ForeshadowCategory;
  notes?: string;
  resolution_notes?: string;
  auto_remind?: boolean;
  remind_before_chapters?: number;
  include_in_context?: boolean;
}

export interface ForeshadowStats {
  total: number;
  pending: number;
  planted: number;
  resolved: number;
  partially_resolved: number;
  abandoned: number;
  long_term_count: number;
  overdue_count: number;
}

export interface ForeshadowListResponse {
  total: number;
  items: Foreshadow[];
  stats?: ForeshadowStats;
}

export interface PlantForeshadowRequest {
  chapter_id: string;
  chapter_number: number;
  hint_text?: string;
}

export interface ResolveForeshadowRequest {
  chapter_id: string;
  chapter_number: number;
  resolution_text?: string;
  is_partial?: boolean;
}

export interface SyncFromAnalysisRequest {
  chapter_ids?: string[];
  overwrite_existing?: boolean;
  auto_set_planted?: boolean;
}

export interface SyncFromAnalysisResponse {
  synced_count: number;
  skipped_count: number;
  new_foreshadows: Foreshadow[];
  skipped_reasons: Array<{ source_memory_id: string; reason: string }>;
}

export interface ForeshadowContextResponse {
  chapter_number: number;
  context_text: string;
  pending_plant: Foreshadow[];
  pending_resolve: Foreshadow[];
  overdue: Foreshadow[];
  recently_planted: Foreshadow[];
}

// ==================== 拆书导入类型定义 ====================

export type BookImportTaskStatus = 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
export type BookImportWarningLevel = 'info' | 'warning' | 'error';

export interface BookImportWarning {
  code: string;
  message: string;
  level: BookImportWarningLevel;
}

export interface BookImportProjectSuggestion {
  title: string;
  description?: string;
  theme?: string;
  genre?: string;
  narrative_perspective: string;
  target_words: number;
}

export interface BookImportChapter {
  title: string;
  content: string;
  summary?: string;
  chapter_number: number;
  outline_title?: string;
}

export interface BookImportOutline {
  title: string;
  content?: string;
  order_index: number;
  structure?: Record<string, unknown>;
}

export interface BookImportTask {
  task_id: string;
  status: BookImportTaskStatus;
  progress: number;
  message?: string;
  error?: string;
  created_at: string;
  updated_at: string;
}

export interface BookImportPreview {
  task_id: string;
  project_suggestion: BookImportProjectSuggestion;
  chapters: BookImportChapter[];
  outlines: BookImportOutline[];
  warnings: BookImportWarning[];
}

export interface BookImportApplyPayload {
  project_suggestion: BookImportProjectSuggestion;
  chapters: BookImportChapter[];
  outlines: BookImportOutline[];
  import_mode?: 'append' | 'overwrite';
}

export interface BookImportResult {
  success: boolean;
  project_id: string;
  statistics: {
    chapters: number;
    outlines: number;
    generated_careers?: number;
    generated_entities?: number;
    generated_world_building?: number;
  };
  warnings: BookImportWarning[];
  failed_steps?: BookImportStepFailure[];
}

export interface BookImportStepFailure {
  step_name: string;       // world_building / career_system / characters
  step_label: string;      // 中文名
  error: string;           // 错误详情
  retry_count?: number;    // 已重试次数
}

export interface BookImportRetryResult {
  success: boolean;
  project_id: string;
  retry_results: Record<string, number>;
  still_failed: BookImportStepFailure[];
}

// ==================== 提示词工坊类型定义 ====================

export interface PromptWorkshopItem {
  id: string;
  name: string;
  description?: string;
  prompt_content: string;
  category: string;
  tags?: string[];
  author_name?: string;
  is_official: boolean;
  download_count: number;
  like_count: number;
  is_liked?: boolean;
  created_at?: string;
}

export interface PromptSubmission {
  id: string;
  name: string;
  description?: string;
  prompt_content?: string;
  category: string;
  tags?: string[];
  author_display_name?: string;
  is_anonymous: boolean;
  status: 'pending' | 'approved' | 'rejected';
  review_note?: string;
  reviewed_at?: string;
  created_at?: string;
  source_instance?: string;
  submitter_name?: string;
}

export interface PromptSubmissionCreate {
  name: string;
  description?: string;
  prompt_content: string;
  category: string;
  tags?: string[];
  author_display_name?: string;
  is_anonymous?: boolean;
  source_style_id?: number;
}

export interface PromptWorkshopCategory {
  id: string;
  name: string;
  count: number;
}

export interface PromptWorkshopListResponse {
  success: boolean;
  data: {
    total: number;
    page: number;
    limit: number;
    items: PromptWorkshopItem[];
    categories: PromptWorkshopCategory[];
  };
}

export interface PromptWorkshopStatusResponse {
  mode: 'client' | 'server';
  instance_id: string;
  cloud_url?: string;
  cloud_connected?: boolean;
}

export interface PromptWorkshopAdminStats {
  total_items: number;
  total_official: number;
  total_pending: number;
  total_downloads: number;
  total_likes: number;
}

// 提示词工坊分类常量
export const PROMPT_CATEGORIES: Record<string, string> = {
  general: '通用',
  fantasy: '玄幻/仙侠',
  martial: '武侠',
  romance: '言情',
  scifi: '科幻',
  horror: '悬疑/惊悚',
  history: '历史',
  urban: '都市',
  game: '游戏/电竞',
  other: '其他',
};
